install

- build ArgoCD docker image with certificates for Amundi
- public allinone.yaml + modifs + ingress for traefik LB
- connect as admin, change password (CLI)
- connect clusters caas-poc caas-np caas-prd (CLI)
- create repositories (templates for connection to git & helm repositories)
- run helm chart to populate projects and applications


```
# Run helm chart install to populate applications and projects :D
helm upgrade --install argocd-manifests . \
--namespace argocd \
-f projects/caas-links.yaml