# prometheus-rules

## Usage

```yaml
# Global settings that can override specific settings in your chart
global:
  fullnameOverride: "myapp"

# Configuration for container status Prometheus rules
containerStatus:
  enabled: true  # Set to true to enable the container status Prometheus rules
  centreon: true  # Optional: If set to true, adds a label `alerting: centreon`

# Explanation:
# - global.fullnameOverride: This allows you to override the full name of the application, ensuring consistent naming conventions.
# - containerStatus.enabled: This enables or disables the container status Prometheus rules.
# - containerStatus.centreon: When set to true, adds a label `alerting: centreon` to the PrometheusRule resource.

# With the above values, the template will generate a PrometheusRule with the name `customapp-container.rules`.
```

## Note for Centreon

There is a custom script that generates centreon alerts based on alertmanager status.  
Scheduled on a daily basis or can ask MONITORING team to trigger it.  
if parameter `centreon: true` is set.  
This will add `alerting: centreon` label to the Prometheus Rule which will allow the centreon script  
to discover all Alerts with label `severity: critical` **only**, to be discovered and available on centreon.  