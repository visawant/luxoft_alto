# secrets

# Usage

values.yaml examples from a parent chart importing this one ("secrets").

## Example using secretProviderClass

```yaml
# values.yaml
secrets:
  provider: azure
  usePodIdentity: false
  useVMManagedIdentity: true
  tenantId: "xxxx-xxxx-xxxx-xxxx"
  userAssignedIdentityID: "yyyy-yyyy-yyyy-yyyy"
  keyvaultName: "example-keyvault"
  secretProviderClass:
    - name: some-certificate # as seen from secretProviderClass custom resource.
      objects: |
        array:
          - |
            objectName: some-certificate-on-azure-keyvault
            objectType: secret
      secretObjects:
        - secretName: some-certificate # as seen from k8s secret.
          type: kubernetes.io/tls
          data:
          - objectName: some-certificate-on-azure-keyvault
            key: tls.key
          - objectName: some-certificate-on-azure-keyvault
            key: tls.crt

```

## Example using vaultStaticSecret

[confluence/VLT - more info](https://confluence.intramundi.com/x/HQHAF)

This section describe the method used to build the target Vault path where your Kubernetes application secrets are migrated.

| Vault path elements | Source |
| ---                 | ---    |
| **namespace**    | Concatenation of "tenant_" and "customer.code" <br> Example: tenant_corporate or tenant_bny, tenant_gam, etc... | 
| **Secret engine** | Concatenation of "customer.code" and "_kv2_shared" <br> Example: corporate_kv2_shared or bs_kv2_shared, cai-mil_kv2_shared, etc... |
| **Path version** | static value: v1 |
| **trigram** | Value from labels.cmdb/trigram |
| **component** | Concatenation of "k8s-app-name" + "_" + "k8s-namespace" |
| **secret type** | Allows you to give a 'type' to your secret. <br> Example: database, sso, ... <br> defaults to "other-secrets" |
| **sub-path** level 1 | Can be user-defined. Last element will be the name of kubernetes secret <br> Example: "my/awesome/application/vault-operator" <br> then "vault-operator" kubernetes secret will be created, you then have to reference it from your helm chart. |


```yaml
# values.yaml
secrets:
  secretEngine: "" # (opt.) explained Above "Secret Engine", defaults to "corporate_kv2_shared".
  secretType: "" # (opt.) defaults to "kv-v2". 
  refreshAfter: "" # (opt.) defaults to "300s".
  env: "" # (req.) Environment (dev,rct,tst,ppr,prd)
  vaultStaticSecret:
    - trigram: "" # (req.) explained Above "trigram".
      component: "" # (opt.) explained Above "component".
      type: "" # (opt.) explained Above "secret type".
      secretEngine: "" # (opt.)
      secretType: "" # (opt.)
      refreshAfter: "" # (opt.)
      secretList:
        - k8sSecretName: "" # (req.) explained Above "trigram".
          type: "" # (opt.)
          secretEngine: "" # (opt.) 
          secretType: "" # (opt.)
          refreshAfter: "" # (opt.)
          vaultSecretPath: "" # (opt.) this is when path is not standard. Should be discouraged.
          # if path is not present, then the path will be generated 
          # path: v1/{{ <Current Namespace> }}/alt/{{ env }}/{{ component }}/{{ secretType }}/{{ k8sSecretName }}
          component: "" # (opt.) Component will be ignored if path is set.

```
