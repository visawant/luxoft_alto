# configs

## Usage 
You can create as many configmaps as you need with this library.

```yaml
# Global settings that can override specific settings in your chart
global:
  # This value will be added as prefix automatically in the configmap name
  fullnameOverride: "myapp"  # Overrides the full name of the application if provided

# This section creates key value ConfigMap
fromKeyValues:
  destinationConfigmaps:
    config1: # The first configmap will be created with name "myapp-config1"
      EXAMPLE_KEY: example-value
      ANOTHER_KEY: 42
    config2: # The second configmap will be created with name "myapp-config2"
      EXAMPLE_KEY_TITI: example-value
      ANOTHER_KEY_TOTO: 42
    ...

# This section creates file ConfigMap
fromFiles:
  destinationConfigmaps:
    config3:
      "test.yaml": |-
        contentOfTestYaml
        ...
      "test.txt": |-
        contentOfTestTxt
        ...
    config4:
      "toto.xml": |-
        contentOfTotoXml
        ...

```
