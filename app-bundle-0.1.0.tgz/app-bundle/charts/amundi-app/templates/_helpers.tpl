{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "amundi-app.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "amundi-app.fullname" -}}
{{- if .Values.global.fullnameOverride }}
{{- .Values.global.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "amundi-app.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Define custom image name.
*/}}
{{- define "amundi-app.image-name" -}}
  {{- $registry := .Values.global.image.registry | default .Values.image.registry -}}
  {{- $repository := trimPrefix "registry-docker.intramundi.com/" (.Values.global.image.repository | default .Values.image.repository) -}}
  {{- $tag := .Values.global.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}

  {{- if $registry -}}
    {{- printf "%s/%s:%s" $registry $repository $tag | quote -}}
  {{- else -}}
    {{- printf "%s:%s" $repository $tag | quote -}}
  {{- end -}}
{{- end }}

{{/*
Define custom Job image name.
*/}}
{{- define "amundi-app.job-image-name" -}}
  {{- $registry := .Values.global.jobs.image.registry | default .Values.global.image.registry | default .Values.image.registry -}}
  {{- $repository := trimPrefix "registry-docker.intramundi.com/" (.Values.global.jobs.image.repository | default .Values.global.image.repository | default .Values.image.repository) -}}
  {{- $tag := .Values.global.jobs.image.tag | default .Values.global.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if and $registry $repository $tag -}}
    {{- printf "%s/%s:%s" $registry $repository $tag | quote -}}
  {{- end -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "amundi-app.labels" -}}
helm.sh/chart: {{ include "amundi-app.chart" . | quote }}
{{ include "amundi-app.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ ( .Values.image.tag | default .Chart.AppVersion ) | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app: {{ include "amundi-app.fullname" . }}
{{- if .Values.labels }}
{{ toYaml .Values.labels }}
{{- end }}
{{- if .Values.ingress.enabled }}
exposed: "external"
{{- else if .Values.service.enabled }}
exposed: "internal"
{{- else }}
exposed: "no"
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "amundi-app.selectorLabels" -}}
app.kubernetes.io/name: {{ include "amundi-app.fullname" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "amundi-app.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "amundi-app.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
