# external-service

Creates services and EndpointSlice k8s resources.
