# gemini-backup

## Usage

This can only be used on AKS Cluster afaik. Gemini needs to be deployed.
values.yaml examples from a parent chart importing this one (as alias "backups").

## Example

```yaml
# values.yaml
backups:
  backups:
  - pvcName: filepvc
    snapshotClass: csi-azurefile-vsc
    schedule:
    - every: 10 minutes
      keep: 3
  - pvcName: diskpvc
    snapshotClass: csi-azuredisk-vsc
    schedule:
    - every: day
      keep: 1
    - every: month
      keep: 1
```

### PS

For more infos on this : <https://github.com/FairwindsOps/gemini>
