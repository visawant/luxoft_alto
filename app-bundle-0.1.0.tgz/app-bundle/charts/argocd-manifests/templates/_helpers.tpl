{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "argocd-manifests.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "argocd-manifests.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "argocd-manifests.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "argocd-manifests.labels" -}}
helm.sh/chart: {{ include "argocd-manifests.chart" . | quote }}
{{ include "argocd-manifests.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ ( .Values.image.tag | default .Chart.AppVersion ) | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app: {{ include "argocd-manifests.fullname" . }}
{{- if .Values.labels }}
{{ toYaml .Values.labels }}
{{- end }}
{{- if .Values.ingress.enabled }}
exposed: "external"
{{- else if .Values.service.enabled }}
exposed: "internal"
{{- else }}
exposed: "no"
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "argocd-manifests.selectorLabels" -}}
app.kubernetes.io/name: {{ include "argocd-manifests.fullname" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "argocd-manifests.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "argocd-manifests.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}