locals {
  workload_name = "citrix"
  iaas_resource_group = {
    "01" = {
      workload_name = local.workload_name
      tags = {
        application = "citrix"
      }
    }
  }

  shared_services_key_vault = {
    "01" = {
      instance_name             = "01"
      resource_group_key        = "01"
      enable_rbac_authorization = true
      tags = {
        description = "azure key vault"
      }

      role_assignment = {
        "sp-terraform-caf" = {
          role_definition_name = "Key Vault Administrator"
          principal_id         = "1be7ac54-bf01-4444-a014-5710361757d0"
        }
        "GSCO_CREW_DAT" = {
          role_definition_name = "Key Vault Administrator"
          principal_id         = "5ffcc1c1-1bd9-4d28-8215-0feebff9f515"
        }
        "GSCO_CREW_CTX_kv_reader" = {
          role_definition_name = "Key Vault Reader"
          principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb"
        }
        "GSCO_CREW_CTX_sp_citrix_user" = {
          role_definition_name = "Key Vault Secrets User"
          principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb"
          sub_scope            = "/secrets/sp-citrix-sbi-${var.environment}-secret"
        }
        "GSCO_CREW_CTX_inccitrix01_vm" = {
          role_definition_name = "Key Vault Secrets User"
          principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb"
          sub_scope            = "/secrets/inccitrix${var.environment}01-admin"
        }
        "GSCO_CREW_CTX_inccitrix01_vm02" = {
          role_definition_name = "Key Vault Secrets User"
          principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb"
          sub_scope            = "/secrets/inccitrix${var.environment}02-admin"
        }
        "GSCO_CREW_SBI-kv_reader" = {
          role_definition_name = "Key Vault Reader"
          principal_id         = "c29e804a-a6ba-4396-80cf-53823307f4aa"
        }
        "GSCO_CREW_SBI-sp-yannick-chailler-sbi-file-exchange-secret" = {
          role_definition_name = "Key Vault Secrets User"
          principal_id         = "c6d646a6-9368-4f31-94cb-094e91507819"
          sub_scope            = "/secrets/sp-yannick-chailler-sbi-file-exchange-${var.environment}-secret"
        }
        "GSCO_CREW_TLS-kv_reader" = {
          role_definition_name = "Key Vault Reader"
          principal_id         = "29ed7da5-63e6-4564-a0bb-eec262ce02b1"
        }
        "GSCO_CREW_TLS-sp-control-m-sef-sbi-file-exchange-secret" = {
          role_definition_name = "Key Vault Secrets User"
          principal_id         = "29ed7da5-63e6-4564-a0bb-eec262ce02b1"
          sub_scope            = "/secrets/sp-control-m-sef-sbi-file-exchange-${var.environment}-secret"
        }
      }

      import_certificate = {
        "01" = {
          existing_certificate_key = "01"
        }
      }

      import_secret = {
        "certificate-authority-azure-mysql" = {
          existing_secret_key = "certificate-authority-azure-mysql"
          content_type        = "certificat"
        }
        "app-sysdig-amt-prd-access-key" = {
          existing_secret_key = "app-sysdig-amt-prd-access-key"
          content_type        = "secret"
          ignore_value        = true //Updated manually because we need one key per aks cluster
        }
        "app-sysdig-amt-prd-api-token" = {
          existing_secret_key = "app-sysdig-amt-prd-api-token"
          content_type        = "secret"
        }
      }

      private_endpoint = {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 4 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias = "shared-services"
        }
      }
    }
  }
}
