# test rendering chart templates locally

```
helm install --dry-run  --debug                                 \
                        --values ./uat/values.yaml              \
                         keda-blob-storage .
```

# deploy via helm

```
helm install    --values ./uat/values.yaml             \
                 keda-blob-storage .
```

# remove deployed helm resource

```
helm delete keda-blob-storage
```
