subscription_id_client = "3441c187-88ab-417c-b052-dad3f6733564"
environment            = "uat"
project_name           = "sbi"
ops_team               = "g-x-admin-azure"
it_owner               = "g-x-admin-azure"

##############################################
###### azure devops area specifications
##############################################
azure_devops = {
  "01" = {
    amundi_products = ["alto-invest"]
    group_membership = {
      "01" = {
        entra_id_group_member = [
          "c6d646a6-9368-4f31-94cb-094e91507819", // GSCO_CREW_SBI
          "c29e804a-a6ba-4396-80cf-53823307f4aa"  // GSCO_AZURECLOUD_DAT_SSO
        ]
        entra_id_service_principal_member = [
          "c8860617-2004-4e6e-98e6-ab05587efbb5" // Object Id of the Managed Identity inc-id-management-np-01-sso-infra-sync-keycloak-config-as-code-01
        ]
      }
    }
  }
}

##############################################
###### database area specifications
##############################################
database_default_specification = {
  postgresql_flexible_server = {
    np = {
      sku = "B_Standard_B2s"
      server_configuration = {
        max_connections = {
          name  = "max_connections"
          value = "400"
        }
      }
    }
  }
}

##############################################
###### container area specifications
##############################################
container_default_specification = {
  aks = {
    keda = true
    default_node_pool = {
      zones = ["1", "2"] // The zone(s) '3' for resource 'sbiuat01' is not supported. The supported zones for location 'centralindia' are '2,1'"
      np    = {}
      prd   = {}
    }
  }
}

##############################################
###### bastion area specifications
##############################################
bastion_default_specification = {
  Developer = {
    zones = []
  }
  Standard = {
    zones                  = [] // Central India does not support Bastion with Availability Zones
    copy_paste_enabled     = true
    file_copy_enabled      = false
    ip_connect_enabled     = false
    scale_units            = 2
    shareable_link_enabled = true
    tunneling_enabled      = false
    kerberos_enabled       = false
  }
}

##############################################
###### dns area specifications
##############################################
dns_records = {
  traefik_private_endpoint_cname_record = {
    "01" = {
      container_aks_key = "01"
      dns_suffixes = [ // Will be prefixed by the env name for non prod env, sample: alto-amt-china-dmo.azure.intramundi.com
        "sso-sbi",     // For uat env
        "inc-sbi",
        "alto-sbi",
        "alto-sbi-reporting",
        "inc-dagster-sbi"
      ]
    }
  }
}

##############################################
###### shared services area specifications
##############################################
shared_services_aad_application = {
  "sp-citrix-sbi-uat" = {
    display_name  = "sp-citrix-sbi-uat"
    description   = "Service principal for Citrix"
    key_vault_key = "01"
    owners        = ["1be7ac54-bf01-4444-a014-5710361757d0"] //sp-terraform-caf]
    secret = {
      name        = "sp-citrix-sbi-uat"
      version     = "v2"
      auto_rotate = true
    }
  }

  "yannick_chailler_sbi_file_exchange" = {
    display_name  = "sp-yannick-chailler-sbi-file-exchange-uat"
    description   = "Service principal for yannick chailler to evaluate file exchange from SBI to Alto"
    key_vault_key = "01"
    secret = {
      name        = "sp-yannick-chailler-sbi-file-exchange-uat"
      version     = "v1"
      auto_rotate = true # <-- enables time_rotating
    }
  }

  "sp-control-m-sef-sbi-file-exchange-uat" = {
    display_name  = "sp-control-m-sef-sbi-file-exchange-uat"
    description   = "Service principal for Control-M to evaluate file exchange from SBI to Alto"
    key_vault_key = "01"
    secret = {
      name         = "sp-control-m-sef-sbi-file-exchange-uat"
      version      = "v1"
      auto_rotate  = true
      content_type = "secret"
      hashicorp_vault = {
        app_trigram = "sef"
      }
    }
  }
}

shared_services_storage_account = {
  "01" = {
    instance_name      = "01"
    resource_group_key = "01"
    account_tier       = "Premium"
    account_kind       = "FileStorage"
    tags = {
      description = "azure storage account"
      ops_team    = "g-x-admin-azure",
      it_owner    = "g-x-admin-azure"
    }

    private_endpoint = {

      current_file = {
        alias            = "current"
        subresource_name = "file"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 7 // Take the IP address number "cidrhost_hostnum" of the current subnet
          }
        ]
      }

      shared-services_file = {
        alias            = "shared-services"
        subresource_name = "file"
      }
    }

    share = {
      "citrix" = {
        name             = "citrix"
        share_quota      = "1000"
        enabled_protocol = "SMB"
      }
    }

    role_assignment = {
      "incstsbiuat01-reader" = {
        role_definition_name = "Reader"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb" // GSCO_CREW_CTX
        principal_type       = "Group"
      }
      "sbi-citrix-smb-share-reader" = {
        role_definition_name = "Storage File Data SMB Share Reader"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb" // GSCO_CREW_CTX
        principal_type       = "Group"
        sub_scope            = "/fileServices/default/fileshares/citrix"
      }
      "sbi-citrix-smb-share-contributor" = {
        role_definition_name = "Storage File Data SMB Share Contributor"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb" // GSCO_CREW_CTX
        principal_type       = "Group"
        sub_scope            = "/fileServices/default/fileshares/citrix"
      }
      "GSCO_CREW_CTX Storage Blob Data Contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb"
        principal_type       = "Group"
        sub_scope            = "/blobServices/default/containers/citrix"
      }
    }
  }

  "02" = {
    instance_name      = "02"
    resource_group_key = "01"

    account_tier   = "Standard" // when is_hns_enabled is set to true the account_tier is Standard or Premium with account_kind is BlockBlobStorage
    account_kind   = "StorageV2"
    is_hns_enabled = "true" // must be true for ADLS Gen2
    tags = {
      description = "azure storage account"
      ops_team    = "g-x-admin-azure",
      it_owner    = "g-x-admin-azure"
    }

    private_endpoint = {
      current_file = {
        alias            = "current"
        subresource_name = "file"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 33 // Take the IP address number "cidrhost_hostnum" of the current subnet
          }
        ]
      }
      shared-services_file = {
        alias            = "shared-services"
        subresource_name = "file"
      }

      current_blob = {
        alias            = "current"
        subresource_name = "blob"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 34 // Take the IP address number "cidrhost_hostnum" of the current subnet
          }
        ]
      }
      shared-services_blob = {
        alias            = "shared-services"
        subresource_name = "blob"
      }

      current-dfs = {
        alias            = "current"
        subresource_name = "dfs"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 39 // Take the IP address number "cidrhost_hostnum" of the current subnet
            //Reserved for a third storage account blob part -> cidrhost_hostnum = 40 // Take the IP address number "cidrhost_hostnum" of the current subnet
          }
        ]
      }
      shared-services-dfs = {
        alias            = "shared-services"
        subresource_name = "dfs"
      }
    }

    share = {
      "citrix" = {
        name             = "citrix"
        access_tier      = "Hot"
        share_quota      = "10"
        enabled_protocol = "SMB"
      }
    }

    container = {
      "citrix" = {
        name                  = "citrix"
        container_access_type = "private"
      }
      "mfundplus-input" = {
        name                  = "mfundplus-input"
        container_access_type = "private"
      }
      "mfundplus-data" = {
        name                  = "mfundplus-data"
        container_access_type = "private"
      }
      "alto-trustee" = {
        name                  = "alto-trustee"
        container_access_type = "private"
      }
    }

    role_assignment = {
      "incstsbiuat02-reader" = {
        role_definition_name = "Reader"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb" // GSCO_CREW_CTX
        principal_type       = "Group"
      }
      "sbi-citrix-smb-share-reader" = {
        role_definition_name = "Storage File Data SMB Share Reader"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb" // GSCO_CREW_CTX
        principal_type       = "Group"
        sub_scope            = "/fileServices/default/fileshares/citrix"
      }
      "sbi-citrix-smb-share-contributor" = {
        role_definition_name = "Storage File Data SMB Share Contributor"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb" // GSCO_CREW_CTX
        principal_type       = "Group"
        sub_scope            = "/fileServices/default/fileshares/citrix"
      }
      "GSCO_CREW_CTX Storage Blob Data Contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        principal_id         = "1b2e709f-ce77-48d6-8d5a-36cd6af717fb"
        principal_type       = "Group"
        sub_scope            = "/blobServices/default/containers/citrix"
      }
      "GSCO_CREW_SBI-reader" = {
        role_definition_name = "Reader"
        principal_id         = "c29e804a-a6ba-4396-80cf-53823307f4aa" // GSCO_CREW_SBI
        principal_type       = "Group"
      }
      "GSCO_CREW_SBI-Storage Blob Data Contributor-mfundplus-input" = {
        role_definition_name = "Storage Blob Data Contributor"
        principal_id         = "c29e804a-a6ba-4396-80cf-53823307f4aa" // GSCO_CREW_SBI
        principal_type       = "Group"
        sub_scope            = "/blobServices/default/containers/mfundplus-input"
      }
      "GSCO_CREW_SBI-Storage Blob Data Contributor-mfundplus-data" = {
        role_definition_name = "Storage Blob Data Contributor"
        principal_id         = "c29e804a-a6ba-4396-80cf-53823307f4aa" // GSCO_CREW_SBI
        principal_type       = "Group"
        sub_scope            = "/blobServices/default/containers/mfundplus-data"
      }
      "GSCO_CREW_SBI-Storage Blob Data Contributor-alto-trustee" = {
        role_definition_name = "Storage Blob Data Contributor"
        principal_id         = "c29e804a-a6ba-4396-80cf-53823307f4aa" // GSCO_CREW_SBI
        principal_type       = "Group"
        sub_scope            = "/blobServices/default/containers/alto-trustee"
      }

      "GSCO_CREW_TLS-reader" = {
        role_definition_name = "Reader"
        principal_id         = "29ed7da5-63e6-4564-a0bb-eec262ce02b1"
        principal_type       = "Group"
      }
      "GSCO_CREW_TLS-Storage Blob Data Contributor-mfundplus-input" = {
        role_definition_name = "Storage Blob Data Contributor"
        principal_id         = "29ed7da5-63e6-4564-a0bb-eec262ce02b1"
        principal_type       = "Group"
        sub_scope            = "/blobServices/default/containers/mfundplus-input"
      }

      "yannick_chailler_sbi_file_exchange-mfundplus-input-blob-contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        aad_application_key  = "yannick_chailler_sbi_file_exchange"
        sub_scope            = "/blobServices/default/containers/mfundplus-input"
      }
      "yannick_chailler_sbi_file_exchange-mfundplus-data-blob-contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        aad_application_key  = "yannick_chailler_sbi_file_exchange"
        sub_scope            = "/blobServices/default/containers/mfundplus-data"
      }

      "sp-control-m-sef-sbi-file-exchange-uat-mfundplus-input-blob-contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        aad_application_key  = "sp-control-m-sef-sbi-file-exchange-uat"
        sub_scope            = "/blobServices/default/containers/mfundplus-input"
      }
    }
  }
}

##############################################
###### AKS workload identities
##############################################
container_aks_workload_identity = {
  "dagster" = {
    namespace        = "platform"
    application_name = "dagster"
    tags = {
      description = "dagster workload identity"
      ops_team    = "g-x-admin-azure"
      it_owner    = "g-x-admin-azure"
    }
    role_assignment = {
      "mfundplus-input-blob-contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        scope_sa_key         = "02"
        scope_suffix         = "/blobServices/default/containers/mfundplus-input"
      }
      "mfundplus-data-blob-contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        scope_sa_key         = "02"
        scope_suffix         = "/blobServices/default/containers/mfundplus-data"
      }
    }
  }
  "contextual-proof-engine" = {
    namespace        = "platform"
    application_name = "contextual-proof-engine-sa"
    tags = {
      description = "cpe workload identity for blob storage processing"
      ops_team    = "g-x-admin-azure"
      it_owner    = "g-x-admin-azure"
    }
    role_assignment = {
      "alto-trustee-blob-contributor" = {
        role_definition_name = "Storage Blob Data Contributor"
        scope_sa_key         = "02"
        scope_suffix         = "/blobServices/default/containers/alto-trustee"
      }
    }
  }
}

##############################################
###### VM area specifications
##############################################
iaas_creation = true
iaas_vm = {
  "01" = {
    workload_name               = "citrix"
    instance_name               = "01"
    resource_group_key          = "01"
    subnet_key                  = "01-snet-citrix-01"
    ip_address_cidrhost_hostnum = 4 // Take the IP address number "cidrhost_hostnum" of the current subnet
    size                        = "Standard_D2s_v3"
    type                        = "windows"
    secure_boot_enabled         = true
    vtpm_enabled                = true
    license_type                = "None"
    source_image_reference = {
      publisher = "microsoftwindowsdesktop"
      offer     = "windows-11"
      sku       = "win11-25h2-avd"
      version   = "latest"
    }
  }
  "02" = {
    workload_name               = "citrix"
    instance_name               = "02"
    resource_group_key          = "01"
    subnet_key                  = "01-snet-citrix-01"
    ip_address_cidrhost_hostnum = 6 // Take the IP address number "cidrhost_hostnum" of the current subnet
    size                        = "Standard_D2s_v3"
    type                        = "windows"
    secure_boot_enabled         = true
    vtpm_enabled                = true
    patch_mode                  = "AutomaticByPlatform" // "patch_mode" must always be set to "AutomaticByPlatform" when "source_image_reference" points to a hotpatch enabled image
    license_type                = "None"
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2025-datacenter-azure-edition"
      version   = "latest"
    }
  }
}
