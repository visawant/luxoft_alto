module "landing-zone" {
  source = "git::https://git.intramundi.com/public-cloud-infrastructure/microsoft-azure/terraform/modules/landing-zones.git?ref=main"

  # Core variables
  subscription_id_client = var.subscription_id_client
  project_name           = var.project_name
  environment            = var.environment
  it_owner               = var.it_owner
  ops_team               = var.ops_team
  region                 = var.region

  # Authentication variables
  ARTIFACT_URL              = var.ARTIFACT_URL
  ARTIFACT_USERNAME         = var.ARTIFACT_USERNAME
  ARTIFACT_PASSWORD         = var.ARTIFACT_PASSWORD
  CONTROLLER_PUBLIC_IP      = var.CONTROLLER_PUBLIC_IP
  CONTROLLER_USERNAME       = var.CONTROLLER_USERNAME
  CONTROLLER_PASSWORD       = var.CONTROLLER_PASSWORD
  AD_SP_AVIATRIX_DAT_APP_ID = var.AD_SP_AVIATRIX_DAT_APP_ID
  AD_SP_AVIATRIX_DAT_SECRET = var.AD_SP_AVIATRIX_DAT_SECRET
  ADO_ARM_CLIENT_ID         = var.ADO_ARM_CLIENT_ID
  ADO_ARM_CLIENT_SECRET     = var.ADO_ARM_CLIENT_SECRET
  ADO_SYNC_REPO_USERNAME    = var.ADO_SYNC_REPO_USERNAME
  ADO_SYNC_REPO_PAT         = var.ADO_SYNC_REPO_PAT
  VAULT_LOGIN_SECRET_IDS    = var.VAULT_LOGIN_SECRET_IDS

  # Services variables
  azure_devops                    = var.azure_devops
  azure_devops_creation           = var.azure_devops_creation
  bastion_creation                = var.bastion_creation
  bastion_sku                     = var.bastion_sku
  bastion_default_specification   = var.bastion_default_specification
  container_creation              = var.container_creation
  container_default_specification = var.container_default_specification
  database_creation               = var.database_creation
  database_default_specification  = var.database_default_specification
  dns_creation                    = var.dns_creation
  dns_records                     = var.dns_records
  private_link_creation           = var.private_link_creation
  shared_services_creation        = var.shared_services_creation
  virtual_network_creation        = var.virtual_network_creation
  iaas_creation                   = var.iaas_creation
  iaas_resource_group             = local.iaas_resource_group
  iaas_vm                         = var.iaas_vm
  shared_services_key_vault       = local.shared_services_key_vault
  shared_services_storage_account = var.shared_services_storage_account
  shared_services_aad_application = var.shared_services_aad_application

  # Specific use case
  disable_container_aks_disk_encryption = var.disable_container_aks_disk_encryption # Legacy option for unencrypted AKS, as mentioned in the following documentation we can currently enable a customer-managed key only while creating an AKS cluster registry https://learn.microsoft.com/en-us/azure/aks/azure-disk-customer-managed-keys?WT.mc_id=AZ-MVP-5003548

  # AKS workload identities
  container_aks_workload_identity = var.container_aks_workload_identity
}
