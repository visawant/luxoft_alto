# SEBI CSCRF & Cloud Framework Compliance Gap Analysis Report

**Report Date:** March 30, 2026 (Rev. 3 — Updated with team responses)
**Scope:** SBI client (sub-sbi-uat), inc-np (sub-management), shared-services (prd & np)
**Cloud Provider:** Microsoft Azure
**Deployment Model:** Public Cloud
**Assessor:** Automated IaC + Live Azure Assessment
**Framework References:**
- SEBI CSCRF (Circular SEBI/HO/ITD-1/ITD_CSC_EXT/P/CIR/2024/113, August 20, 2024)
- SEBI Cloud Framework (Circular SEBI/HO/ITD/ITD_VAPT/P/CIR/2023/033, March 6, 2023)

### Operational Context (from infrastructure team)

The following operational context has been incorporated into this revision:

- **Centralized logging architecture:** A single Log Analytics workspace (`frc-log-management-01`) in France Central is used as a centralized SIEM with Microsoft Sentinel (17 data connectors active). This is a cost/management optimization.
- **External WAF/CDN:** An F5 WAF/CDN sits outside Azure and has network connectivity via Aviatrix. No services are directly internet-facing from Azure.
- **Aviatrix as firewall:** Aviatrix spoke gateways handle egress filtering and network segmentation, replacing Azure Firewall.
- **DDoS strategy:** DDoS Protection is applied at the F5/public IP level for services exposed through the external CDN.
- **No VMs in production:** No IaaS VMs are deployed; Azure Bastion subnet is pre-provisioned but unused.
- **EPAC for Azure Policy:** Enterprise Policy as Code (EPAC) manages Azure Policy at the management group level, not at individual subscription level.
- **ACR strategy:** Client ACRs pull from a principal ACR on shared-services; content trust/soft-delete planned at the shared-services level.
- **PostgreSQL in PROD:** Uses ZRS for storage resilience; CMK planned for future enablement.
- **HSM requirement:** Client (SBI) requires private connectivity between their on-premise HSM and Azure Key Vault — under investigation.

---

## 1. Executive Summary

### RE Category Applicability

This report covers **all five RE categories** under the CSCRF graded approach. The infrastructure assessed serves multiple Amundi clients across Indian capital markets (SBI Mutual Fund being the primary client in scope). The controls assessment identifies which findings apply to which RE tier.

| RE Category | Applicable Standards | Mandatory Guidelines | Exemptions |
|-------------|---------------------|---------------------|------------|
| **MIIs** | All Part I standards | All Part II guidelines | None |
| **Qualified REs** | All Part I standards | All Part II guidelines | None |
| **Mid-size REs** | All except Table 26 exemptions | All except GV.OV.S4, ID.RA.S3, PR.DS.S5/S6, PR.IP.S16/S17, DE.DP.S4/S5, RS.MA.S5 | 9 standard exemptions |
| **Small-size REs** | All except Table 25 exemptions | Reduced set | 46 standard exemptions; must onboard Market SOC |
| **Self-certification REs** | All except Table 25 exemptions | Reduced set | 46 standard exemptions; exempt from CERT-In cyber audit; must onboard Market SOC |

### Overall Compliance Posture

| Domain | Score | Justification |
|--------|-------|---------------|
| **IaC-Assessable Controls** | **78%** | Strong encryption, network isolation, RBAC, Sentinel with 17 connectors, F5 WAF/CDN, Aviatrix FW. Main gaps: Defender Free tier, log retention, AKS diagnostics, backup deployment |
| **Requires Procedural Validation** | ~30 controls | Governance, training, incident response, BCP cannot be assessed via Terraform/Azure CLI |

### Finding Severity Summary

| Severity | Count | Description |
|----------|-------|-------------|
| **Critical** | 2 | Defender plans mostly Free tier (pricing TBC); Log retention insufficient for regulatory compliance |
| **High** | 5 | No AKS diagnostic settings; Backup vault ready but not enabled; SBOM not generated; Encryption opt-out flags in module; Network Watcher storage accounts public |
| **Medium** | 6 | No PIM/Conditional Access visible; Standard SKU KVs; Single subscription PRD+NP (management); NSG flow log retention 30 days; No container image scanning; No API rate limiting |
| **Low** | 3 | frc-rg defaults on Central India; Sentinel CMK not configured; No resource locks |
| **Accepted/Mitigated** | 7 | Items from prior report now re-classified due to operational context (see Section 4) |

### Top 3 Regulatory Risks

1. **Microsoft Defender for Cloud is on Free tier for VMs, SQL, Storage, AKS, Containers, and AppServices across ALL subscriptions** — CSCRF DE.CM requires continuous security monitoring and vulnerability detection; Free tier provides only basic recommendations without runtime threat protection. *Team response: Pricing to be checked. Note: Defender for Containers and Sysdig are similar — need to clarify with security team.*

2. **Log Analytics retention is 90 days; CSCRF requires minimum 365 days for audit trails** — DE.CM.S1 and PR.AA.S8/S9 require comprehensive log retention. Current 90-day Sentinel retention loses audit evidence. *Team response: 2 options — increase LA retention directly or use Log Analytics archive feature.*

3. **AKS clusters have no diagnostic settings configured** — kube-audit, kube-apiserver, and guard logs are not being captured, creating a blind spot for Kubernetes-level security events despite Sentinel being active. *Team response: Cost to calculate, especially region-specific law implications.*

---

## 2. CSCRF Compliance Matrix

### 2.1 GOVERNANCE (GV) — Cyber Resilience Goal: ANTICIPATE

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| GV.OC.S1 | Organizational context: cybersecurity roles aligned | All REs except small/self-cert | Not Assessable via IaC | **Requires Documentation from security** | Requires board-approved cyber resilience policy document | N/A | Document and get Board approval |
| GV.OC.S2 | Compliance with IT Act, DPDP Act, SEBI circulars | All REs (Mandatory) | Partial | **To be assessed** | EPAC exists but SEBI-specific compliance policies should be verified at management group level | Low | Verify EPAC policy set includes SEBI CSCRF-relevant policies |
| GV.OC.S3 | SEBI/govt audit and inspection rights | All REs except small/self-cert | Not Assessable via IaC | **To be assessed** | Must be in CSP agreement | N/A | Verify Microsoft EA/MCA includes SEBI audit rights |
| GV.RR.S1 | Cybersecurity roles established | All REs except small/self-cert | Partial | **Requires Documentation from security** | Organizational RACI not assessable via IaC | Low | Document RACI mapping Azure RBAC groups to CSCRF responsibilities |
| GV.RR.S3 | CISO designated | MIIs, Qualified (Mandatory) | Not Assessable via IaC | **Requires Documentation from security** | Cannot verify CISO appointment via IaC | N/A | Confirm CISO appointment and reporting structure |
| GV.PO.S1 | Board-approved cybersecurity policy | All REs | Not Assessable via IaC | **Requires Documentation from security** | Requires documented policy | N/A | Create and get Board approval |
| GV.OV.S3 | Performance evaluation of cybersecurity controls | All REs | Partial | **Begin by controlling current state first, then elaborate strategy. Finally, create documentation to define SLAs for alert triage and response** | Alerts exist; documented SLA for review/response needed | Medium | Define SLAs for alert triage and response |
| GV.RM.S1 | Cyber risk management framework | MIIs, Qualified, Mid-size | Not Assessable via IaC | **Requires Documentation** | Risk register and framework needed | N/A | Create cyber risk management framework |
| GV.SC.S1 | Supply chain risk management | All REs except small/self-cert | Partial | **Related to SBOM — to be delegated to CICD or dev teams** | No SBOM generation visible | High | Implement SBOM generation in CI/CD |
| GV.SC.S7 | SBOM maintained | All REs | Non-Compliant | **Related to SBOM — to be delegated to CICD or dev teams** | CSCRF explicitly mandates SBOM | High | Implement SBOM using `syft` or `cyclonedx` in Jenkins pipeline |

### 2.2 IDENTIFY (ID) — Cyber Resilience Goal: ANTICIPATE

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| ID.AM.S1 | Critical systems identified and classified | All REs | Partial | **Jira Task to create: Add new tag criticality 1,2,3,4 levels like: low, medium, high, critical** | No formal criticality classification tag | Medium | Add `criticality` tag to all resources |
| ID.AM.S2 | IT asset inventory maintained | All REs except small/self-cert | Compliant | N/A | IaC serves as asset inventory | N/A | N/A |
| ID.RA.S1 | Periodic risk assessment | All REs | Partial | **To be assessed** | Full CSPM requires Defender paid tier upgrade | High | Enable Defender CSPM paid tier |
| ID.RA.S2 | Threat intelligence integrated | All REs | Compliant | N/A | Sentinel threat intelligence active | N/A | Verify threat intelligence feeds include CERT-In advisories |

### 2.3 PROTECT (PR) — Cyber Resilience Goal: ANTICIPATE

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| PR.AA.S1 | Identities and credentials managed | All REs | Compliant | N/A | N/A | N/A | N/A |
| PR.AA.S2 | Network integrity (segmentation) | All REs | Compliant | N/A | Well-implemented segmentation with defense-in-depth | N/A | N/A |
| PR.AA.S3 | Least privilege and segregation of duties | All REs | Compliant | N/A | Granular scoping implemented | N/A | N/A |
| PR.AA.S4 | Zero Trust model | All REs except small/self-cert | Partial | **Implemented at AD level. For our use case it needs to be assessed** | No PIM (Privileged Identity Management) or Conditional Access visible in IaC | Medium | Implement Azure AD PIM and Conditional Access |
| PR.AA.S8 | Comprehensive log management policy | All REs | Non-Compliant | **To be assessed** | **Retention only 90 days — CSCRF requires minimum 365 days.** | **Critical** | Increase LA retention to 365 days OR configure Log Analytics data export/archive |
| PR.AA.S9 | User logs uniquely identified | All REs | Compliant | N/A | Comprehensive user activity logging | N/A | N/A |
| PR.AA.S15 | Access control for APIs, endpoints | All REs except small/self-cert | Partial | **Fun question - To be assessed** | No Azure API Management for internal API rate limiting | Low | Evaluate if internal API rate limiting is needed |
| PR.DS.S1 | Data at rest encrypted (AES-256+) | All REs except small/self-cert | Compliant | **Jira Task to create** — Compliant but still items to track down | PostgreSQL CMK planned but not yet active — Azure-managed encryption (AES-256) is compliant as baseline | Low | Enable PostgreSQL CMK when ready (planned) |
| PR.DS.S2 | Data in transit encrypted (TLS 1.2+) | All REs | Compliant | N/A | TLS 1.2+ enforced everywhere | N/A | N/A |
| PR.DS.S5 | Dev/test separated from production | All REs except mid/small/self-cert | Partial | **To be assessed — Already some separation but might not be enough** | Management PRD workloads are minimal (DevOps only); acceptable if documented | Low | Document that management PRD contains only Azure DevOps configuration, no regulatory data |
| PR.IP.S1 | Baseline security configuration | All REs | Compliant | N/A | IaC + EPAC provides baseline enforcement | N/A | N/A |
| PR.IP.S7 | Backup and recovery plan documented | All REs | Partial | **Jira task to create: Finish the topic** — Options: daily/1 week in PostgreSQL OR Azure Backup for 1 year (in the region, not in our subscription) | **Backup vault not deployed in SBI-UAT.** Azure built-in PostgreSQL backup provides 7 days but SEBI may require longer | High | Deploy backup vault with 90-day retention. Consider Azure Backup for 1-year retention |
| PR.IP.S13 | Cloud Framework compliance (Annexure-J) | All REs | Partial | **To be assessed** | Multiple cloud-specific items addressed | Medium | Address remaining Cloud Framework gaps per Section 3 |
| PR.MA.S3 | Patches categorized and tested | All REs | Compliant | **Citrix/AAD for OS. AKS: there should already be an existing ticket in the board for Azure Linux OS** | No VMs = no VM patching gap | N/A | N/A |

### 2.4 DETECT (DE) — Cyber Resilience Goal: ANTICIPATE

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| DE.CM.S1 | SOC established (24x7x365) | All REs | Partial | **Requires Documentation from security with SOC process and 24/7 monitoring** | Sentinel serves as SIEM/SOC platform. SOC operational procedures and 24x7 monitoring SOP needed | Medium | Document SOC operational procedures; define 24x7 monitoring model |
| DE.CM.S2 | Continuous monitoring mechanisms | All REs | Partial | N/A | **Flow log retention 30 days (should be 90+).** | Medium | Increase flow log retention to 90 days |
| DE.CM.S4 | Capacity monitoring for critical systems | All REs except small/self-cert | Partial | **Jira to create: capacity alert postgresql** | No database capacity alerts | Medium | Add PostgreSQL capacity alerts (storage %, CPU, connections) |
| DE.CM.S5 | Cybersecurity audit, VAPT, vulnerability detection | All REs | Non-Compliant | **To be assessed — Pricing to consider - Defender. Note: Defender for Container and Sysdig are pretty much the same — need to ask security team** | **No runtime threat protection.** | **Critical** | Enable Defender Standard tier on all resource types |
| DE.DP.S5 | Threat hunting and compromise assessment | All REs except small/self-cert | Partial | **To be assessed — Security team should be involved** | Sentinel deployed and connected; hunting queries should be configured | Low | Configure Sentinel analytics rules and hunting queries |

### 2.5 RESPOND (RS) — Cyber Resilience Goal: WITHSTAND & CONTAIN

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| RS.MA.S1 | CCMP documented with scenario-based SOPs | All REs | Not Assessable via IaC | **To be delegated to security team. Question: What is CCMP?** | CCMP (Cyber Crisis Management Plan) required per Annexure-O | N/A | Create CCMP — Note: CCMP = Cyber Crisis Management Plan |
| RS.MA.S4 | Incidents contained and mitigated | All REs | Partial | **To be delegated to security team? Also: Jira ticket needed for Advanced networking AKS network policies via Cilium** | No automated containment playbooks visible | Medium | Create Sentinel automated response playbooks |
| RS.CO.S2 | Incidents reported to SEBI, CERT-In within 6 hours | All REs | Not Assessable via IaC | **Requires Documentation from security** | Reporting process needed. Email: mkt_incidents@sebi.gov.in | N/A | Document incident reporting procedure per Annexure-O |

### 2.6 RECOVER (RC) — Cyber Resilience Goal: RECOVER

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| RC.RP.S1 | Recovery plan with cyber-scenario classifications | All REs | Partial | **Recovery plan exists: https://confluence.intramundi.com/spaces/ITSPCI/pages/394195657/Multi-region+redundant+deployment — To be improved** | Backup strategy exists but not fully deployed. Recovery plan not documented | High | Deploy backup vault; improve existing recovery plan per Annexure-C |
| RC.RP.S2 | RTO/RPO mandated by SEBI | All REs | Partial | **Testing must be done in order to document and check requirement SEBI** | RTO/RPO targets not formally documented | High | Define and document RTO/RPO targets per SEBI requirements |
| RC.RP.S4 | Backup documented and tested | All REs | Partial | **Redundant backup topic / BCP / DR drills** | Retention and testing schedule needed | Medium | Set minimum 90-day retention; schedule quarterly restoration drills |

### 2.7 EVOLVE (EV) — Cyber Resilience Goal: EVOLVE

| CSCRF Ref | Standard / Guideline | Mandatory? | Status | Team Response | Gap | Severity | Remediation |
|-----------|---------------------|------------|--------|---------------|-----|----------|-------------|
| EV.ST.S1 | Strategies to anticipate new attack vectors | All REs except small/self-cert | Partial | **Annual threat modeling? To be delegated to security team?** | No formal threat modeling documented | Medium | Conduct annual threat modeling |
| EV.ST.S2 | Heterogeneity to minimize common failures | All REs except small/self-cert | Partial | **To be assessed — High level design multi cloud strat. No documented exit strategy / data portability plan** | Single cloud provider concentration risk | Low | Document multi-cloud assessment per Cloud Framework Principle 9 |

---

## 3. Cloud Framework Compliance (SEBI Circular March 6, 2023 / Annexure-J)

| Cloud Framework Ref | Requirement | Status | Team Response | Gap | Remediation |
|---------------------|-------------|--------|---------------|-----|-------------|
| **Principle 2: CSP Selection** | MeitY-empanelled CSP with STQC audit | Compliant | N/A | N/A | Maintain MeitY empanelment documentation |
| **Principle 3: Data Localization** | All data within India | Compliant (with documented exemption) | **Log Analytics in France Central: To be assessed** | Document exemption rationale | Create formal document citing CSCRF Box Item 10 exemption; get IT Committee and Board approval |
| **6.2.1: Vulnerability Management** | Vulnerability scanning and patching | Partial | **Pricing to consider - Defender** | No runtime vulnerability detection | Enable Defender paid plans |
| **6.2.3: SOC Integration** | SOC monitoring for cloud | Compliant | N/A | Well-integrated SOC | Verify all 17 connectors cover required data sources per CSCRF |
| **6.2.4: IAM** | Least privilege, MFA, PAM | Partial | **PR.AA.S4 at AD level — to be assessed** | No PIM visible. MFA at AAD tenant level | Implement PIM; verify MFA via Conditional Access |
| **6.2.5: Logging & Monitoring** | Comprehensive logging, adequate retention | Partial | **2 options: increase retention OR archive** | **Log retention 90 days (need 365+)** | Archive to Storage Account or increase retention |
| **6.2.6: Application Security** | WAF, API gateways, zero trust | Compliant (with external controls) | **Documentation WAF and external F5 to be delegated to Network team. F5 logs are fed into Sentinel for access logs but not WAF** | WAF is external (F5) — document this in compliance evidence. **F5 WAF logs not in Sentinel** | Document F5 WAF architecture; **ensure F5 WAF logs (not just access logs) feed into Sentinel** |
| **6.2.9: Encryption & Key Management** | BYOK/BYOE; HSM | Partial | **Private access from client for HSM connectivity** | Standard SKU on client KVs (no HSM). Private HSM connectivity under investigation | Investigate Azure Dedicated HSM or Managed HSM; or ExpressRoute/VPN to client's on-prem HSM |
| **6.2.10: Endpoint Security** | Anti-virus, DLP | Partial | **Defender for Container and Sysdig are pretty much the same — need to ask security team** | Container runtime security needs Defender for Containers | Clarify Defender vs Sysdig overlap with security team |
| **6.2.11: Network Security** | Micro-segmentation, DDoS, CASB/SASE | Compliant (with external controls) | **DDoS protection for all Aviatrix gateways — to be assessed if required** | DDoS handled at F5/CDN layer for external traffic | Document F5 DDoS protection; assess Aviatrix gateway DDoS needs |
| **6.2.12: Backup & Recovery** | Backup policy, segregation, tested twice yearly | Partial | **Already OK, need to be enabled. Options: daily/1 week PostgreSQL OR Azure Backup 1 year** | Not yet deployed in SBI-UAT | Deploy and test backup strategy |
| **Principle 7: Contractual** | 20+ mandatory contract clauses | Not Assessable via IaC | **Review Microsoft EA/MCA against mandatory clauses — What are those clauses?** | Full contract review needed | Review Microsoft EA/MCA against mandatory clauses (see Annexure-K of SEBI Cloud Framework) |
| **Principle 8: BCP/DR** | BCP, DR drills, contingency | Partial | **RC.RP.S2: Testing must be done** | No documented BCP/DR drills | Create BCP; schedule DR drills |
| **Principle 9: Vendor Lock-in** | Concentration risk, data portability | Partial | **No documented exit strategy / data portability plan** | Single-cloud. No documented exit strategy | Document exit strategy and data portability plan |

---

## 4. Critical & High Findings (Updated with Team Responses)

### CRITICAL FINDINGS

**C1. Microsoft Defender for Cloud on Free Tier Across All Subscriptions**
- **CSCRF Ref:** DE.CM.S5, PR.IP.S12, Cloud Framework 6.2.1
- **Risk:** No runtime threat protection for SQL, Storage, Containers, AKS. Free tier only provides recommendations without active protection.
- **Evidence:** `az security pricing list` shows Free tier for all resource plans except KeyVaults/Discovery/FoundationalCspm across all 4 subscriptions.
- **Team Response:** **Pricing to be checked.** Note: Defender for Containers and Sysdig are similar — need to clarify with security team.
- **Remediation:** Add `azurerm_security_center_subscription_pricing` for each plan per subscription in Terraform. Clarify Defender vs Sysdig overlap.

**C2. Log Retention Insufficient for Regulatory Compliance (90 days)**
- **CSCRF Ref:** PR.AA.S8, DE.CM.S2, Cloud Framework 6.2.5
- **Risk:** Audit evidence lost after 90 days. SEBI requires minimum 365 days. NSG flow logs only 30 days.
- **Evidence:** `frc-log-management-01`: retention=90 days. Flow logs: 30-day retention.
- **Team Response:** **2 options: increase log retention OR Log Analytics archive**
- **Remediation:** Either:
  1. Increase Log Analytics retention to 365 days directly, OR
  2. Configure Log Analytics archive (data moves to low-cost archive tier after 90 days, retained up to 12 years, queryable via restore jobs)
- Increase NSG flow log retention to 90 days.

### HIGH FINDINGS

**H1. AKS Clusters Have No Diagnostic Settings**
- **CSCRF Ref:** DE.CM.S1, PR.AA.S8
- **Risk:** No kube-audit, kube-apiserver, guard, or cluster-autoscaler logs captured. Security events at the Kubernetes control plane level are invisible to Sentinel.
- **Team Response:** **Cost to calculate. Especially region-specific law implications.**
- **Recommended categories:**
  - **kube-audit-admin** (not full kube-audit) — ~90% less data
  - **guard** — Azure AD authentication events
  - **cluster-autoscaler** — scaling events (low volume)
- **Remediation:** Add `azurerm_monitor_diagnostic_setting` for AKS clusters. Calculate cost impact before implementation.

**H2. Backup Vault Not Deployed in SBI-UAT**
- **CSCRF Ref:** PR.IP.S7, RC.RP.S1, Cloud Framework 6.2.12
- **Risk:** PostgreSQL relies only on Azure built-in 7-day backup. No long-term backup vault.
- **Evidence:** `az dataprotection backup-vault list` returns empty for SBI-UAT.
- **Team Response:** **Already OK, need to be enabled.** Options:
  - Daily backup / 1 week retention in PostgreSQL native
  - Azure Backup for 1 year (in the region, not in our subscription)
- **Remediation:** Set `backup_creation = true` in SBI tfvars. Configure retention policy (1 year recommended for SEBI compliance).

**H3. SBOM Not Generated**
- **CSCRF Ref:** GV.SC.S7
- **Risk:** No Software Bill of Materials. Supply chain vulnerabilities untracked.
- **Evidence:** No SBOM generation in Jenkins pipeline or Terraform modules.
- **Team Response:** **Supply chain — see dev or CICD. To be delegated to CICD or dev teams.**
- **Remediation:** Add `syft` or `cyclonedx-cli` to Jenkins pipeline. Delegate to CICD/dev teams.

**H4. Encryption Opt-Out Flags Exist in Module**
- **CSCRF Ref:** PR.DS.S1
- **Risk:** `disable_container_aks_disk_encryption` and `disable_container_registry_encryption` allow clients to bypass encryption.
- **Team Response:** **Option available, but encryption is enabled.**
- **Remediation:** Remove flags or add Azure Policy guardrail via EPAC. Document that encryption is currently enabled on all deployments.

**H5. Network Watcher Storage Accounts Have Public Access**
- **CSCRF Ref:** PR.DS.S4
- **Risk:** 4 storage accounts for flow logs have `publicNetworkAccess: Enabled`.
- **Evidence:** `frcstonetwatch01`, `incstonetwatch01`, `eastonetwatch01`, `eus2stonetwatch01`.
- **Team Response:** **To be assessed but seems possible for Network Watcher**
- **Remediation:** Disable public access; use private endpoints.

### FINDINGS RE-CLASSIFIED (Accepted/Mitigated with Operational Context)

| Prior Finding | Prior Severity | New Status | Rationale |
|---------------|---------------|------------|-----------|
| **No WAF / No Application Gateway** | Critical | **Mitigated** | F5 WAF/CDN handles all external traffic. No services published to internet from Azure. F5 has network access via Aviatrix. **Note:** F5 access logs in Sentinel but WAF logs not yet — needs remediation |
| **No DDoS Protection Standard** | Critical | **Mitigated** | DDoS handled by F5/CDN at external layer. Azure basic DDoS on VNets. DDoS metric alerts configured. **Note:** DDoS for Aviatrix gateways to be assessed if required |
| **No Azure Firewall for Egress** | High | **Mitigated** | Aviatrix spoke gateways serve as firewall and egress control. Documented network architecture |
| **Key Vault Standard SKU (No HSM)** | High | **Accepted** (with caveat) | Standard SKU meets encryption requirements. HSM-backed keys not required for current use case. **However:** SBI client requires private HSM connectivity — under investigation |
| **No Azure Bastion** | High | **Not Applicable** | No IaaS VMs deployed. Bastion subnet pre-provisioned for future use. AKS managed via private cluster API and kubectl |
| **No Azure Policy Assignments in client subs** | High | **Mitigated** | **EPAC (Enterprise Policy as Code)** manages policy at management group level. Policies inherit to all subscriptions. Verify EPAC includes SEBI-relevant policies |
| **Container Registry soft-delete/trust policy disabled** | Medium | **Accepted** (with plan) | Client ACRs pull from principal ACR on shared-services. Team will activate soft-delete and content trust at shared-services ACR level. Acceptable if shared-services ACR is secured |

---

## 5. New Jira Tickets to Create

Based on team responses, the following Jira tickets need to be created:

| # | Ticket Summary | CSCRF Ref | Priority | Assignee |
|---|---------------|-----------|----------|----------|
| 1 | Add criticality tag (1-4 levels: low, medium, high, critical) to all Azure resources | ID.AM.S1 | Medium | DAT |
| 2 | Track down remaining PR.DS.S1 encryption items | PR.DS.S1 | Low | DAT |
| 3 | Finish backup topic — deploy backup vault with 1-year retention | PR.IP.S7 | High | DAT |
| 4 | Create PostgreSQL capacity alerts (storage %, CPU, connections) | DE.CM.S4 | Medium | DAT |
| 5 | Advanced networking AKS network policies via Cilium | RS.MA.S4 | Medium | DAT |
| 6 | Azure Linux OS ticket (check existing board for status) | PR.MA.S3 | Low | DAT |

---

## 6. Items Delegated to Other Teams

| Item | CSCRF Ref | Delegated To | Notes |
|------|-----------|--------------|-------|
| GV.OC.S1 — Organizational context documentation | GV.OC.S1 | Security | Requires board-approved policy |
| GV.RR.S1 — Cybersecurity roles documentation | GV.RR.S1 | Security | RACI mapping |
| GV.RR.S3 — CISO designation | GV.RR.S3 | Security | Appointment documentation |
| GV.PO.S1 — Board-approved cybersecurity policy | GV.PO.S1 | Security | Policy document |
| GV.RM.S1 — Cyber risk management framework | GV.RM.S1 | Security | Risk register |
| GV.SC.S1 & GV.SC.S7 — SBOM generation | GV.SC.S1, GV.SC.S7 | CICD / Dev teams | Implement in pipeline |
| DE.CM.S1 — SOC process and 24/7 monitoring | DE.CM.S1 | Security | SOC operational procedures |
| DE.DP.S5 — Threat hunting | DE.DP.S5 | Security | Sentinel analytics rules |
| RS.MA.S1 — CCMP (Cyber Crisis Management Plan) | RS.MA.S1 | Security | **CCMP = Cyber Crisis Management Plan** per Annexure-O |
| RS.MA.S4 — Incident containment playbooks | RS.MA.S4 | Security | Sentinel automated response |
| RS.CO.S2 — Incident reporting documentation | RS.CO.S2 | Security | SEBI/CERT-In reporting SOP |
| EV.ST.S1 — Annual threat modeling | EV.ST.S1 | Security | Threat modeling process |
| F5 WAF documentation | 6.2.6 | Network | Document F5 architecture; **ensure WAF logs (not just access logs) feed into Sentinel** |
| Defender vs Sysdig clarification | DE.CM.S5 | Security | Clarify overlap and coverage |
| DDoS for Aviatrix gateways | 6.2.11 | Network | Assess if required |

---

## 7. Controls Not Assessable via IaC

| CSCRF Ref | Control Description | Why Not Assessable | Recommended Validation Method |
|-----------|--------------------|--------------------|-------------------------------|
| GV.OC.S1 | Organizational context | Governance structure | Board resolution and policy review |
| GV.PO.S1 | Board-approved cybersecurity policy | Policy document | Document review and Board minutes |
| GV.OV.S1-S4 | Board oversight, CCI assessment | Governance process | IT Committee minutes, CCI audit report |
| GV.RM.S1-S4 | Risk management framework | Process | Risk register review |
| GV.RR.S3 | CISO designation | Organizational | CISO appointment letter |
| PR.AT.S1-S5 | Cybersecurity awareness/training | HR process | Training records |
| PR.AA.S5-S7 | Access reviews, MFA enforcement | Azure AD tenant-level | Conditional Access policy review |
| PR.AA.S10 | Physical security | CSP responsibility | Microsoft SOC 2 Type II report |
| PR.IP.S8 | Backup drills | Operational | Drill reports |
| PR.IP.S14 | CERT-In empanelled auditor | Procurement | Engagement letter |
| PR.IP.S16 | ISO 27001 certification | Certification | Certificate verification |
| DE.DP.S1-S5 | Detection roles, playbooks, red teaming | SOC operations | Playbook docs, red team reports |
| RS.MA.S1-S5 | CCMP, incident response | Process | CCMP document, CSK registration |
| RS.CO.S1-S2 | Incident reporting to SEBI/CERT-In | Process | Reporting SOP |
| RC.RP.S3 | DR drills | Operational | Drill reports |
| **Cloud Framework** | Contractual obligations (Principle 7) | Legal | Microsoft EA/MCA contract review — **mandatory clauses are in Annexure-K of SEBI Cloud Framework** |
| **Cloud Framework** | Exit strategy (Principle 9) | Strategic | Documented exit plan |

---

## 8. Remediation Roadmap

### Immediate (0-30 days) — Critical Gaps

| # | Action | CSCRF Ref | Owner | Status |
|---|--------|-----------|-------|--------|
| 1 | **Enable Defender for Cloud Standard tier** — pricing to be checked first. Clarify Defender vs Sysdig overlap | DE.CM.S5 | Cloud Security / DAT | Pricing TBC |
| 2 | **Configure Log Analytics retention/archive** for 365-day retention | PR.AA.S8 | DAT | 2 options identified |
| 3 | **Add AKS diagnostic settings** — calculate cost first, especially region-specific implications | DE.CM.S1 | DAT | Cost TBC |
| 4 | **Deploy backup vault in SBI-UAT** — already OK, just needs to be enabled | PR.IP.S7 | DAT | Ready to enable |
| 5 | **Increase NSG flow log retention** to 90 days | DE.CM.S2 | Network / DAT | Planned |

### Short-term (30-90 days) — High-Priority Items

| # | Action | CSCRF Ref | Owner | Status |
|---|--------|-----------|-------|--------|
| 6 | **Implement SBOM generation** in Jenkins pipeline | GV.SC.S7 | DevOps / CICD | Delegated |
| 7 | **Document encryption opt-out flags** — encryption is enabled, document current state | PR.DS.S1 | DAT | Option available |
| 8 | **Disable public access on Network Watcher storage accounts** | PR.DS.S4 | Network / DAT | Seems possible |
| 9 | **Document F5 WAF/Aviatrix architecture** — ensure F5 WAF logs (not just access logs) feed into Sentinel | Cloud 6.2.6, 6.2.11 | Network | Delegated |
| 10 | **Document CSCRF Box Item 10 exemption** for France Central Log Analytics | Cloud Principle 3 | CISO / Legal | To be assessed |
| 11 | **Verify EPAC policy set** includes SEBI CSCRF-relevant policies | GV.OC.S2 | Governance / DAT | To be assessed |
| 12 | **Create CCMP and incident response SOP** per Annexure-O | RS.MA.S1 | Security | Delegated |
| 13 | **Investigate SBI HSM private connectivity** | Cloud 6.2.9 | Network / Security | Under investigation |
| 14 | **Add criticality tags** (1-4 levels) to all resources | ID.AM.S1 | DAT | Jira ticket |

### Medium-term (90-180 days) — Enhancements and Hardening

| # | Action | CSCRF Ref | Owner | Status |
|---|--------|-----------|-------|--------|
| 15 | **Implement Azure AD PIM** — already at AD level, assess for our use case | PR.AA.S4 | Identity / Security | To be assessed |
| 16 | **Configure Sentinel hunting queries** | DE.DP.S5 | SOC / Security | Delegated |
| 17 | **Assess DDoS for Aviatrix gateways** | Cloud 6.2.11 | Network | To be assessed |
| 18 | **Conduct VAPT** per Annexure-L scope | DE.CM.S5 | Security / External auditor | Planned |
| 19 | **Improve BCP/DR plan** — existing plan at Confluence, needs improvement | RC.RP.S1-S4 | CISO / Operations | Testing required |
| 20 | **Conduct DR drill** and document results | RC.RP.S3 | Operations / DAT | Testing required |
| 21 | **Engage CERT-In empanelled auditor** | PR.IP.S14 | CISO / Compliance | Planned |
| 22 | **Document cloud exit strategy** | Cloud Principle 9 | CTO / CISO | Not documented |
| 23 | **Review Microsoft EA/MCA** against 20+ mandatory clauses (Annexure-K) | Cloud Principle 7 | Legal | What are those clauses? |
| 24 | **Annual threat modeling** | EV.ST.S1 | Security | Delegated |

---

## Appendix A: Azure Live State Summary

### Defender for Cloud Status (All Subscriptions)

| Plan | SBI-UAT | Management | SS-PRD | SS-NP | Required? |
|------|---------|------------|--------|-------|-----------|
| VirtualMachines | **Free** | **Free** | **Free** | **Free** | Yes (if VMs exist) |
| SqlServers | **Free** | **Free** | **Free** | **Free** | Yes |
| AppServices | **Free** | **Free** | **Free** | **Free** | Yes (if App Services) |
| StorageAccounts | **Free** | **Free** | **Free** | **Free** | Yes |
| KubernetesService | **Free** | **Free** | **Free** | **Free** | Yes |
| ContainerRegistry | **Free** | **Free** | **Free** | **Free** | Yes |
| Containers | **Free** | **Free** | **Free** | **Free** | Yes — **Note: similar to Sysdig, clarify overlap** |
| OpenSourceRelationalDatabases | **Free** | **Free** | **Free** | **Free** | Yes |
| KeyVaults | Standard | Standard | Standard | Standard | Already enabled |
| Discovery | Standard | Standard | Standard | Standard | Already enabled |
| FoundationalCspm | Standard | Standard | Standard | Standard | Already enabled |

### Key Architecture Decisions (for SEBI Audit Evidence)

| Decision | Rationale | CSCRF Compliance Impact | Team Notes |
|----------|-----------|------------------------|------------|
| Centralized Log Analytics in France Central | Cost optimization, centralized SIEM with Sentinel | Permissible under CSCRF Box Item 10 exemption for IT/Cybersecurity Data | To be assessed |
| F5 WAF/CDN (external to Azure) | No direct internet publishing from Azure | Compensating control for Cloud Framework 6.2.6 — document architecture | **Access logs in Sentinel, WAF logs NOT yet** |
| Aviatrix instead of Azure Firewall | Enterprise-grade network segmentation and transit | Equivalent functionality — document in network security evidence | DDoS for Aviatrix to be assessed |
| No Azure Bastion | No IaaS VMs deployed | Not applicable — Bastion subnet pre-provisioned for future use | N/A |
| EPAC for Azure Policy | Management group level enforcement | Policies inherited by all subscriptions — verify SEBI-relevant policies included | To be assessed |
| Standard SKU Key Vaults | HSM not needed for current operations | Acceptable; Premium exists on shared-services. | SBI HSM connectivity under investigation |
| Defender vs Sysdig | Container security options | Both provide container runtime security | Need to clarify overlap with security team |

---

*Report generated from Terraform codebase analysis + Azure CLI live state assessment. Rev. 3 incorporates team responses from assessment review. Controls marked "Not Assessable via IaC" require separate procedural/organizational validation. This report should be reviewed by the CISO and IT Committee before submission to SEBI auditors.*
