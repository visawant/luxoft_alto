variable "subscription_id_client" {
  type        = string
  description = "value of the subscription ID for the Client subscription"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_client))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "project_name" {
  description = "Project name used by our Cloud naming convention: https://confluence.intramundi.com/display/ITSPCI/Cloud+naming+convention"
  type        = string
  validation {
    condition     = length(var.project_name) <= 15
    error_message = "Project name is too long. Max length is 15 characters.."
  }
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  validation {
    condition     = length(var.environment) <= 3 && contains(["dmo", "tst", "rct", "dev", "ppr", "uat", "np", "prd"], var.environment)
    error_message = "Valid value is one of the following: dmo, tst, rct, ppr, dev, uat, np, prd."
  }
}

variable "ops_team" {
  description = "Team accountable for day-to-day operations."
  type        = string
  validation {
    condition     = length(var.ops_team) <= 15 && can(regex("^[a-zA-Z0-9-]*$", var.ops_team))
    error_message = "The ops_team name must be less than 15 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "it_owner" {
  description = "Top-level division of your company that owns the subscription or workload that the resource belongs to. In smaller organizations, this tag might represent a single corporate or shared top-level organizational element."
  type        = string
  validation {
    condition     = length(var.it_owner) <= 100 && can(regex("^[a-zA-Z0-9-@.]*$", var.it_owner))
    error_message = "The it_owner name must be less than 15 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "region" {
  description = "Azure region"
  type        = string
  default     = "Central India"
}

##############################################
###### artifact store
##############################################
variable "ARTIFACT_URL" {
  description = "Artifact store URL"
  type        = string
  default     = "oci://helm-virtual-oci.intramundi.com"
}

variable "ARTIFACT_USERNAME" {
  description = "Artifact store username"
  type        = string
  sensitive   = true
}

variable "ARTIFACT_PASSWORD" {
  description = "Artifact store password"
  type        = string
  sensitive   = true
}

## Aviatrix related config
variable "CONTROLLER_PUBLIC_IP" {
  type        = string
  description = "Controller public IP"
}

variable "CONTROLLER_USERNAME" {
  type        = string
  description = "Controller username"
}

variable "CONTROLLER_PASSWORD" {
  description = "Controller password"
  type        = string
}

variable "AD_SP_AVIATRIX_DAT_APP_ID" {
  type        = string
  description = "AAD Aviatrix DAT account App ID"
}

variable "AD_SP_AVIATRIX_DAT_SECRET" {
  description = "AAD Aviatrix DAT account secret"
  type        = string
}

variable "VAULT_LOGIN_SECRET_IDS" {
  description = "HashiCorp Vault AppRole secret IDs per environment"
  type        = map(string)
  default     = {}
}

##############################################
###### azure devops area specifications
##############################################
variable "ADO_ARM_CLIENT_ID" {
  type        = string
  description = "Client id of the service principal that will connect to Azure DevOps"
}

variable "ADO_ARM_CLIENT_SECRET" {
  description = "Client secret of the service principal that will connect to Azure DevOps"
  type        = string
}

variable "ADO_SYNC_REPO_USERNAME" {
  type        = string
  description = "Azure DevOps username used to sync repos"
}

variable "ADO_SYNC_REPO_PAT" {
  description = "Azure DevOps PAT used to sync repos"
  type        = string
}

variable "azure_devops_creation" {
  description = "Create a Azure DevOps area"
  type        = bool
  default     = true
}

variable "azure_devops" {
  description = "Azure DevOps specifications"
  default = {
    "01" = {
      amundi_products = ["alto-invest"]
      group_membership = {
        "01" = {}
      }
    }
  }
}

##############################################
###### connectivity area specifications
##############################################
variable "virtual_network_creation" {
  description = "Create a Virtual Network"
  type        = bool
  default     = true
}

variable "bastion_creation" {
  description = "Create a Bastion"
  type        = bool
  default     = true
}

variable "bastion_sku" {
  description = "Bastion SKU"
  type        = string
  validation {
    condition     = contains(["Standard", "Developer"], var.bastion_sku)
    error_message = "Valid value is one of the following: Standard, Developer."
  }
  default = "Standard" // The "Developer" role doesn't permit to work on multiple vm, need for the Citrix team
}

variable "bastion_default_specification" {
  description = "Bastion default specifications per SKU"
  type        = any
  default = {
    Developer = {
      zones = []
    }
    Standard = {
      zones                  = ["1", "2", "3"]
      copy_paste_enabled     = true
      file_copy_enabled      = false
      ip_connect_enabled     = false
      scale_units            = 2
      shareable_link_enabled = true
      tunneling_enabled      = false
      kerberos_enabled       = false
    }
  }
}

##############################################
###### container area specifications
##############################################
variable "container_creation" {
  description = "Create the container platform"
  type        = bool
  default     = true
}

variable "container_default_specification" {
  description = "Default specifications for the container platform"
  type        = any
  default     = {}
}

variable "disable_container_aks_disk_encryption" {
  description = "Legacy option for unencrypted AKS, as mentioned in the following documentation we can currently enable a customer-managed key only while creating an AKS cluster registry https://learn.microsoft.com/en-us/azure/aks/azure-disk-customer-managed-keys?WT.mc_id=AZ-MVP-5003548"
  type        = bool
  default     = false
}

##############################################
###### database area specifications
##############################################
variable "database_creation" {
  description = "Create the database platform"
  type        = bool
  default     = true
}

variable "database_default_specification" {
  description = "Default specifications for the database platform"
  type        = any
  default     = {}
}

##############################################
###### dns area specifications
##############################################
variable "dns_creation" {
  description = "Create a DNS area"
  type        = bool
  default     = true
}

variable "dns_records" {
  description = "DNS records to create"
  type = object({
    traefik_private_endpoint_cname_record = map(object({
      dns_suffixes = list(string)
    }))
  })
  default = {
    traefik_private_endpoint_cname_record = {
      "01" = {
        dns_suffixes = [ // Will be prefixed by the env name for non prod env, sample: uat-inc-sbi.azure.intramundi.com
          "inc-sbi",
          "alto-sbi",
          "alto-sbi-reporting"
        ]
      }
    }
  }
}

variable "dns_records_http_probe_customization" {
  description = "Custom specification for the http probe based on the dns_records keys"
  type = object({
    traefik_private_endpoint_cname_record = optional(map(object({
      container_aks_key = optional(string, "01")
      tags = optional(object({
        probeUriPrefixPath         = optional(string, "https://")
        probeUriSuffixPath         = optional(string, "/")
        probeSuccessHttpStatusCode = optional(string, "200")
      }), {})
    })), {})
  })
  default = {
    traefik_private_endpoint_cname_record = {
      "sso-sbi" = {
        tags = {
          probeUriSuffixPath = "/auth"
        }
      }
      "alto-sbi" = {
        tags = {
          probeUriSuffixPath = "/confidentiality"
        }
      }
    }
  }
}

##############################################
###### private link area specifications
##############################################
variable "private_link_creation" {
  description = "Create the Private Link area"
  type        = bool
  default     = true
}

##############################################
###### shared services area specifications
##############################################
variable "shared_services_creation" {
  description = "Create the shared services area with an Azure Key Vaults"
  type        = bool
  default     = true
}


variable "shared_services_storage_account" {
  description = "Storage account specifications"
  type        = any
  default     = {}
}

variable "shared_services_aad_application" {
  description = "Entra ID application/service principal to create"
  type = map(object({
    display_name  = string
    owners        = optional(list(string), null)
    description   = string
    key_vault_key = string
    secret = object({
      name                  = string
      days_to_expire        = optional(number, 90)
      version               = optional(string, null)
      role_assignment_scope = optional(list(string), [])
      content_type          = optional(string, "secret")
      hashicorp_vault = optional(object({
        app_trigram = string
        mount       = optional(string, "corporate_kv2_shared")
        namespace   = optional(string, "tenant_corporate")
        component   = optional(string, "common")
      }), null)
    })
  }))
  default  = {}
  nullable = true
}

##############################################
###### vm area specifications
##############################################
variable "iaas_creation" {
  description = "Create the shared services area"
  type        = bool
  default     = false
}
variable "iaas_vm" {
  description = "Custom iaas vm"
  type        = any
  default     = {}
}

##############################################
###### aks workload identity specifications
##############################################
variable "container_aks_workload_identity" {
  description = "Microsoft Entra Workload ID with Azure Kubernetes Service (AKS)"
  type        = any
  default     = {}
}
