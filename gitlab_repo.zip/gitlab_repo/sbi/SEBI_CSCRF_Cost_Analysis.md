# SEBI CSCRF Remediation — Cost Analysis

**Date:** March 25, 2026
**Scope:** All 4 subscriptions (SBI-UAT, Management, SS-PRD, SS-NP)
**Pricing Region:** Central India / France Central (Log Analytics)
**Currency:** EUR/month (annual estimates included)
**Exchange Rate:** 1 USD = 0.86 EUR (Q1 2026)

> **Disclaimer:** All costs are estimates based on Azure public pricing as of Q1 2026, converted to EUR. Actual costs depend on resource count, data volumes, and commitment tier discounts. Prices exclude applicable taxes and EA/MCA negotiated discounts.

---

## 1. Cost Summary

| Category | Monthly Estimate (Low) | Monthly Estimate (High) | Annual Estimate (Low) | Annual Estimate (High) |
|----------|----------------------|------------------------|---------------------|----------------------|
| **C1. Defender for Cloud** | 301 | 731 | 3,612 | 8,772 |
| **C2. Log Retention (365d)** | 215 | 602 | 2,580 | 7,224 |
| **H1. AKS Diagnostic Settings** | 129 | 430 | 1,548 | 5,160 |
| **H2. Backup Vault** | 43 | 129 | 516 | 1,548 |
| **H3. SBOM Generation** | 0 | 0 | 0 | 0 |
| **H4. Encryption Opt-Out Flags** | 0 | 0 | 0 | 0 |
| **H5. Network Watcher Private Access** | 17 | 43 | 206 | 516 |
| **NSG Flow Logs (90d retention)** | 26 | 69 | 310 | 826 |
| **TOTAL** | **731** | **2,004** | **8,772** | **24,046** |

**Best estimate (mid-range): ~1,290 EUR/month (~15,480 EUR/year)**

---

## 2. Detailed Cost Breakdown

### C1. Microsoft Defender for Cloud — Standard Tier

Enabling Defender across all 4 subscriptions. Pricing is per-resource, per-month.

| Defender Plan | Unit Price | Resources (Est.) | Subs | Monthly Cost | Notes |
|--------------|-----------|------------------|------|-------------|-------|
| **Defender for Servers P1** | 4.30 EUR/server/mo | 0 | 4 | **0 EUR** | No IaaS VMs deployed. P1 recommended over P2 (no VMs = no agent needed). Enable for coverage if VMs are added later |
| **Defender for SQL** | 12.90 EUR/instance/mo | 2-4 MSSQL instances | 2 | **26 – 52 EUR** | Only charged for subscriptions with SQL resources |
| **Defender for OSRDB** | 12.90 EUR/instance/mo | 2-4 PostgreSQL instances | 2 | **26 – 52 EUR** | PostgreSQL flexible servers in SBI + shared-services |
| **Defender for Storage** | 8.60 EUR/storage acct/mo (per-transaction plan) | 10-20 storage accounts | 4 | **86 – 172 EUR** | Per-transaction plan (0.13 EUR/10K transactions) may be cheaper for low-activity accounts. Estimate assumes flat rate |
| **Defender for Containers** | 6.02 EUR/vCore/mo | 8-24 vCores (AKS nodes) | 2 | **48 – 144 EUR** | Based on 2-6 nodes x 4 vCores. Only AKS subscriptions charged |
| **Defender for App Services** | 12.90 EUR/instance/mo | 0-2 | 1 | **0 – 26 EUR** | Only if App Services exist |
| **Defender for Container Registry** | Included in Containers | — | — | **0 EUR** | Merged into Defender for Containers plan |
| **Defender CSPM (full)** | 4.30 EUR/server/mo + 0.006 EUR/hr/billable resource | ~50 billable resources | 4 | **86 – 215 EUR** | Optional but recommended. Provides attack path analysis, cloud security graph |
| **KeyVaults** | Already Standard | — | — | **0 EUR** | Already enabled |
| **FoundationalCspm** | Already Standard | — | — | **0 EUR** | Already enabled |
| | | | **SUBTOTAL** | **301 – 731 EUR/mo** | |

**Cost optimization tips:**
- Use **per-transaction pricing** for Defender for Storage on low-activity accounts (~60% cheaper)
- Skip Defender for Servers if no VMs are planned (re-enable when VMs are deployed)
- Defender CSPM (full) is optional — FoundationalCspm (free) is already active. Full CSPM adds attack path analysis but costs more
- AKS node auto-scaling affects Containers cost — charged per vCore running

---

### C2. Log Retention Extension (90d to 365d)

Two options — both achieve 365-day retention. Can be combined.

#### Option A: Log Analytics Archive (Recommended)

Data stays in Log Analytics but moves to archive tier after 90 days. Queryable via restore jobs (takes minutes).

| Component | Unit Price | Volume (Est.) | Monthly Cost | Notes |
|-----------|-----------|---------------|-------------|-------|
| **Interactive retention (0-90d)** | Included in ingestion | — | **0 EUR** | Already paid via ingestion cost |
| **Archive retention (90-365d)** | 0.022 EUR/GB/mo | 1.5 – 4.5 TB archived | **32 – 96 EUR** | Based on 50-150 GB/day ingestion. Archive accumulates: month 4 has 3 months archived, etc. Steady state ~9 months of data in archive |
| **Restore jobs (on-demand)** | 0.108 EUR/GB restored | Occasional | **9 – 26 EUR** | Only when querying archived data for audits/investigations |
| | | **SUBTOTAL** | **40 – 122 EUR/mo** | Cheapest option. Recommended |

#### Option B: Data Export to Storage Account

Continuous export of log tables to a Storage Account. Data always accessible, no restore needed.

| Component | Unit Price | Volume (Est.) | Monthly Cost | Notes |
|-----------|-----------|---------------|-------------|-------|
| **Storage (Cool tier)** | 0.009 EUR/GB/mo | 4.5 – 13.5 TB (steady state at 365d) | **39 – 116 EUR** | Accumulates over 12 months. Cool tier for cost efficiency |
| **Write transactions** | 0.086 EUR/10K writes | ~1M writes/mo | **9 EUR** | Export creates blobs continuously |
| **Lifecycle management** | Free | — | **0 EUR** | Auto-delete after 365 days |
| **Data export rule** | Free | — | **0 EUR** | No charge for the export rule itself |
| | | **SUBTOTAL** | **47 – 125 EUR/mo** | More accessible but slightly more expensive |

#### Option C: Combined (Archive + Export for critical tables)

| Component | Monthly Cost | Notes |
|-----------|-------------|-------|
| Archive all tables | 32 – 96 EUR | Bulk retention at lowest cost |
| Export SecurityEvent + AzureActivity to Storage | 17 – 43 EUR | Critical audit tables always accessible |
| **SUBTOTAL** | **49 – 139 EUR/mo** | Best of both worlds |

**Recommendation:** Option A (Archive) for cost efficiency. Option C if auditors need instant access to security events without restore wait times.

**Additional consideration — current ingestion costs:**
The existing Log Analytics workspace (`frc-log-management-01`) has a 100GB/day cap. Current ingestion costs are likely:

| Ingestion Tier | Price/GB | At 50 GB/day | At 100 GB/day |
|---------------|---------|-------------|---------------|
| Pay-as-you-go | 3.96 EUR/GB (France Central) | 5,934 EUR/mo | 11,868 EUR/mo |
| Commitment 100GB/day | 3.16 EUR/GB | 4,747 EUR/mo | 9,494 EUR/mo |
| Commitment 200GB/day | 2.77 EUR/GB | — | 8,308 EUR/mo |

If not already on a commitment tier, switching to one could **save 860 – 3,440 EUR/month** — more than covering the archive/export cost.

---

### H1. AKS Diagnostic Settings

New log ingestion cost for AKS control plane logs routed to Log Analytics.

| Log Category | Volume/day (Est.) | Ingestion Cost/mo | Notes |
|-------------|------------------|-------------------|-------|
| **kube-audit-admin** | 5 – 15 GB/day | **103 – 387 EUR** | Write-only operations. ~90% less than full kube-audit. Volume depends on cluster activity |
| **guard** | 0.05 – 0.2 GB/day | **2 – 7 EUR** | AAD authentication events only. Very low volume |
| **cluster-autoscaler** | 0.01 – 0.1 GB/day | **1 – 3 EUR** | Scaling events. Minimal volume |
| | **SUBTOTAL** | **106 – 397 EUR/mo** | Per cluster. Multiply by number of AKS clusters |

**Assumptions:** 3.44 EUR/GB average ingestion (France Central, commitment tier). 1-2 AKS clusters total.

**Cost optimization tips:**
- Use **Resource-specific** destination mode (not AzureDiagnostics) — ~30% cheaper, better query performance
- Apply **Log Analytics transformation rules** to filter noisy events before ingestion (e.g., drop kube-system namespace events)
- Set **daily cap** on AKS diagnostic categories if cost is a concern (e.g., 10GB/day for kube-audit-admin)
- **Do NOT enable kube-audit** (full) — it generates 10-100x more data than kube-audit-admin with minimal additional security value
- Archive AKS logs after 30 days (shorter interactive retention) since they're primarily for incident investigation

**If cost is prohibitive**, minimum viable option:
- Enable only **guard** (~4 EUR/mo) for authentication audit trail
- Skip kube-audit-admin and rely on Sentinel alerts from other connectors
- This is a trade-off: satisfies SEBI auth logging requirement (PR.AA.S8) but leaves a gap in K8s mutation tracking

---

### H2. Backup Vault (SBI-UAT)

Azure Backup for PostgreSQL Flexible Server.

| Component | Unit Price | Resources | Monthly Cost | Notes |
|-----------|-----------|-----------|-------------|-------|
| **Protected instance fee** | 8.60 EUR/instance/mo | 1-2 PostgreSQL instances | **9 – 17 EUR** | Per database server backed up |
| **Backup storage (LRS)** | 0.043 EUR/GB/mo | 50 – 200 GB | **2 – 9 EUR** | Depends on DB size and retention. LRS sufficient for same-region |
| **Backup storage (GRS)** | 0.086 EUR/GB/mo | 50 – 200 GB | **4 – 17 EUR** | If cross-region redundancy required (recommended for DR) |
| **Point-in-time restore** | Included | — | 0 EUR | PostgreSQL built-in PITR (7-day, already active) |
| | | **SUBTOTAL** | **13 – 34 EUR/mo** | LRS: 13-26. GRS: 17-34 |

**90-day retention impact:** Backup storage accumulates. At 90-day retention with daily backups:
- Incremental backups: ~10-30% of full backup size per day
- Steady state storage: ~2-5x the database size
- For a 50GB database: ~100-250GB backup storage = **4-22 EUR/mo** (LRS)

**Full backup vault estimate: 43 – 129 EUR/mo** (including all PostgreSQL + optional blob/disk backup)

---

### H3. SBOM Generation — 0 EUR/month

| Component | Cost | Notes |
|-----------|------|-------|
| **Syft** (Anchore) | Free (open source) | CLI tool, runs in Jenkins pipeline |
| **CycloneDX CLI** | Free (open source) | Alternative SBOM generator |
| **Jenkins compute** | Negligible | ~30 seconds per build, existing runner |
| **Storage** | Negligible | SBOM JSON files are <1MB each |

Only cost is engineering time to integrate into Jenkins pipeline (~3 days).

---

### H4. Remove Encryption Opt-Out Flags — 0 EUR/month

Code change only. No Azure cost. Engineering effort: ~2 days.

If implementing via EPAC policy instead of code removal:
- Azure Policy: **Free** (built-in policies) or **0 EUR** (custom policy definitions are free)

---

### H5. Network Watcher Storage Accounts — Private Access

Disable public access and add private endpoints to 4 storage accounts.

| Component | Unit Price | Resources | Monthly Cost | Notes |
|-----------|-----------|-----------|-------------|-------|
| **Private Endpoint** | 0.009 EUR/hr (~6.28 EUR/mo) | 4 storage accounts | **17 – 26 EUR** | One PE per storage account. May share PE if in same VNet |
| **Private DNS Zone** | 0.43 EUR/zone/mo | 1 (shared) | **0.43 EUR** | `privatelink.blob.core.windows.net` — likely already exists |
| **Data processing** | 0.009 EUR/GB | Minimal | **1 – 4 EUR** | Flow log data is low volume |
| | | **SUBTOTAL** | **19 – 30 EUR/mo** | |

---

### NSG Flow Logs — 90-Day Retention

Increase from 30 to 90 days. Storage cost only (flow logs themselves are free with Network Watcher).

| Component | Unit Price | Volume (Est.) | Monthly Cost | Notes |
|-----------|-----------|---------------|-------------|-------|
| **Flow log storage (90d)** | 0.015 EUR/GB/mo (Hot) | 50 – 150 GB steady state | **1 – 3 EUR** | Flow logs are compact. 17 NSGs but most are low-traffic |
| **Additional 60 days storage** | — | +100 – 300 GB (delta from 30d to 90d) | **2 – 4 EUR** | Incremental cost over current 30d |
| **Traffic Analytics** (optional) | 0.43 EUR/NSG/mo + ingestion | 17 NSGs | **7 + ingestion** | Optional but recommended for security visibility |
| | | **SUBTOTAL** | **3 – 69 EUR/mo** | Without Traffic Analytics: ~3-7. With: ~26-69 |

---

## 3. Cost by Timeline Phase

### Phase 1: Immediate (0-30 days)

| # | Action | Monthly Cost | Annual Cost | One-Time Effort |
|---|--------|-------------|-------------|-----------------|
| 1 | Defender for Cloud Standard | 301 – 731 EUR | 3,612 – 8,772 EUR | 2 days eng |
| 2 | Log Analytics archive (365d) | 43 – 129 EUR | 516 – 1,548 EUR | 2 days eng |
| 3 | AKS diagnostic settings | 129 – 430 EUR | 1,548 – 5,160 EUR | 1 day eng |
| 4 | Backup vault (SBI-UAT) | 43 – 129 EUR | 516 – 1,548 EUR | 1 day eng |
| 5 | NSG flow logs 90d | 26 – 69 EUR | 310 – 826 EUR | 0.5 day eng |
| | **Phase 1 Total** | **542 – 1,488 EUR** | **6,502 – 17,854 EUR** | **6.5 days** |

### Phase 2: Short-term (30-90 days)

| # | Action | Monthly Cost | Annual Cost | One-Time Effort |
|---|--------|-------------|-------------|-----------------|
| 6 | SBOM generation | 0 EUR | 0 EUR | 3 days eng |
| 7 | Encryption opt-out flags | 0 EUR | 0 EUR | 2 days eng |
| 8 | Network Watcher private access | 19 – 30 EUR | 227 – 361 EUR | 1 day eng |
| 9 | Document F5/Aviatrix controls | 0 EUR | 0 EUR | 5 days (docs) |
| 10 | CSCRF Box Item 10 exemption doc | 0 EUR | 0 EUR | 3 days (legal) |
| 11 | Verify EPAC policies | 0 EUR | 0 EUR | 2 days eng |
| 12 | CCMP + incident SOP | 0 EUR | 0 EUR | 10 days (CISO) |
| 13 | HSM connectivity investigation | 0 – 1,720 EUR | 0 – 20,640 EUR | 10 days eng |
| 14 | ACR soft-delete (shared-svc) | 0 EUR | 0 EUR | 0.5 day eng |
| | **Phase 2 Total** | **19 – 1,750 EUR** | **227 – 21,001 EUR** | **36.5 days** |

> **Note on HSM:** If Azure Dedicated HSM is required, cost is ~4,128 EUR/month per HSM unit. Managed HSM is ~2.75 EUR/hr (~1,978 EUR/month). ExpressRoute to client's on-prem HSM uses existing connectivity (no additional Azure cost). This is the single most expensive potential item.

### Phase 3: Medium-term (90-180 days)

| # | Action | Monthly Cost | Annual Cost | One-Time Effort |
|---|--------|-------------|-------------|-----------------|
| 15 | Azure AD PIM | 0 EUR (included in P2) | 0 EUR | 10 days eng |
| 16 | Sentinel hunting queries | 0 EUR | 0 EUR | 10 days SOC |
| 17 | Data classification tags | 0 EUR | 0 EUR | 5 days eng |
| 18 | VAPT (external auditor) | — | 25,800 – 68,800 EUR | External |
| 19 | BCP/DR plan | 0 EUR | 0 EUR | 15 days (CISO) |
| 20 | First DR drill | 172 – 430 EUR | One-time | 5 days ops |
| 21 | CERT-In auditor | — | 17,200 – 43,000 EUR | External |
| 22 | Cloud exit strategy | 0 EUR | 0 EUR | 10 days (CTO) |
| 23 | PostgreSQL CMK | 0 – 3 EUR | 0 – 31 EUR | 1 day eng |
| 24 | Verify Sentinel connectors | 0 EUR | 0 EUR | 2 days eng |
| | **Phase 3 Total** | **172 – 433 EUR** | **43,000 – 111,831 EUR** | **58 days + external** |

> **Note:** VAPT and CERT-In auditor are external engagements with highly variable costs depending on scope and vendor. Estimates based on typical Indian market rates for SEBI-regulated entities.

---

## 4. Total Cost of Compliance

### Azure Infrastructure Cost (Recurring)

| | Monthly | Annual |
|--|---------|--------|
| **Low estimate** | 731 EUR | 8,772 EUR |
| **Mid estimate** | 1,290 EUR | 15,480 EUR |
| **High estimate** | 2,004 EUR | 24,046 EUR |

### External Engagements (One-Time)

| Engagement | Estimated Cost | Frequency |
|-----------|---------------|-----------|
| VAPT (Annexure-L scope) | 25,800 – 68,800 EUR | Annual |
| CERT-In empanelled auditor | 17,200 – 43,000 EUR | Annual |
| HSM solution (if Dedicated HSM) | 24,080 – 49,880 EUR/yr | Ongoing |
| **External Total** | **43,000 – 161,680 EUR/yr** | |

### Engineering Effort (Internal)

| Phase | Days | Assumed Rate (688 EUR/day) |
|-------|------|------------------------|
| Phase 1 (0-30d) | 6.5 days | 4,472 EUR |
| Phase 2 (30-90d) | 36.5 days | 25,112 EUR |
| Phase 3 (90-180d) | 58 days | 39,904 EUR |
| **Total** | **101 days** | **69,488 EUR** |

### Grand Total (Year 1)

| Component | Low | High |
|-----------|-----|------|
| Azure recurring (12 months) | 8,772 EUR | 24,046 EUR |
| External engagements | 43,000 EUR | 161,680 EUR |
| Internal engineering | 69,488 EUR | 69,488 EUR |
| **Year 1 Total** | **121,260 EUR** | **255,214 EUR** |
| **Year 2+ (recurring only)** | **51,772 EUR** | **185,726 EUR** |

---

## 5. Cost Optimization Recommendations

| # | Recommendation | Potential Savings |
|---|---------------|-------------------|
| 1 | **Switch Log Analytics to commitment tier** (100GB/day or 200GB/day) if not already | 860 – 3,440 EUR/mo |
| 2 | **Use per-transaction pricing** for Defender for Storage on low-activity accounts | ~43-86 EUR/mo |
| 3 | **Skip Defender for Servers** until VMs are deployed | ~0 EUR (already no VMs) |
| 4 | **Use Log Analytics Archive** instead of Storage export (Option A vs B) | ~17-43 EUR/mo |
| 5 | **Apply transformation rules** on AKS diagnostic logs to filter before ingestion | 30-50% reduction on H1 |
| 6 | **Use kube-audit-admin only** (not full kube-audit) | 90% reduction vs full audit |
| 7 | **Use LRS backup** instead of GRS if DR is handled at app level | ~9-17 EUR/mo |
| 8 | **Negotiate EA/MCA discount** with Microsoft for Defender bundle | 10-30% off list price |
| 9 | **Use Managed HSM** (1,978 EUR/mo) instead of Dedicated HSM (4,128 EUR/mo) if HSM is needed | 2,150 EUR/mo |
| 10 | **Combine VAPT + CERT-In audit** with same vendor if allowed | 8,600-17,200 EUR savings |

**Biggest cost lever:** Log Analytics commitment tier. If currently on pay-as-you-go with 50-100GB/day ingestion, switching to a commitment tier saves **more than the entire remediation cost**.

---

## 6. Cost vs Risk Matrix

| Finding | Monthly Cost to Fix | Risk if NOT Fixed | SEBI Penalty Risk |
|---------|-------------------|-------------------|-------------------|
| **C1. Defender Free tier** | 301 – 731 EUR | No runtime threat detection. Blind to active attacks | High — DE.CM.S5 is mandatory for all REs |
| **C2. Log retention 90d** | 43 – 129 EUR | Audit evidence lost. Cannot demonstrate compliance during inspection | Critical — PR.AA.S8 requires 365d minimum |
| **H1. AKS diagnostics** | 129 – 430 EUR | K8s control plane blind spot. Cannot investigate cluster compromises | High — Required for SOC visibility |
| **H2. Backup vault** | 43 – 129 EUR | 7-day backup only. Extended outage = data loss beyond 7 days | High — RC.RP.S1 requires documented backup |
| **H3. SBOM** | 0 EUR | Supply chain vulnerabilities untracked | Medium — GV.SC.S7 explicitly mandates SBOM |
| **H5. NetWatch public** | 19 – 30 EUR | Flow log data accessible from internet | Medium — PR.DS.S4 data protection |
| **NSG flow logs 90d** | 3 – 69 EUR | Network forensics limited to 30 days | Medium — DE.CM.S2 continuous monitoring |

**Best value for money:** C2 (log archive) at 43-129 EUR/mo eliminates the single highest regulatory risk. H3 (SBOM) is free and closes a mandatory SEBI control.

---

*Prices based on Azure public pricing (Central India / France Central regions) converted at 1 USD = 0.86 EUR. Actual costs may vary based on EA/MCA negotiated rates, resource utilization, and data volumes. Review with Azure cost management tools after implementation for actuals.*
