terraform {
  required_version = "~> 1.15"
  required_providers {
    azurerm = {
      version = "~> 4.8, ~> 4.60"
      source  = "hashicorp/azurerm"
    }
  }
  backend "http" {
    # Configuration is sourced from <env>-backend.tfvars files
  }
}

provider "azurerm" {
  skip_provider_registration = false
  subscription_id            = var.subscription_id_client
  features {}
}
