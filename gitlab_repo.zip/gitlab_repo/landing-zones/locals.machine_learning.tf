locals {
  machine_learning_resource_group = { for key, value in var.machine_learning_resource_group : key => value if var.machine_learning_creation }

  machine_learning_resource_group_role_assignment = tomap({
    for son in
    flatten([
      for father_key, father in var.machine_learning_resource_group : [
        for son_key, son in father.role_assignment : {
          key = "${father_key}-${son_key}"
          role_assignment = merge(
            son,
            {
              resource_group_key = father_key
            }
          )
        }
      ]
    ]) : son.key => son.role_assignment if var.machine_learning_creation
  })

  machine_learning = {
    ai_services = { for key, value in var.machine_learning_ai_services : key => merge(
      {
        name               = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-ais-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
        resource_group_id  = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].id
        location           = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location
        storage_account_id = module.storage["machine_learning_${key}"].storage_account.id
        key_vault_id       = module.keyvault[coalesce(value.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key_vault.id
        key_vault_key_id   = module.keyvault[coalesce(value.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key[var.machine_learning_default_specification.key_vault_key_key].id
      },
      value,
      {
        private_endpoint = { for private_endpoint_key, private_endpoint in value.private_endpoint : private_endpoint_key =>
          merge(
            private_endpoint,
            {
              alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

              region_code         = coalesce(private_endpoint.region_code, var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location])
              location            = private_endpoint.alias == "shared-services" ? compact([var.region_shared_services, var.machine_learning_default_specification.region_shared_services]) != [] ? coalesce(var.region_shared_services, var.machine_learning_default_specification.region_shared_services) : coalesce(private_endpoint.location, azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location) : coalesce(private_endpoint.location, azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location)
              resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
              private_dns_zone_ids = private_endpoint.alias == "current" ? [
                module.dns["privatelink.openai.azure.com"].resource.id,
                module.dns["privatelink.cognitiveservices.azure.com"].resource.id,
                module.dns["privatelink.services.ai.azure.com"].resource.id
                ] : [
                var.dns_default_specification.dns_private_zone.privatelink_openai_azure_com.private_dns_zone_id,
                var.dns_default_specification.dns_private_zone.privatelink_cognitiveservices_azure_com.private_dns_zone_id,
                var.dns_default_specification.dns_private_zone.privatelink_services_ai_azure_com.private_dns_zone_id
              ]

              subnet_id        = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[coalesce(private_endpoint.subnet_key, "01-snet-back-private-endpoints-02")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services_nic_with_multiple_ips.prd_id : var.regional_shared_resources[var.region].subnet_shared_services_nic_with_multiple_ips.np_id
              address_prefix   = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[coalesce(private_endpoint.subnet_key, "01-snet-back-private-endpoints-02")].address_prefixes[0] : null
              ip_configuration = private_endpoint.ip_configuration
            }
          )
        if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

        tags = merge(azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].tags, value.tags)
      }
    ) if var.machine_learning_creation }

    workspace_hub = { for key, value in var.machine_learning_workspace_hub : key => merge(
      {
        name                  = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-hub-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
        resource_group_id     = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].id
        location              = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location
        key_vault_id          = module.keyvault[coalesce(value.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key_vault.id
        storage_account_id    = module.storage["machine_learning_${key}"].storage_account.id
        container_registry_id = module.acr[coalesce(value.container_registry_key, var.machine_learning_default_specification.container_registry_key)].container_registry.id
      },
      value,
      {
        application_insights_id = coalesce(value.application_insights_id, azurerm_application_insights.machine_learning[key].id)
        encryption = {
          key_vault_id = coalesce(value.encryption.key_vault_id, module.keyvault[coalesce(value.encryption.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key_vault.id)
          key_id       = coalesce(value.encryption.key_id, module.keyvault[coalesce(value.encryption.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key[coalesce(value.encryption.key_vault_key_key, var.machine_learning_default_specification.key_vault_key_key)].id)
          status       = coalesce(value.encryption.status, local.environment_type == "prd" ? true : false)
        }
        private_endpoint = { for private_endpoint_key, private_endpoint in value.private_endpoint : private_endpoint_key =>
          merge(
            private_endpoint,
            {
              alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

              instance_name       = lookup(private_endpoint, "instance_name", "01")
              region_code         = lookup(private_endpoint, "region_code", var.region_code[private_endpoint.alias == "shared-services" ? compact([var.region_shared_services, var.machine_learning_default_specification.region_shared_services]) != [] ? coalesce(var.region_shared_services, var.machine_learning_default_specification.region_shared_services) : lookup(private_endpoint, "location", azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location) : lookup(private_endpoint, "location", azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location)])
              location            = private_endpoint.alias == "shared-services" ? compact([var.region_shared_services, var.machine_learning_default_specification.region_shared_services]) != [] ? coalesce(var.region_shared_services, var.machine_learning_default_specification.region_shared_services) : lookup(private_endpoint, "location", azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location) : lookup(private_endpoint, "location", azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location)
              resource_group_name = private_endpoint.alias == "current" ? lookup(private_endpoint, "resource_group_name", azurerm_resource_group.private_link[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
              private_dns_zone_ids = private_endpoint.alias == "current" ? [
                module.dns["privatelink.api.azureml.ms"].resource.id,
                module.dns["privatelink.notebooks.azure.net"].resource.id,
                ] : [
                var.dns_default_specification.dns_private_zone.privatelink_api_azureml_ms.private_dns_zone_id,
                var.dns_default_specification.dns_private_zone.privatelink_notebooks_azure_net.private_dns_zone_id,
              ]
              subnet_id        = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-02")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services_nic_with_multiple_ips.prd_id : var.regional_shared_resources[var.region].subnet_shared_services_nic_with_multiple_ips.np_id
              address_prefix   = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-02")].address_prefixes[0] : null
              ip_configuration = lookup(private_endpoint, "ip_configuration", [])
              tags             = merge(azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].tags, value.tags)
            }
          )
        if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }
        tags = merge(azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].tags, value.tags)
      }
    ) if var.machine_learning_creation }

    project = { for key, value in var.machine_learning_project : key => merge(
      value,
      {
        name          = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-proj-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
        friendly_name = coalesce(value.friendly_name, "${title(var.project_name)} - ${title(coalesce(value.workload_name, var.project_name))} - ${upper(var.environment)}-${value.instance_name} - ${coalesce(var.machine_learning_resource_group[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location, var.region)}")
        tags          = merge(azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].tags, value.tags)
      }
    ) if var.machine_learning_creation }

    cognitive_account = { for key, value in var.machine_learning_cognitive_account : key => merge(
      {
        name                 = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-${var.machine_learning_default_specification.cognitive_account[value.kind].suffix_name}-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
        resource_group_id    = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].id
        key_vault_id         = module.keyvault[coalesce(value.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key_vault.id
        storage_account_id   = module.storage[var.machine_learning_default_specification.cognitive_account.storage_account_key].storage_account.id
        kind_without_storage = var.machine_learning_default_specification.cognitive_account.kind_without_storage
      },
      value,
      {
        kind     = replace(value.kind, "_", ".")
        location = coalesce(value.location, azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location)
        customer_managed_key = {
          key_vault_key_id = module.keyvault[coalesce(value.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key["${coalesce(value.key_vault_key_key, var.machine_learning_default_specification.key_vault_key_key)}"].id
        }

        private_endpoint = { for private_endpoint_key, private_endpoint in value.private_endpoint : private_endpoint_key =>
          merge(
            private_endpoint,
            {
              alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

              region_code         = coalesce(private_endpoint.region_code, var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location])
              location            = private_endpoint.alias == "shared-services" ? compact([var.region_shared_services, var.machine_learning_default_specification.region_shared_services]) != [] ? coalesce(var.region_shared_services, var.machine_learning_default_specification.region_shared_services) : coalesce(private_endpoint.location, azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location) : lookup(private_endpoint, "location", azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location)
              resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
              private_dns_zone_ids = private_endpoint.alias == "current" ? [
                value.kind == "OpenAI" ? module.dns["privatelink.openai.azure.com"].resource.id : module.dns["privatelink.cognitiveservices.azure.com"].resource.id,
                ] : [
                value.kind == "OpenAI" ? var.dns_default_specification.dns_private_zone.privatelink_openai_azure_com.private_dns_zone_id : var.dns_default_specification.dns_private_zone.privatelink_cognitiveservices_azure_com.private_dns_zone_id,
              ]
              subnet_id        = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
              address_prefix   = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
              ip_configuration = lookup(private_endpoint, "ip_configuration", [])
              tags             = merge(azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].tags, value.tags)
            }
          )
        if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }
        tags = merge(azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].tags, value.tags)
      }
    ) if var.machine_learning_creation }

    model = { for key, value in var.machine_learning_model : key => merge(
      value,
      {
        name = substr(coalesce(value.name,
          "${var.project_name}-${lower(split("/", value.model_id)[5])}-${var.environment}-${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}"
        ), 0, 52)
      }
    ) if var.machine_learning_creation }

    storage_account = { for key, value in var.machine_learning_default_specification.hub_storage_account : "machine_learning_${key}" => merge(
      {
        name                          = replace("${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}st-oai-${var.project_name}${var.environment}${value.instance_name}", "-", "")
        account_tier                  = coalesce(value.storage_account.account_tier, "Premium")
        account_kind                  = coalesce(value.storage_account.account_kind, "StorageV2")
        is_hns_enabled                = coalesce(value.storage_account.is_hns_enabled, false)
        account_replication_type      = coalesce(value.storage_account.account_replication_type, "ZRS")
        role_assignment               = value.storage_account.role_assignment
        share                         = value.storage_account.share
        public_network_access_enabled = contains([for cognitive_account_key, cognitive_account_value in var.machine_learning_cognitive_account : cognitive_account_value.kind], "TextTranslation") ? true : false //Necessary when using document-translation with managed identity, firewall rules will be set by the machine-learning module, see https://learn.microsoft.com/en-us/azure/ai-services/translator/document-translation/how-to-guides/create-use-managed-identities?WT.mc_id=AZ-MVP-5003548
        network_rules = {
          "machine_learning_${key}" = {
            storage_account_id = module.storage[var.machine_learning_default_specification.cognitive_account.storage_account_key].storage_account.id
            bypass             = contains([for key, value in var.machine_learning_cognitive_account : value.kind], "TextTranslation") ? ["AzureServices"] : ["None"] //Necessary when using document-translation with managed identity, firewall rules will be set by the machine-learning module, see https://learn.microsoft.com/en-us/azure/ai-services/translator/document-translation/how-to-guides/create-use-managed-identities?WT.mc_id=AZ-MVP-5003548
            private_link_access = [for key, value in var.machine_learning_cognitive_account :
              {
                kind                  = value.kind
                endpoint_resource_key = key
                endpoint_tenant_id    = data.azurerm_client_config.current.tenant_id
              }
            if contains(var.machine_learning_default_specification.cognitive_account.kind_with_storage_account_network_rules, value.kind)]
          }
        }

        customer_managed_key = [
          {
            key_vault_id     = module.keyvault[coalesce(value.storage_account.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key_vault.id
            key_vault_key_id = module.keyvault[coalesce(value.storage_account.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key[var.machine_learning_default_specification.key_vault_key_key].versionless_id
            identity_name    = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-id-st-oai-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
          }
        ]
      },
      value.storage_account,
      {
        resource_group_name = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].name
        location            = azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location
        private_endpoint = { for private_endpoint_key, private_endpoint in value.storage_account.private_endpoint_cognitive : private_endpoint_key =>
          merge(
            private_endpoint,
            {
              alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

              instance_name       = lookup(private_endpoint, "instance_name", "01")
              region_code         = lookup(private_endpoint, "region_code", var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location])
              location            = private_endpoint.alias == "shared-services" ? compact([var.region_shared_services, var.machine_learning_default_specification.region_shared_services]) != [] ? coalesce(var.region_shared_services, var.machine_learning_default_specification.region_shared_services) : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[value.resource_group_key].location) : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[value.resource_group_key].location)
              resource_group_name = private_endpoint.alias == "current" ? lookup(private_endpoint, "resource_group_name", azurerm_resource_group.private_link[value.resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

              dns_private_zone_id = private_endpoint.alias == "current" ? module.dns["privatelink.${private_endpoint.subresource_name}.core.windows.net"].resource.id : var.dns_default_specification.dns_private_zone["privatelink_${private_endpoint.subresource_name}_core_windows_net"].private_dns_zone_id
              subnet_id           = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
              address_prefix      = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].address_prefixes[0] : null
              ip_configuration    = lookup(private_endpoint, "ip_configuration", [])
            }
          )
        if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

        container = { for container_key, container_value in local.cognitive_account_storage_account_container : "cognitive_account_${container_key}" =>
          {
            name                  = "${lower(container_value.kind)}-${lower(container_value.suffix_name)}"
            endpoint_resource_key = container_key
          }
        }
        tags = merge(local.tags, value.storage_account.tags)
      }
      ) if var.machine_learning_creation && contains([for key, value in var.machine_learning_cognitive_account : value.kind], "TextTranslation")
    }

    tags = local.tags
  }

  //This variable is used to map cognitive account storage containers to their respective keys.
  cognitive_account_storage_account_container = tomap({
    for son in
    flatten([
      for father_key, father in var.machine_learning_cognitive_account : [
        for son_key, son in toset(father.storage_account_container_suffix_name) : {
          key = "${father_key}-${son_key}"
          container = {
            kind        = father.kind
            suffix_name = son_key
          }
        }
      ]
    ]) : son.key => son.container
  })

  //This variable is used to map workspace hub storage accounts to their respective keys.
  workspace_hub_storage_account = { for key, value in var.machine_learning_default_specification.hub_storage_account : "machine_learning_${key}" => merge(
    {
      customer_managed_key = [
        {
          key_vault_id     = module.keyvault[coalesce(value.storage_account.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key_vault.id
          key_vault_key_id = module.keyvault[coalesce(value.storage_account.key_vault_key, var.machine_learning_default_specification.key_vault_key)].key[coalesce(value.storage_account.key_vault_key_key, var.machine_learning_default_specification.key_vault_key_key)].versionless_id
          identity_name    = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-id-st-hub-${var.project_name}-${var.environment}-${value.instance_name}"
        }
      ]
    },
    value.storage_account,
    {
      workload_name       = "hub-${var.project_name}"
      resource_group_name = azurerm_resource_group.shared_services[value.storage_account.resource_group_key].name
      location            = coalesce(value.storage_account.location, azurerm_resource_group.shared_services[value.storage_account.resource_group_key].location)
    }
    ) if var.machine_learning_creation
  }

  machine_learning_key_vault_key = { for key, value in var.shared_services_key_vault : "machine_learning_${key}" => {
    key_vault_key = key
    name          = "${var.project_name}-machine-learning-${key}"
  } if var.machine_learning_creation }
}
