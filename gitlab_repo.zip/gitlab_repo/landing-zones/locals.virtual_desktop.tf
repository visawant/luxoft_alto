locals {
  virtual_desktop_resource_group = { for key, value in var.virtual_desktop_resource_group : key => value if var.virtual_desktop_creation }

  virtual_desktop = { for virtual_desktop_key, virtual_desktop in var.virtual_desktop : virtual_desktop_key => merge(
    {
      resource_group_name = azurerm_resource_group.virtual_desktop[lookup(virtual_desktop, "resource_group_key", "01")].name
    },
    virtual_desktop,
    {
      location = lookup(virtual_desktop, "location", azurerm_resource_group.virtual_desktop[lookup(virtual_desktop, "resource_group_key", "01")].location)
      tags     = lookup(virtual_desktop, "tags", var.virtual_desktop_default_specification.tags)

      host_pool = { for host_pool_key, host_pool in lookup(virtual_desktop, "host_pool", {}) : host_pool_key => merge(
        {
          name = "${lookup(virtual_desktop, "region_code", local.region_code)}-vdpool-${lookup(host_pool, "workload_name", var.project_name)}-${var.environment}-${lookup(host_pool, "instance_name", host_pool_key)}"
        },
        host_pool
      ) }

      application_group = { for application_group_key, application_group in lookup(virtual_desktop, "application_group", {}) : application_group_key => merge(
        {
          name          = "${lookup(virtual_desktop, "region_code", local.region_code)}-vdag-${lookup(application_group, "workload_name", var.project_name)}-${var.environment}-${lookup(application_group, "instance_name", application_group_key)}"
          host_pool_key = application_group.host_pool_key
        },
        application_group
      ) }

      desktop_application = { for desktop_application_key, desktop_application in lookup(virtual_desktop, "desktop_application", {}) : desktop_application_key => merge(
        {
          name                  = "${lookup(virtual_desktop, "region_code", local.region_code)}-vdapp-${lookup(desktop_application, "workload_name", var.project_name)}-${var.environment}-${lookup(desktop_application, "instance_name", desktop_application_key)}"
          application_group_key = desktop_application.application_group_key
        },
        desktop_application
      ) }
    }
  ) if var.virtual_desktop_creation }
}
