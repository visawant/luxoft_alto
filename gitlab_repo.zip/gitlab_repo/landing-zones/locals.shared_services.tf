locals {
  shared_services_resource_group = { for key, value in var.shared_services_resource_group : key => value if var.shared_services_creation }

  shared_services_resource_group_managed_by_azure = { for key, value in merge(var.shared_services_resource_group_managed_by_azure, var.custom_shared_services_resource_group_managed_by_azure) : key => merge(
    {
      name     = coalesce(value.name, "")
      location = coalesce(value.location, var.region)
      tags     = merge(local.include_subscription_tags, local.tags, value.tags)
    }
  ) }

  shared_services_resource_group_role_assignment = tomap({
    for son in
    flatten([
      for father_key, father in var.shared_services_resource_group : [
        for son_key, son in father.role_assignment : {
          key = "${father_key}-${son_key}"
          role_assignment = merge(
            son,
            {
              resource_group_key = father_key
            }
          )
        }
      ]
    ]) : son.key => son.role_assignment if var.shared_services_creation
  })

  shared_services_key_vault = { for key_vault_key, key_vault in var.shared_services_key_vault : key_vault_key => merge(
    {
      name                          = "${var.region_code[lookup(key_vault, "location", var.region)]}-kv-${lookup(key_vault, "workload_name", var.project_name)}-${var.environment}-${key_vault.instance_name}"
      resource_group_name           = azurerm_resource_group.shared_services[lookup(key_vault, "resource_group_key", "01")].name
      location                      = azurerm_resource_group.shared_services[lookup(key_vault, "resource_group_key", "01")].location
      public_network_access_enabled = lookup(key_vault, "public_network_access_enabled", false)
      network_acls                  = lookup(key_vault, "network_acls", [])
      role_assignment               = lookup(key_vault, "role_assignment", {})
      access_policy                 = lookup(key_vault, "access_policy", {})
      aad_application = merge(
        { for k, v in var.shared_services_aad_application : k => v if v.key_vault_key == key_vault_key },
        { for k, v in local.database_postgresql_flexible_server_aad_application : k => v if v.key_vault_key == key_vault_key },
        { for k, v in local.database_mssql_server_aad_application : k => v if v.key_vault_key == key_vault_key },
        { for k, v in local.database_mysql_flexible_servers_aad_application : k => v if v.key_vault_key == key_vault_key }
      )
      sku_name                  = lookup(key_vault, "sku_name", var.shared_services_default_specification.key_vault.sku_name)
      enable_rbac_authorization = lookup(key_vault, "enable_rbac_authorization", var.shared_services_default_specification.key_vault.enable_rbac_authorization)
    },
    key_vault,
    {
      certificate = { for key, value in lookup(key_vault, "import_certificate", {}) : key =>
        {
          name = local.shared_services_existing_secret[value.existing_certificate_key].name
          certificate = {
            contents = local.shared_services_existing_secret[value.existing_certificate_key].value
          }
        }
      }

      private_endpoint = { for private_endpoint_key, private_endpoint in key_vault.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = lookup(private_endpoint, "instance_name", "01")
            region_code         = lookup(private_endpoint, "region_code", local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[lookup(key_vault, "resource_group_key", "01")].location) : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[lookup(key_vault, "resource_group_key", "01")].location)
            resource_group_name = private_endpoint.alias == "current" ? lookup(private_endpoint, "resource_group_name", azurerm_resource_group.private_link[lookup(key_vault, "resource_group_key", "01")].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            dns_private_zone_id = private_endpoint.alias == "current" ? module.dns["privatelink.vaultcore.azure.net"].resource.id : var.dns_default_specification.dns_private_zone.privatelink_vaultcore_azure_net.private_dns_zone_id
            subnet_id           = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix      = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].address_prefixes[0] : null
            ip_configuration    = lookup(private_endpoint, "ip_configuration", [])
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      secret = merge(
        { for secret_key, secret in lookup(key_vault, "secret", {}) : secret_key => merge(
          secret,
          {
            name = secret.name
            tags = merge(
              local.tags,
              azurerm_resource_group.shared_services[lookup(key_vault, "resource_group_key", "01")].tags,
              lookup(secret, "tags", {})
            )
            length         = lookup(secret, "secret", 32)
            special        = lookup(secret, "secret", true)
            days_to_expire = lookup(secret, "secret", 90)
          }
        ) },
        { for secret_key, secret in var.database_postgresql_flexible_server : "database_postgresql_flexible_server-${secret_key}" => merge(
          secret,
          {
            name = secret.administrator_secret_name
            tags = merge(local.tags, lookup(secret, "tags", {}), {
              login = secret.administrator_login
            })
            length         = lookup(secret, "secret", 32)
            special        = lookup(secret, "secret", true)
            days_to_expire = lookup(secret, "secret", 90)
          }
        ) if var.database_creation && var.database_default_specification.postgresql_flexible_server.create },
        { for secret_key, secret in var.database_mysql_flexible_servers : "database_mysql_flexible_server-${secret_key}" => merge(
          secret,
          {
            name = secret.administrator_secret_name
            tags = merge(local.tags, lookup(secret, "tags", {}), {
              login = secret.administrator_login
            })
            length         = lookup(secret, "secret", 32)
            special        = lookup(secret, "secret", true)
            days_to_expire = lookup(secret, "secret", 90)
          }
        ) if var.database_creation && var.database_default_specification.mysql_flexible_server.create },
        { for secret_key, secret in var.iaas_vm : "iaas_vm-${secret_key}" => merge(
          secret,
          {
            name = substr(coalesce(secret.user, "${coalesce(secret.name, replace("${local.region_code}${lookup(secret, "workload_name", var.project_name)}${var.environment}${secret.instance_name}", "-", ""))}-admin"), 0, 20)
            tags = merge(local.tags, lookup(secret, "tags", {}), {
              login = substr(coalesce(secret.user, "${coalesce(secret.name, replace("${local.region_code}${lookup(secret, "workload_name", var.project_name)}${var.environment}${secret.instance_name}", "-", ""))}-admin"), 0, 20)
            })
            length         = lookup(secret, "secret", 32)
            special        = lookup(secret, "secret", true)
            days_to_expire = lookup(secret, "secret", 90)
          }
        ) if secret.keyvault_key == key_vault_key },
        { for secret_key, secret in merge(lookup(key_vault, "import_secret", {}), local.shared_services_import_secret) : "import-secret-${secret_key}" => merge(
          {
            name = local.shared_services_existing_secret[secret_key].name
          },
          secret,
          {
            value           = local.shared_services_existing_secret[secret_key].value
            expiration_date = local.shared_services_existing_secret[secret_key].expiration_date
            tags            = local.shared_services_existing_secret[secret_key].tags
            import          = true
          }
        ) },
        { for secret_key, secret in lookup(local.azure_devops, "01", null) == null ? {} : local.azure_devops["01"].redis_admin_password : "redis_admin_password-${secret_key}" => merge(
          secret,
          {
            length         = lookup(secret, "secret", 32)
            special        = lookup(secret, "secret", true)
            days_to_expire = lookup(secret, "secret", 90)
          }
        ) if secret.keyvault_key == key_vault_key && var.azure_devops_creation && var.container_creation && var.container_default_specification.aks.create },
      )

      key = merge(
        { for key, value in local.machine_learning_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.machine_learning_creation },
        { for key, value in local.database_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.database_creation },
        { for key, value in local.event_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.event_creation },
        { for key, value in local.shared_services_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.shared_services_creation },
        { for key, value in local.backup_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.backup_creation },
        { for key, value in local.container_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.container_creation },
        { for key, value in local.private_link_key_vault_key : key => value if value.key_vault_key == key_vault_key && var.private_link_creation }
      )

      tags = merge(coalesce(key_vault.tags, {}), local.tags)
    }
  ) if var.shared_services_creation && (((lookup(key_vault, "enable_rbac_authorization", true)) == false && !var.machine_learning_creation) ? false : true) }

  shared_services_existing_secret = data.azurerm_key_vault_secret.certificate_shared_services_prd

  shared_services_key_vault_key = var.shared_services_creation ? {
    "shared-services-01" = {
      key_vault_key = var.shared_services_default_specification.key_vault.default_key
      name          = "${var.project_name}-shared-services-01"
    }
  } : {}

  shared_services_container_registry = { for container_registry_key, container_registry in var.shared_services_container_registry : container_registry_key => merge(
    {
      name                = replace("${var.region_code[coalesce(container_registry.location, var.region)]}cr${coalesce(container_registry.workload_name, var.project_name)}${var.environment}${container_registry.instance_name}", "-", "")
      resource_group_name = azurerm_resource_group.shared_services[container_registry.resource_group_key].name
      sku                 = container_registry.sku
      encryption = var.disable_container_registry_encryption ? [] : [
        {
          key_vault_key_id          = module.keyvault[coalesce(container_registry.key_vault_key, var.shared_services_default_specification.key_vault.default_key)].key[coalesce(container_registry.key_vault_key_key, var.shared_services_default_specification.key_vault.key_vault_key)].versionless_id
          key_vault_key_resource_id = module.keyvault[coalesce(container_registry.key_vault_key, var.shared_services_default_specification.key_vault.default_key)].key[coalesce(container_registry.key_vault_key_key, var.shared_services_default_specification.key_vault.key_vault_key)].resource_versionless_id
          identity_name             = "${var.region_code[coalesce(container_registry.location, var.region)]}-id-cr-${coalesce(container_registry.workload_name, var.project_name)}-${var.environment}-${container_registry.instance_name}"
        }
      ]
    },
    container_registry,
    {
      location = azurerm_resource_group.shared_services[container_registry.resource_group_key].location
      role_assignment = merge(
        container_registry.role_assignment,
        var.shared_services_default_specification.container_registry["${local.environment_type}"].role_assignment
      )
      private_endpoint = { for private_endpoint_key, private_endpoint in container_registry.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = private_endpoint.instance_name
            region_code         = coalesce(private_endpoint.region_code, local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.shared_services[container_registry.resource_group_key].location) : coalesce(private_endpoint.location, azurerm_resource_group.shared_services[container_registry.resource_group_key].location)
            resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[container_registry.resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            dns_private_zone_id = private_endpoint.alias == "current" ? module.dns["privatelink.azurecr.io"].resource.id : var.dns_default_specification.dns_private_zone.privatelink_azurecr_io.private_dns_zone_id
            subnet_id           = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[coalesce(private_endpoint.subnet_key, "01-snet-back-private-endpoints-02")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services_nic_with_multiple_ips.prd_id : var.regional_shared_resources[var.region].subnet_shared_services_nic_with_multiple_ips.np_id
            address_prefix      = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[coalesce(private_endpoint.subnet_key, "01-snet-back-private-endpoints-02")].address_prefixes[0] : null
            ip_configuration    = private_endpoint.ip_configuration
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      tags = merge(container_registry.tags, local.tags)
    }
  ) if var.shared_services_creation && var.private_link_creation }

  shared_services_storage_account = { for storage_account_key, storage_account in merge(var.shared_services_storage_account, var.shared_services_additional_storage_account, local.workspace_hub_storage_account, local.backup_vault_storage_account) : storage_account_key => merge(
    {
      name                             = substr(replace("${var.region_code[lookup(storage_account, "location", azurerm_resource_group.shared_services[lookup(storage_account, "resource_group_key", "01")].location)]}st${lookup(storage_account, "workload_name", var.project_name)}${var.environment}${storage_account.instance_name}", "-", ""), 0, 24)
      resource_group_name              = lookup(storage_account, "resource_group_name", azurerm_resource_group.shared_services[lookup(storage_account, "resource_group_key", "01")].name)
      location                         = lookup(storage_account, "location", azurerm_resource_group.shared_services[lookup(storage_account, "resource_group_key", "01")].location)
      account_tier                     = lookup(storage_account, "account_tier", "Premium")
      account_kind                     = lookup(storage_account, "account_kind", "StorageV2")
      is_hns_enabled                   = lookup(storage_account, "is_hns_enabled", false)
      account_replication_type         = lookup(storage_account, "account_replication_type", "ZRS")
      public_network_access_enabled    = lookup(storage_account, "public_network_access_enabled", false)
      cross_tenant_replication_enabled = lookup(storage_account, "cross_tenant_replication_enabled", false)
      allowed_copy_scope               = lookup(storage_account, "allowed_copy_scope", "AAD")
      allow_nested_items_to_be_public  = lookup(storage_account, "allow_nested_items_to_be_public", false)
      blob_properties                  = lookup(storage_account, "blob_properties", [])
      management_policy                = lookup(storage_account, "management_policy", {})
      customer_managed_key = [
        {
          key_vault_key_id = module.keyvault[var.shared_services_default_specification.key_vault.default_key].key[var.shared_services_default_specification.key_vault.key_vault_key].versionless_id
          key_vault_id     = module.keyvault[var.shared_services_default_specification.key_vault.default_key].key_vault.id
          identity_name    = "${var.region_code[lookup(storage_account, "location", azurerm_resource_group.shared_services[lookup(storage_account, "resource_group_key", "01")].location)]}-id-st-${lookup(storage_account, "workload_name", var.project_name)}-${var.environment}-${storage_account.instance_name}"
        }
      ]
    },
    storage_account,
    {
      private_endpoint = { for private_endpoint_key, private_endpoint in storage_account.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = lookup(private_endpoint, "instance_name", "01")
            region_code         = lookup(private_endpoint, "region_code", local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[lookup(storage_account, "resource_group_key", "01")].location) : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[lookup(storage_account, "resource_group_key", "01")].location)
            resource_group_name = private_endpoint.alias == "current" ? lookup(private_endpoint, "resource_group_name", azurerm_resource_group.private_link["01"].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
            dns_private_zone_id = private_endpoint.alias == "current" ? module.dns["privatelink.${private_endpoint.subresource_name}.core.windows.net"].resource.id : var.dns_default_specification.dns_private_zone["privatelink_${private_endpoint.subresource_name}_core_windows_net"].private_dns_zone_id
            subnet_id           = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix      = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].address_prefixes[0] : null
            ip_configuration    = lookup(private_endpoint, "ip_configuration", [])
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      container = lookup(storage_account, "container", {})
      share     = lookup(storage_account, "share", {})
      network_rules = { for key, value in lookup(storage_account, "network_rules", { "01" = {} }) : key => merge(value,
        {
          private_link_access = lookup(value, "private_link_access", null) == null ? var.shared_services_storage_account_network_rules_private_link_access : concat(value.private_link_access, var.shared_services_storage_account_network_rules_private_link_access)
      }) }
      role_assignment = { for k, v in lookup(storage_account, "role_assignment", {}) : k =>
        {
          role_definition_name = v.role_definition_name
          principal_id         = lookup(v, "aad_application_key", null) != null ? module.keyvault[lookup(v, "keyvault_key", "01")].aad_application[v.aad_application_key].service_principal_object_id : v.principal_id
          principal_type       = lookup(v, "aad_application_key", null) != null ? "ServicePrincipal" : v.principal_type
        }
      }

      tags = merge(lookup(storage_account, "tags", {}), local.tags)
    }
  ) if var.shared_services_creation }

  shared_services_import_secret = var.container_creation && var.container_default_specification.aks.create ? {
    "keycloak-argocd-azure-${var.environment}-client-secret" = {
      existing_secret_key = "import-secret-keycloak-argocd-azure-${var.environment}-client-secret"
      name                = "keycloak-argocd-azure-client-secret"
    }
    "prometheus-basic-auth-${local.environment_type}-secret" = {
      existing_secret_key = "import-secret-prometheus-basic-auth-${local.environment_type}-secret"
      name                = "prometheus-basic-auth-secret"
    }
  } : {}
}
