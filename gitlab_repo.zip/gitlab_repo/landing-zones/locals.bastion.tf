locals {
  bastion_resource_group = { for key, value in var.bastion_resource_group : key => value if var.bastion_creation && var.virtual_network_creation }
  bastion_resource       = { for key, value in var.bastion_resource : key => value if var.bastion_creation && var.virtual_network_creation }
  bastion_public_ip      = { for key, value in var.bastion_public_ip : key => value if var.bastion_creation && var.bastion_sku != "Developer" && var.virtual_network_creation }

  bastion = { for bastion_key, bastion in local.bastion_resource : bastion_key => merge(
    {
      virtual_network_id = azurerm_virtual_network.connectivity[bastion.virtual_network_key].id
      ip_configuration = {
        name                 = "${local.region_code}-ipconfig-bastion-${var.environment}-${lookup(bastion, "instance_name", bastion_key)}"
        subnet_id            = azurerm_subnet.connectivity[bastion.subnet_key].id
        public_ip_address_id = var.bastion_sku != "Developer" ? azurerm_public_ip.bastion[bastion.public_ip_address_key].id : null
      }
    },
    bastion
  ) if var.virtual_network_creation }
}
