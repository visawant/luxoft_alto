resource "azurerm_resource_group" "iaas" {
  for_each = local.iaas_resource_group

  name     = "${local.region_code}-rg-${each.value.workload_name}-${var.environment}-${lookup(each.value, "instance_name", each.key)}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
