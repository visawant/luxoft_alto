variable "connectivity_network_security_group_rules_default_specification" {
  description = "Network Security Group rules default specifications"
  type = map(list(object({
    description                                = optional(string, null)
    direction                                  = optional(string, null)
    name                                       = optional(string, null)
    suffix_name                                = optional(string, "")
    access                                     = optional(string, null)
    priority                                   = optional(number, null)
    source_address_prefix                      = optional(string, null)
    source_address_prefixes                    = optional(list(string), null)
    source_subnet_key                          = optional(list(string), []) //Use a subnet key or "current_subnet"
    source_virtual_network_key                 = optional(list(string), []) //Use a virtual network to include all it's cidr
    source_application_security_group_ids      = optional(list(string), null)
    destination_address_prefix                 = optional(string, null)
    destination_address_prefixes               = optional(list(string), null)
    destination_subnet_key                     = optional(list(string), []) //Use a subnet key or "current_subnet"
    destination_virtual_network_key            = optional(list(string), []) //Use a virtual network to include all it's cidr
    destination_application_security_group_ids = optional(list(string), null)
    destination_port_range                     = optional(string, null)
    destination_port_ranges                    = optional(list(string), null)
    protocol                                   = optional(string, null)
    source_port_range                          = optional(string, null)
    source_port_ranges                         = optional(list(string), null)
  })))
  default = {
    "default" = [
      {
        suffix_name             = "AzureBastionAllowSshRdp"
        description             = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                = 100
        direction               = "Inbound"
        access                  = "Allow"
        protocol                = "Tcp"
        source_port_range       = "*"
        destination_port_ranges = ["22", "3389"]
        source_subnet_key       = ["01-AzureBastionSubnet"]
        destination_subnet_key  = ["current_subnet"]
      },
      {
        name                       = "AviatrixNatRule"
        description                = "Internet Egress allowed and routed to Aviatrix via Route Tables: https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 210
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_virtual_network_key = ["01"]
        destination_address_prefix = "Internet"
      },
      {
        suffix_name            = "AzureLoadBalancer"
        description            = "Azure probe: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority               = 1000
        direction              = "Inbound"
        access                 = "Allow"
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "*"
        source_address_prefix  = "AzureLoadBalancer"
        destination_subnet_key = ["current_subnet"]
      },
      {
        suffix_name                  = "Keycloak"
        description                  = "Resources to Keycloak: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                     = 1010
        direction                    = "Inbound"
        access                       = "Allow"
        protocol                     = "Tcp"
        source_port_range            = "*"
        destination_port_ranges      = ["443", "4000-4004"]
        source_subnet_key            = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefixes = ["10.0.0.159", "10.0.0.160"]
      },
      {
        suffix_name                  = "Keycloak"
        description                  = "Resources to Keycloak: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                     = 1010
        direction                    = "Outbound"
        access                       = "Allow"
        protocol                     = "Tcp"
        source_port_range            = "*"
        destination_port_ranges      = ["443", "4000-4004"]
        source_subnet_key            = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefixes = ["10.0.0.159", "10.0.0.160"]
      },
      {
        suffix_name                = "KeyVault"
        description                = "Resources to Azure Key Vault: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                   = 1020
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["443"]
        source_subnet_key          = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01", "01-snet-app-service-01", "01-snet-container-app-devops-01", "01-snet-container-instance-devops-01"]
        destination_address_prefix = "10.0.1.4"
      },
      {
        suffix_name                = "KeyVault"
        description                = "Resources to Azure Key Vault: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                   = 1020
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["443"]
        source_subnet_key          = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01", "01-snet-app-service-01", "01-snet-container-app-devops-01", "01-snet-container-instance-devops-01"]
        destination_address_prefix = "10.0.1.4"
      },
      {
        suffix_name                  = "StorageAccount"
        description                  = "Containers to Azure Storage Account volumes: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                     = 1030
        direction                    = "Inbound"
        access                       = "Allow"
        protocol                     = "Tcp"
        source_port_range            = "*"
        destination_port_ranges      = ["443", "445"]
        source_subnet_key            = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefixes = ["10.0.1.7", "10.0.1.8", "10.0.1.39", "10.0.1.34", "10.0.1.33"]
      },
      {
        suffix_name                  = "StorageAccount"
        description                  = "Containers to Azure Storage Account volumes: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                     = 1030
        direction                    = "Outbound"
        access                       = "Allow"
        protocol                     = "Tcp"
        source_port_range            = "*"
        destination_port_ranges      = ["443", "445"]
        source_subnet_key            = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefixes = ["10.0.1.7", "10.0.1.8", "10.0.1.39", "10.0.1.34", "10.0.1.33"]
      },
      {
        suffix_name                  = "ContainerRegistry"
        description                  = "Containers to Azure Container Registry: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                     = 1040
        direction                    = "Inbound"
        access                       = "Allow"
        protocol                     = "Tcp"
        source_port_range            = "*"
        destination_port_ranges      = ["443"]
        source_subnet_key            = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01", "01-snet-container-app-devops-01", "01-snet-container-instance-devops-01"]
        destination_address_prefixes = ["10.0.2.69", "10.0.2.70"]
      },
      {
        suffix_name                  = "ContainerRegistry"
        description                  = "Containers to Azure Container Registry: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                     = 1040
        direction                    = "Outbound"
        access                       = "Allow"
        protocol                     = "Tcp"
        source_port_range            = "*"
        destination_port_ranges      = ["443"]
        source_subnet_key            = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01", "01-snet-container-app-devops-01", "01-snet-container-instance-devops-01"]
        destination_address_prefixes = ["10.0.2.69", "10.0.2.70"]
      },
      {
        suffix_name                = "PostgreSQL"
        description                = "Containers to PostgreSQL flexible server: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                   = 1050
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "5432"
        source_subnet_key          = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefix = "10.0.1.9"
      },
      {
        suffix_name                = "PostgreSQL"
        description                = "Containers to PostgreSQL flexible server: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                   = 1050
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "5432"
        source_subnet_key          = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefix = "10.0.1.9"
      },
      {
        suffix_name                = "MySQL"
        description                = "Containers to MySQL flexible server: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                   = 1060
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "3306"
        source_subnet_key          = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefix = "10.0.1.13"
      },
      {
        suffix_name                = "MySQL"
        description                = "Containers to MySQL flexible server: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                   = 1060
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "3306"
        source_subnet_key          = ["01-snet-aks-01", "01-snet-aks-02", "01-snet-container-app-01"]
        destination_address_prefix = "10.0.1.13"
      },
      {
        suffix_name            = "AKS"
        description            = "AKS workload: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority               = 1070
        direction              = "Inbound"
        access                 = "Allow"
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "*"
        source_subnet_key      = ["01-snet-aks-01", "01-snet-aks-02"]
        destination_subnet_key = ["01-snet-aks-01", "01-snet-aks-02"]
      },
      {
        suffix_name            = "AKS"
        description            = "AKS workload: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority               = 1070
        direction              = "Outbound"
        access                 = "Allow"
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "*"
        source_subnet_key      = ["01-snet-aks-01", "01-snet-aks-02"]
        destination_subnet_key = ["01-snet-aks-01", "01-snet-aks-02"]
      },
      {
        suffix_name            = "ContainerApp"
        description            = "Container App workload: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority               = 1080
        direction              = "Inbound"
        access                 = "Allow"
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "*"
        source_subnet_key      = ["01-snet-container-app-01"]
        destination_subnet_key = ["01-snet-container-app-01"]
      },
      {
        suffix_name            = "ContainerApp"
        description            = "Container App workload: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority               = 1080
        direction              = "Outbound"
        access                 = "Allow"
        protocol               = "*"
        source_port_range      = "*"
        destination_port_range = "*"
        source_subnet_key      = ["01-snet-container-app-01"]
        destination_subnet_key = ["01-snet-container-app-01"]
      },
      {
        suffix_name                = "FuncToStorage"
        description                = "Function to Storage Account"
        priority                   = 1090
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_subnet_key          = ["01-snet-app-service-01"]
        destination_address_prefix = "10.0.1.40"
      },
      {
        suffix_name                = "FuncToStorage"
        description                = "Function to Storage Account"
        priority                   = 1090
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_subnet_key          = ["01-snet-app-service-01"]
        destination_address_prefix = "10.0.1.40"
      },
      {
        suffix_name                     = "DenyVirtualNetworkFlow"
        description                     = "Deny virtual network inbound flow: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                        = 4000
        direction                       = "Inbound"
        access                          = "Deny"
        protocol                        = "*"
        source_port_range               = "*"
        destination_port_range          = "*"
        source_virtual_network_key      = ["01"]
        destination_virtual_network_key = ["01"]
      },
      {
        suffix_name                     = "DenyVirtualNetworkFlow"
        description                     = "Deny virtual network inbound flow: https://confluence.intramundi.com/display/ITSPCI/Client+zone+-+Network+Flow+Matrix"
        priority                        = 4000
        direction                       = "Outbound"
        access                          = "Deny"
        protocol                        = "*"
        source_port_range               = "*"
        destination_port_range          = "*"
        source_virtual_network_key      = ["01"]
        destination_virtual_network_key = ["01"]
      }
    ]

    "azure_bastion" = [
      {
        name                       = "AllowHttpsInBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 100
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_address_prefix      = "Internet"
        destination_address_prefix = "*"
      },
      {
        name                       = "AllowGatewayManagerInBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 110
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["443"]
        source_address_prefix      = "GatewayManager"
        destination_address_prefix = "*"
      },
      {
        name                       = "AllowLoadBalancerInBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 120
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["443"]
        source_address_prefix      = "AzureLoadBalancer"
        destination_address_prefix = "*"
      },
      {
        name                       = "AllowBastionHostCommunicationInBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 130
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["8080", "5701"]
        source_address_prefix      = "VirtualNetwork"
        destination_address_prefix = "VirtualNetwork"
      },
      {
        name                       = "DenyAllInBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 4010
        direction                  = "Inbound"
        access                     = "Deny"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      },
      {
        name                       = "AllowSshRdpOutBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 100
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_ranges    = ["22", "3389"]
        source_address_prefix      = "*"
        destination_address_prefix = "VirtualNetwork"
      },
      {
        name                       = "AllowAzureCloudCommunicationOutBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 110
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_address_prefix      = "*"
        destination_address_prefix = "AzureCloud"
      },
      {
        name                       = "AllowBastionHostCommunicationOutBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 120
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["8080", "5701"]
        source_address_prefix      = "*"
        destination_address_prefix = "VirtualNetwork"
      },
      {
        name                       = "AllowGetSessionInformationOutBound"
        description                = "See Microsoft requirements : https://learn.microsoft.com/en-us/azure/bastion/bastion-nsg?WT.mc_id=AZ-MVP-5003548"
        priority                   = 130
        direction                  = "Outbound"
        access                     = "Allow"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["80", "443"]
        source_address_prefix      = "*"
        destination_address_prefix = "Internet"
      },
      {
        name                       = "DenyAllOutBound"
        description                = ""
        priority                   = 4010
        direction                  = "Outbound"
        access                     = "Deny"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      },
    ]

    "aviatrix" = [
      {
        name                       = "AviatrixManagement"
        description                = "Specific rules created at the NSG's NIC level by Aviatrix that we have reproduced at the NSG's subnet level."
        priority                   = 200
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_ranges    = ["443", "500", "4500", "1194"]
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      },
      {
        name                       = "AviatrixNatRule"
        description                = "Specific NAT rule created at the NSG's NIC level by Aviatrix that we have reproduced at the NSG's subnet level."
        priority                   = 210
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "VirtualNetwork"
        destination_address_prefix = "*"
      }
    ]
  }
}

variable "connectivity_network_security_group_rules_additional_specification" {
  description = "Additional Network Security Group rules default specifications"
  type = map(list(object({
    description                                = optional(string, null)
    direction                                  = optional(string, null)
    name                                       = optional(string, null)
    suffix_name                                = optional(string, "")
    access                                     = optional(string, null)
    priority                                   = optional(number, null)
    source_address_prefix                      = optional(string, null)
    source_address_prefixes                    = optional(list(string), null)
    source_subnet_key                          = optional(list(string), []) //Use a subnet key or "current_subnet"
    source_virtual_network_key                 = optional(list(string), []) //Use a virtual network to include all it's cidr
    source_application_security_group_ids      = optional(list(string), null)
    destination_address_prefix                 = optional(string, null)
    destination_address_prefixes               = optional(list(string), null)
    destination_subnet_key                     = optional(list(string), []) //Use a subnet key or "current_subnet"
    destination_virtual_network_key            = optional(list(string), []) //Use a virtual network to include all it's cidr
    destination_application_security_group_ids = optional(list(string), null)
    destination_port_range                     = optional(string, null)
    destination_port_ranges                    = optional(list(string), null)
    protocol                                   = optional(string, null)
    source_port_range                          = optional(string, null)
    source_port_ranges                         = optional(list(string), null)
  })))
  default = {}
}
