resource "azurerm_resource_group" "bastion" {
  for_each = local.bastion_resource_group

  name     = "${local.region_code}-rg-bastion-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, local.tags, coalesce(each.value.tags, {}))

}

resource "azurerm_public_ip" "bastion" {
  for_each            = local.bastion_public_ip
  name                = "${local.region_code}-pip-${lookup(each.value, "workload_name", var.project_name)}-${var.environment}-${lookup(each.value, "instance_name", each.key)}"
  location            = azurerm_resource_group.bastion[each.value.resource_group_key].location
  resource_group_name = azurerm_resource_group.bastion[each.value.resource_group_key].name
  allocation_method   = each.value.allocation_method
  sku                 = each.value.sku
  zones               = lookup(each.value, "zones", var.bastion_default_specification.zones)
  tags                = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
