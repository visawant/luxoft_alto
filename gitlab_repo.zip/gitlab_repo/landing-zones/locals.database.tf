locals {
  database_resource_group = { for key, value in var.database_resource_group : key => value if var.database_creation }

  database_resource_group_role_assignment = tomap({
    for son in
    flatten([
      for father_key, father in var.database_resource_group : [
        for son_key, son in father.role_assignment : {
          key = "${father_key}-${son_key}"
          role_assignment = merge(
            son,
            {
              resource_group_key = father_key
            }
          )
        }
      ]
    ]) : son.key => son.role_assignment if var.database_creation
  })

  database_key_vault_key = var.database_creation ? {
    "database-01" = {
      key_vault_key = var.database_default_specification.mssql_server.key_vault_key
      name          = "${var.project_name}-database-01"
    }
  } : {}

  database_postgresql_flexible_server = { for database_postgresql_flexible_server_key, database_postgresql_flexible_server in var.database_postgresql_flexible_server : database_postgresql_flexible_server_key => merge(
    {
      name_server         = "${local.region_code}-psql-${coalesce(database_postgresql_flexible_server.workload_name, var.project_name)}-${var.environment}-${database_postgresql_flexible_server.instance_name}"
      resource_group_name = azurerm_resource_group.database[coalesce(database_postgresql_flexible_server.resource_group_key, "01")].name
      location            = azurerm_resource_group.database[coalesce(database_postgresql_flexible_server.resource_group_key, "01")].location
    },
    database_postgresql_flexible_server,
    {
      auto_grow_enabled = coalesce(database_postgresql_flexible_server.auto_grow_enabled, var.database_default_specification.postgresql_flexible_server.auto_grow_enabled)
      storage_mb        = coalesce(database_postgresql_flexible_server.storage_mb, var.database_default_specification.postgresql_flexible_server["${local.environment_type}"].storage_mb)
      login             = database_postgresql_flexible_server.administrator_login
      password          = module.keyvault[database_postgresql_flexible_server.keyvault_key].password["database_postgresql_flexible_server-${database_postgresql_flexible_server_key}"].value
      authentication = {
        tenant_id      = data.azurerm_client_config.current.tenant_id
        object_id      = module.keyvault[database_postgresql_flexible_server.keyvault_key].aad_application["sp-flexible-server-${database_postgresql_flexible_server_key}"].service_principal_object_id
        principal_name = module.keyvault[database_postgresql_flexible_server.keyvault_key].aad_application["sp-flexible-server-${database_postgresql_flexible_server_key}"].application_display_name
        principal_type = "ServicePrincipal"
      }
      sku                  = coalesce(database_postgresql_flexible_server.sku, var.database_default_specification.postgresql_flexible_server["${local.environment_type}"].sku)
      version_db           = coalesce(database_postgresql_flexible_server.version_db, var.database_default_specification.postgresql_flexible_server.version_db)
      database             = database_postgresql_flexible_server.database
      delegated_subnet_id  = null
      private_dns_zone_id  = null
      zone                 = try(database_postgresql_flexible_server.zone, var.database_default_specification.postgresql_flexible_server["${local.environment_type}"].zone)
      high_availability    = length(database_postgresql_flexible_server.high_availability) == 0 ? var.database_default_specification.postgresql_flexible_server["${local.environment_type}"].high_availability : database_postgresql_flexible_server.high_availability
      server_configuration = coalesce(database_postgresql_flexible_server.server_configuration, var.database_default_specification.postgresql_flexible_server["${local.environment_type}"].server_configuration)
      private_endpoint = { for private_endpoint_key, private_endpoint in database_postgresql_flexible_server.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = private_endpoint.instance_name
            region_code         = coalesce(private_endpoint.region_code, local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.shared_services[database_postgresql_flexible_server.resource_group_key].location) : coalesce(private_endpoint.location, azurerm_resource_group.shared_services[database_postgresql_flexible_server.resource_group_key].location)
            resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[coalesce(database_postgresql_flexible_server.resource_group_key)].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            dns_private_zone_id = private_endpoint.alias == "current" ? module.dns["privatelink.postgres.database.azure.com"].resource.id : var.dns_default_specification.dns_private_zone.privatelink_postgres_database_azure_com.private_dns_zone_id
            subnet_id           = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix      = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
            ip_configuration    = private_endpoint.ip_configuration
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      tags = merge(database_postgresql_flexible_server.tags, local.tags)
    }
  ) if var.database_creation && var.database_default_specification.postgresql_flexible_server.create && var.shared_services_creation && var.private_link_creation }

  database_postgresql_flexible_dbsqware = { for database_postgresql_flexible_server_key, database_postgresql_flexible_server in var.database_postgresql_flexible_server : "postgresql_flexible_server-${database_postgresql_flexible_server_key}" => merge(
    {
      dbsqware_payload = {
        dbalias        = upper("PGS_AZU${module.flex-postgre[database_postgresql_flexible_server_key].server.name}")
        rdbmsname      = "PostgreSQL"
        virt_host_name = module.flex-postgre[database_postgresql_flexible_server_key].server.fqdn
        host_name      = module.flex-postgre[database_postgresql_flexible_server_key].server.fqdn
        username       = "sp-dbsqware-amt"
        port           = "5432"
        comments       = var.project_name
        contact        = var.project_name
        client         = "AMUNDI"
        env            = upper(contains(["np", "uat"], module.flex-postgre[database_postgresql_flexible_server_key].server.tags["environment"]) ? "RCT" : module.flex-postgre[database_postgresql_flexible_server_key].server.tags["environment"] == "dmo" ? "TST" : module.flex-postgre[database_postgresql_flexible_server_key].server.tags["environment"])
        globalhost     = ""
        custom1        = ""
        custom2        = ""
        dbaname        = ""
        comments_upd   = "insert new instance by API through Terraform"
        custom1        = "https://portal.azure.com/#@amundi.com/resource${module.flex-postgre[database_postgresql_flexible_server_key].server.id}/overview"
      }
      name_server = module.flex-postgre[database_postgresql_flexible_server_key].server.name
    }
  ) if var.database_creation && var.database_default_specification.postgresql_flexible_server.create && var.shared_services_creation && var.private_link_creation }

  database_postgresql_flexible_server_aad_application = { for database_postgresql_flexible_server_key, database_postgresql_flexible_server in var.database_postgresql_flexible_server : "sp-flexible-server-${database_postgresql_flexible_server_key}" =>
    {
      display_name  = "sp-postgresql-flexible-server-admin-${coalesce(database_postgresql_flexible_server.region_code, local.region_code)}-${coalesce(database_postgresql_flexible_server.workload_name, var.project_name)}-${var.environment}-${coalesce(database_postgresql_flexible_server.instance_name, database_postgresql_flexible_server_key)}"
      description   = "PostgreSQL Flexible Server application for ${var.project_name}"
      owners        = coalesce(database_postgresql_flexible_server.aad_application.owners, var.database_default_specification.postgresql_flexible_server.aad_application.owners)
      key_vault_key = coalesce(database_postgresql_flexible_server.keyvault_key, var.database_default_specification.postgresql_flexible_server.aad_application.key_vault_key)
      secret = {
        name         = database_postgresql_flexible_server.aad_application.secret.name
        display_name = true
        version      = database_postgresql_flexible_server.aad_application.secret.version
        tenant_id    = data.azurerm_client_config.current.tenant_id
        host         = "${local.region_code}-psql-${coalesce(database_postgresql_flexible_server.workload_name, var.project_name)}-${var.environment}-${database_postgresql_flexible_server.instance_name}.postgres.database.azure.com"
      }
  } if var.database_creation && var.database_default_specification.postgresql_flexible_server.create && var.shared_services_creation && var.private_link_creation }

  database_postgresql_flexible_server_backup_vault = { for key, value in var.database_postgresql_flexible_server : module.flex-postgre[key].server.name => {
    backup_vault_key = value.backup_vault_key

    backup_instances = { for backup_policy_key in value.backup_policy_keys : "${module.flex-postgre[key].server.name}_${backup_policy_key}" => {
      type                          = "postgresql_flexible"
      name                          = "${substr("${module.flex-postgre[key].server.name}_${backup_policy_key}", 0, 50)}" //All backup instance names must be between 5 and 50 characters long.
      backup_policy_key             = backup_policy_key
      postgresql_flexible_server_id = module.flex-postgre[key].server.id
      }
    }

    role_assignments = {
      "${module.flex-postgre[key].server.name}_postgresql_contributor" = {
        principal_id               = "system-assigned" # Special marker that the module will interpret
        role_definition_id_or_name = "Contributor"
        scope                      = module.flex-postgre[key].server.id
        description                = "Allow backup vault identity to perform backup operations on PostgreSQL Flexible server"
      }
      "${module.flex-postgre[key].server.name}_resource_group_reader}" = {
        principal_id               = "system-assigned" # Special marker that the module will interpret
        role_definition_id_or_name = "Reader"
        scope                      = regex("(.*?/resourceGroups/[^/]+)", module.flex-postgre[key].server.id)[0]
        description                = "Allow backup vault identity to read resource group information"
      }
    }
  } if var.database_creation && var.database_default_specification.postgresql_flexible_server.create && var.shared_services_creation && var.private_link_creation }

  database_mssql_server = { for key, value in var.database_mssql_server : key => merge(
    {
      name                                         = "${coalesce(value.region_code, local.region_code)}-sql-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
      resource_group_name                          = azurerm_resource_group.database[value.resource_group_key].name
      location                                     = azurerm_resource_group.database[value.resource_group_key].location
      transparent_data_encryption_key_vault_key_id = module.keyvault[coalesce(value.key_vault_key, var.database_default_specification.mssql_server.key_vault_key)].key["database-01"].id
      key_vault_id                                 = module.keyvault[coalesce(value.key_vault_key, var.database_default_specification.mssql_server.key_vault_key)].key_vault.id
    },
    value,
    {
      private_endpoint = { for private_endpoint_key, private_endpoint in value.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = lookup(private_endpoint, "instance_name", "01")
            region_code         = lookup(private_endpoint, "region_code", local.region_code)
            location            = lookup(private_endpoint, "location", azurerm_resource_group.database[value.resource_group_key].location)
            resource_group_name = private_endpoint.alias == "current" ? lookup(private_endpoint, "resource_group_name", azurerm_resource_group.private_link[var.database_default_specification.private_endpoint.resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            private_dns_zone_ids = private_endpoint.alias == "current" ? [module.dns["privatelink.database.windows.net"].resource.id] : [var.dns_default_specification.dns_private_zone.privatelink_database_windows_net.private_dns_zone_id]
            subnet_id            = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix       = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].address_prefixes[0] : null
            ip_configuration     = lookup(private_endpoint, "ip_configuration", [])
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      azuread_administrator = {
        object_id                   = module.keyvault[coalesce(value.key_vault_key, var.database_default_specification.mssql_server.aad_application.key_vault_key)].aad_application["sp-mssql-server-${key}"].service_principal_object_id
        login_username              = module.keyvault[coalesce(value.key_vault_key, var.database_default_specification.mssql_server.aad_application.key_vault_key)].aad_application["sp-mssql-server-${key}"].application_display_name
        azuread_authentication_only = coalesce(value.azuread_administrator.azuread_authentication_only, var.database_default_specification.mssql_server.azuread_administrator.azuread_authentication_only)
      }
    }
  ) if var.database_creation && var.database_default_specification.mssql_server.create }

  database_mssql_dbsqware = { for key, value in var.database_mssql_server : "database_mssql-${key}" => merge(
    {
      dbsqware_payload = {
        dbalias        = upper("MSS_AZU${module.mssql.server[key].name}")
        rdbmsname      = "MsSql"
        virt_host_name = module.mssql.server[key].fqdn
        host_name      = module.mssql.server[key].fqdn
        username       = "sp-dbsqware-amt"
        port           = "1433"
        comments       = var.project_name
        contact        = var.project_name
        client         = "AMUNDI"
        env            = upper(contains(["np", "uat"], module.mssql.server[key].tags["environment"]) ? "RCT" : module.mssql.server[key].tags["environment"] == "dmo" ? "TST" : module.mssql.server[key].tags["environment"])
        globalhost     = ""
        custom1        = ""
        custom2        = ""
        dbaname        = ""
        comments_upd   = "insert new instance by API through Terraform"
        custom1        = "https://portal.azure.com/#@amundi.com/resource${module.mssql.server[key].id}/overview"
      }
      name_server = module.mssql.server[key].name
    }
  ) if var.database_creation && var.database_default_specification.mssql_server.create }

  database_mssql_server_aad_application = { for key, value in var.database_mssql_server : "sp-mssql-server-${key}" =>
    {
      display_name  = "sp-mssql-server-admin-${coalesce(value.region_code, local.region_code)}-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
      description   = "Azure SQL Database server application for ${var.project_name}"
      owners        = lookup(value.aad_application, "owners", var.database_default_specification.mssql_server.aad_application.owners)
      key_vault_key = coalesce(value.key_vault_key, var.database_default_specification.mssql_server.aad_application.key_vault_key)
      secret = {
        name    = coalesce(value.secret.name, "sp-mssql-server-admin")
        version = coalesce(value.secret.version, "v1")
      }
  } if var.database_creation && var.database_default_specification.mssql_server.create }

  database_mssql_database = { for key, value in var.database_mssql_database : key => merge(
    {
      transparent_data_encryption_key_vault_key_id = module.keyvault[coalesce(value.key_vault_key, var.database_default_specification.mssql_server.key_vault_key)].key["database-01"].id
    },
    value,
    {
    }
  ) if var.database_creation && var.database_default_specification.mssql_server.create }

  database_mysql_flexible_servers = { for database_mysql_flexible_servers_key, database_mysql_flexible_servers in var.database_mysql_flexible_servers : database_mysql_flexible_servers_key => merge(
    {
      name                = "${local.region_code}-mysql-${coalesce(database_mysql_flexible_servers.workload_name, var.project_name)}-${var.environment}-${database_mysql_flexible_servers.instance_name}"
      resource_group_name = azurerm_resource_group.database[database_mysql_flexible_servers.resource_group_key].name
      location            = azurerm_resource_group.database[database_mysql_flexible_servers.resource_group_key].location
    },
    database_mysql_flexible_servers,
    {
      key_vault_id           = module.keyvault[coalesce(database_mysql_flexible_servers.keyvault_key, var.database_default_specification.mysql_flexible_server.key_vault_key)].key_vault.id
      administrator_login    = database_mysql_flexible_servers.administrator_login
      administrator_password = module.keyvault[coalesce(database_mysql_flexible_servers.keyvault_key, var.database_default_specification.mysql_flexible_server.key_vault_key)].password["database_mysql_flexible_server-${database_mysql_flexible_servers_key}"].value
      customer_managed_key = [{
        key_vault_key_id = module.keyvault[coalesce(database_mysql_flexible_servers.keyvault_key, var.database_default_specification.mysql_flexible_server.key_vault_key)].key["database-01"].id
      }]
      authentication = {
        tenant_id      = data.azurerm_client_config.current.tenant_id
        object_id      = module.keyvault[coalesce(database_mysql_flexible_servers.keyvault_key, var.database_default_specification.mysql_flexible_server.key_vault_key)].aad_application["sp-mysql-flexible-server-${database_mysql_flexible_servers_key}"].service_principal_object_id
        principal_name = module.keyvault[coalesce(database_mysql_flexible_servers.keyvault_key, var.database_default_specification.mysql_flexible_server.key_vault_key)].aad_application["sp-mysql-flexible-server-${database_mysql_flexible_servers_key}"].application_display_name
        principal_type = "ServicePrincipal"
      }
      identity = {
        type        = "UserAssigned"
        identity_id = var.regional_shared_resources[var.region].mysql["user_assigned_identity_entra_id_${local.environment_type}_id"]
      }
      active_directory_administrator = { for admin_key, admin in database_mysql_flexible_servers.active_directory_administrator : admin_key => merge(
        admin,
        {
          identity_id = var.regional_shared_resources[var.region].mysql["user_assigned_identity_entra_id_${local.environment_type}_id"]
          login       = coalesce(admin.login, admin_key)
        }
      ) }
      server_configuration = try(coalescelist(database_mysql_flexible_servers.server_configuration, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].server_configuration), null)
      create_mode          = coalesce(database_mysql_flexible_servers.create_mode, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].create_mode)
      version              = coalesce(database_mysql_flexible_servers.version, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].version)
      sku_name             = coalesce(database_mysql_flexible_servers.sku_name, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].sku)
      delegated_subnet_id  = database_mysql_flexible_servers.delegated_subnet_id
      private_dns_zone_id  = database_mysql_flexible_servers.private_dns_zone_id
      zone                 = try(coalesce(database_mysql_flexible_servers.zone, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].zone), null)
      high_availability    = try(coalescelist(database_mysql_flexible_servers.high_availability, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].high_availability), null)
      storage              = try(coalescelist(database_mysql_flexible_servers.storage, var.database_default_specification.mysql_flexible_server["${local.environment_type}"].storage), null)
      private_endpoint = { for private_endpoint_key, private_endpoint in database_mysql_flexible_servers.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name        = coalesce(private_endpoint.instance_name, "01")
            region_code          = coalesce(private_endpoint.region_code, local.region_code)
            location             = coalesce(private_endpoint.location, azurerm_resource_group.database[database_mysql_flexible_servers.resource_group_key].location)
            resource_group_name  = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link["01"].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
            private_dns_zone_ids = private_endpoint.alias == "current" ? [module.dns["privatelink.mysql.database.azure.com"].resource.id] : [var.dns_default_specification.dns_private_zone.privatelink_mysql_database_azure_com.private_dns_zone_id]
            subnet_id            = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix       = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
            ip_configuration     = private_endpoint.ip_configuration
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) }

      tags = merge(lookup(database_mysql_flexible_servers, "tags", local.tags))
    }
  ) if var.database_creation && var.database_default_specification.mysql_flexible_server.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation }

  database_mysql_flexible_dbsqware = { for database_mysql_flexible_servers_key, database_mysql_flexible_servers in var.database_mysql_flexible_servers : "mysql_flexible_server-${database_mysql_flexible_servers_key}" =>
    {
      dbsqware_payload = {
        dbalias        = upper("MYS_AZU${module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].name}")
        rdbmsname      = "MySQL"
        virt_host_name = module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].fqdn
        host_name      = module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].fqdn
        username       = "sp-dbsqware-amt"
        port           = "3306"
        comments       = var.project_name
        contact        = var.project_name
        client         = "AMUNDI"
        env            = upper(contains(["np", "uat"], module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].tags["environment"]) ? "RCT" : module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].tags["environment"] == "dmo" ? "TST" : module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].tags["environment"])
        globalhost     = ""
        custom1        = ""
        custom2        = ""
        dbaname        = ""
        comments_upd   = "insert new instance by API through Terraform"
        custom1        = "https://portal.azure.com/#@amundi.com/resource${module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].id}/overview"
      }
      name_server = module.mysql_flexible_servers.server[database_mysql_flexible_servers_key].name
  } if var.database_creation && var.database_default_specification.mysql_flexible_server.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation }

  database_mysql_flexible_servers_aad_application = { for database_mysql_flexible_servers_key, database_mysql_flexible_servers in var.database_mysql_flexible_servers : "sp-mysql-flexible-server-${database_mysql_flexible_servers_key}" =>
    {
      display_name  = "sp-mysql-flexible-servers-admin-${local.region_code}-${coalesce(database_mysql_flexible_servers.workload_name, var.project_name)}-${var.environment}-${coalesce(database_mysql_flexible_servers.instance_name, database_mysql_flexible_servers_key)}"
      description   = "MySQL Flexible Server application for ${var.project_name}"
      owners        = coalesce(database_mysql_flexible_servers.aad_application, var.database_default_specification.mysql_flexible_server.aad_application).owners
      key_vault_key = coalesce(database_mysql_flexible_servers.keyvault_key, var.database_default_specification.mysql_flexible_server.key_vault_key)
      secret = {
        name         = "sp-mysql-flexible-server-admin"
        version      = database_mysql_flexible_servers.aad_application.version
        display_name = true
        tenant_id    = data.azurerm_client_config.current.tenant_id
        host         = "${local.region_code}-mysql-${coalesce(database_mysql_flexible_servers.workload_name, var.project_name)}-${var.environment}-${database_mysql_flexible_servers.instance_name}.mysql.database.azure.com"
      }
  } if var.database_creation && var.database_default_specification.mysql_flexible_server.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation }

  database_user_assigned_identity = { for key, value in var.database_user_assigned_identity : key => merge(
    {
      name                = "${local.region_code}-id-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
      resource_group_name = azurerm_resource_group.database[value.resource_group_key].name
      location            = azurerm_resource_group.database[value.resource_group_key].location
      tags                = merge(value.tags, local.tags)
    },
    value
  ) if var.database_creation }

  database_dbsqware = { for key, value in merge(local.database_postgresql_flexible_dbsqware, local.database_mysql_flexible_dbsqware, local.database_mssql_dbsqware) : key => merge(
    {
      api_username = "api_terraform"
      api_password = local.shared_services_existing_secret["dbsqware-api-terraform-secret"].value
    },
    value
    )
  }
}
