resource "azurerm_resource_group" "monitor" {
  for_each = local.monitor_resource_group

  name     = "${local.region_code}-rg-${each.value.workload_name}-${var.environment}-${each.value.instance_name}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}


resource "azurerm_application_insights" "monitor" {
  for_each = { for key, value in var.monitor_app_insight : key => value if value.application_insights_create && var.monitor_creation }

  name                = "${local.region_code}-appi-${coalesce(each.value.workload_name, var.project_name)}-${var.environment}-${each.value.instance_name}"
  location            = coalesce(each.value.location, var.region)
  resource_group_name = azurerm_resource_group.monitor[each.value.resource_group_key].name
  workspace_id        = var.regional_shared_resources[var.region].log_analytics_workspace_id
  application_type    = coalesce(each.value.application_type, "web")
  tags                = merge(each.value.tags, local.tags)
}
