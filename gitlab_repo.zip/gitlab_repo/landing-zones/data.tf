data "azurerm_client_config" "current" {}

data "azurerm_subscription" "subscription_id_client" {
  subscription_id = var.subscription_id_client
}
