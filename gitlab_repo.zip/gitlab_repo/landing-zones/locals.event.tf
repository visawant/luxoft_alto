locals {
  event_resource_group = { for key, value in var.event_resource_group : key => value if var.event_creation }

  event_resource_group_role_assignment = tomap({
    for son in
    flatten([
      for father_key, father in var.event_resource_group : [
        for son_key, son in father.role_assignment : {
          key = "${father_key}-${son_key}"
          role_assignment = merge(
            son,
            {
              resource_group_key = father_key
            }
          )
        }
      ]
    ]) : son.key => son.role_assignment if var.event_creation
  })

  event_key_vault_key = var.event_creation ? {
    "event-01" = {
      key_vault_key = var.event_default_specification.event_servicebus_namespace.key_vault_key
      name          = "${var.project_name}-event-01"
    }
  } : {}

  event_servicebus_namespace = { for event_servicebus_namespace_key, event_servicebus_namespace in var.event_servicebus_namespace : event_servicebus_namespace_key => merge(
    {
      name                          = "${local.region_code}-sbns-${lookup(event_servicebus_namespace, "workload_name", var.project_name)}-${var.environment}-${event_servicebus_namespace.instance_name}"
      resource_group_name           = azurerm_resource_group.event[coalesce(event_servicebus_namespace.resource_group_key, "01")].name
      location                      = azurerm_resource_group.event[coalesce(event_servicebus_namespace.resource_group_key, "01")].location
      sku                           = coalesce(event_servicebus_namespace.sku, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].sku)
      capacity                      = coalesce(event_servicebus_namespace.capacity, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].capacity)
      premium_messaging_partitions  = coalesce(event_servicebus_namespace.premium_messaging_partitions, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].premium_messaging_partitions)
      local_auth_enabled            = coalesce(event_servicebus_namespace.local_auth_enabled, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].local_auth_enabled)
      public_network_access_enabled = coalesce(event_servicebus_namespace.public_network_access_enabled, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].public_network_access_enabled)
      minimum_tls_version           = coalesce(event_servicebus_namespace.minimum_tls_version, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].minimum_tls_version)
      key_vault_id                  = module.keyvault[coalesce(event_servicebus_namespace.key_vault_key, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].key_vault_key)].key_vault.id
      customer_managed_key = coalesce(event_servicebus_namespace.sku, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].sku) == "Standard" || coalesce(event_servicebus_namespace.sku, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].sku) == "Basic" ? null : [{
        key_vault_key_id                  = module.keyvault[coalesce(event_servicebus_namespace.key_vault_key, var.event_default_specification.event_servicebus_namespace.key_vault_key)].key["event-01"].id
        infrastructure_encryption_enabled = true
      }]
      queue = { for queue_key, queue in event_servicebus_namespace.queue : queue_key => merge(
        {
          name                                    = coalesce(queue.name, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.name)
          lock_duration                           = try(queue.lock_duration, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.lock_duration)
          duplicate_detection_history_time_window = try(queue.duplicate_detection_history_time_window, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.duplicate_detection_history_time_window)
          requires_duplicate_detection            = try(queue.requires_duplicate_detection, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.requires_duplicate_detection)
          requires_session                        = try(queue.requires_session, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.requires_session)
          forward_to                              = try(queue.forward_to, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.forward_to, null)
          forward_dead_lettered_messages_to       = try(queue.forward_dead_lettered_messages_to, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.forward_dead_lettered_messages_to, null)
          dead_lettering_on_message_expiration    = try(queue.dead_lettering_on_message_expiration, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.dead_lettering_on_message_expiration)
          max_delivery_count                      = try(queue.max_delivery_count, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.max_delivery_count)
          status                                  = try(queue.status, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.status)
          auto_delete_on_idle                     = try(queue.auto_delete_on_idle, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.auto_delete_on_idle)
          default_message_ttl                     = try(queue.default_message_ttl, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.default_message_ttl)
          max_size_in_megabytes                   = try(queue.max_size_in_megabytes, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.max_size_in_megabytes)
          timeouts                                = try(queue.timeouts, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.timeouts)
          authorization_rule                      = try(queue.authorization_rule, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].queue.authorization_rule)
        },
        queue,
        {
          tags = merge(local.tags, lookup(queue, "tags", {}))
        }
        )
      }
      topic = { for topic_key, topic in event_servicebus_namespace.topic : topic_key => merge(
        {
          name                          = coalesce(topic.name, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.name)
          status                        = coalesce(topic.status, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.status)
          auto_delete_on_idle           = coalesce(topic.auto_delete_on_idle, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.auto_delete_on_idle)
          default_message_ttl           = coalesce(topic.default_message_ttl, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.default_message_ttl)
          duplicate_detection_window    = coalesce(topic.duplicate_detection_window, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.duplicate_detection_window)
          express_enabled               = coalesce(topic.express_enabled, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.express_enabled)
          max_message_size_in_kilobytes = coalesce(topic.max_message_size_in_kilobytes, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.max_message_size_in_kilobytes)
          max_size_in_megabytes         = coalesce(topic.max_size_in_megabytes, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.max_size_in_megabytes)
          requires_duplicate_detection  = coalesce(topic.requires_duplicate_detection, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.requires_duplicate_detection)
          support_ordering              = coalesce(topic.support_ordering, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.support_ordering)
          timeouts                      = coalesce(topic.timeouts, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].topic.timeouts)
        },
        topic,
        {
          tags = merge(local.tags, lookup(topic, "tags", {}))
        }
        )
      }
      timeouts = coalesce(event_servicebus_namespace.timeouts, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].timeouts)

    },
    event_servicebus_namespace,
    {
      network_rule_set = [
        for network_rule_set in coalesce(event_servicebus_namespace.network_rule_set, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].network_rule_set) : {
          default_action           = network_rule_set.default_action
          ip_rules                 = var.event_default_specification.event_servicebus_namespace.allow_aviatrix_public_ip ? concat(network_rule_set.ip_rules, local.connectivity_aviatrix_public_ip) : network_rule_set.ip_rules
          trusted_services_allowed = network_rule_set.trusted_services_allowed
          network_rules = [
            for network_rules in network_rule_set.network_rules : {
              subnet_id                            = network_rules.subnet_id
              ignore_missing_vnet_service_endpoint = network_rules.ignore_missing_vnet_service_endpoint
            }
          ]
        }
      ]
      tags = merge(local.tags, lookup(event_servicebus_namespace, "tags", {}))
    },
    {
      private_endpoint = { for private_endpoint_key, private_endpoint in event_servicebus_namespace.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = private_endpoint.instance_name
            region_code         = coalesce(private_endpoint.region_code, local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.event[event_servicebus_namespace.resource_group_key].location) : coalesce(private_endpoint.location, azurerm_resource_group.event[event_servicebus_namespace.resource_group_key].location)
            resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[event_servicebus_namespace.private_link_resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            private_dns_zone_ids = private_endpoint.alias == "current" ? [module.dns["privatelink.servicebus.windows.net"].resource.id] : [var.dns_default_specification.dns_private_zone["privatelink_servicebus_windows_net"].private_dns_zone_id]
            subnet_id            = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix       = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
            ip_configuration     = private_endpoint.ip_configuration
          }
        )
        if coalesce(event_servicebus_namespace.sku, var.event_default_specification.event_servicebus_namespace["${local.environment_type}"].sku) == "Premium" && contains(["current", "shared-services"], private_endpoint.alias) &&
      (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }
    }

  ) if var.event_creation }
}

