locals {
  #The 2 following variable are used to map Amundi products to their respective git repository files.
  git_repository_file_amundi_products_by_product = { for amundi_product in var.azure_devops["01"].amundi_products : amundi_product => var.azure_devops_default_specification.amundi_products[amundi_product].git_repository_file_amundi_products }
  git_repository_file_amundi_products = merge([for key, val in local.git_repository_file_amundi_products_by_product :
    { for k, v in val : k => v if contains(var.azure_devops["01"].amundi_products, key) }
  ]...)

  azure_devops = { for azure_devops_key, azure_devops in var.azure_devops : azure_devops_key => merge(
    {
      resource_group_name = "useless"
    },
    azure_devops,
    {
      devops_project = { for devops_project_key, devops_project in lookup(azure_devops, "devops_project", {}) : devops_project_key => merge(
        {
          name               = "${coalesce(azure_devops.region_code, local.region_code)}-${coalesce(devops_project.workload_name, var.project_name)}-prd-${coalesce(devops_project.instance_name, devops_project_key)}"
          description        = "This is the Azure DevOps project of the application ${var.project_name}"
          create             = var.environment == "prd" ? true : false
          work_item_template = coalesce(devops_project.work_item_template, var.azure_devops_default_specification.work_item_template)
          features           = coalesce(devops_project.features, var.azure_devops_default_specification.features)
        },
        devops_project
      ) }

      git_repository = { for git_repository_key, git_repository in lookup(azure_devops, "git_repository", {}) : git_repository_key => merge(
        {
        },
        git_repository,
        {
          project_key = lookup(git_repository, "project_key", "01")
          name        = lookup(git_repository, "name", git_repository_key)
          create      = var.environment == "prd" ? true : false
        }
      ) }

      git_repository_amundi_products = { for amundi_product in azure_devops.amundi_products : amundi_product => {
        project_key    = "01"
        name           = amundi_product
        create         = var.environment == "prd" ? true : false
        source_url     = var.azure_devops_default_specification.amundi_products[amundi_product].source_url
        init_type      = "Import"
        source_type    = "Git"
        default_branch = null
        username       = var.ADO_SYNC_REPO_USERNAME
        password       = var.ADO_SYNC_REPO_PAT
        }
      }

      git_repository_file = var.environment == "prd" ? { for git_repository_file_key, git_repository_file in lookup(azure_devops, "git_repository_file", {}) : git_repository_file_key => merge(
        {
        },
        git_repository_file,
        {
        }
      ) } : {}

      git_repository_file_amundi_products = { for git_repository_file_key, git_repository_file in local.git_repository_file_amundi_products : git_repository_file_key => merge(
        git_repository_file,
        {
          file                 = "${git_repository_file.prefix_file_path}/${var.environment}/${git_repository_file.file}"
          template_file_path   = git_repository_file.template_file_path
          repository_key       = basename(git_repository_file_key)
          modification_ignored = contains(var.azure_devops_default_specification.amundi_products.template_files_modification_ignored, git_repository_file.file) || git_repository_file.all_files_modification_ignored
          template_values = merge(git_repository_file.template_values,
            {
              product_name            = basename(git_repository_file_key)
              argo-cd-namespace       = "caas-system"
              environment             = var.environment
              acr_name                = replace("${local.region_code}cr${coalesce(var.shared_services_container_registry[azure_devops.acr_key].workload_name, var.project_name)}${var.environment}${var.shared_services_container_registry[azure_devops.acr_key].instance_name}", "-", "")
              azure_devops_url        = "https://dev.azure.com/amundi-technology/${coalesce(azure_devops.region_code, local.region_code)}-${lookup(git_repository_file, "devops_project_workload_name", var.project_name)}-prd-${lookup(git_repository_file, "devops_project_instance", "01")}/_git"
              additional_dependencies = var.azure_devops_default_specification.amundi_products[basename(git_repository_file_key)].dependencies
              dependency              = element(split("/", git_repository_file_key), 1)
              enablers                = var.azure_devops_default_specification.amundi_products[basename(git_repository_file_key)].dependencies
            }
          )
        }
      ) if var.container_creation }

      redis_admin_password = { for amundi_product in azure_devops.amundi_products : "${azure_devops_key}-${amundi_product}" =>
        {
          name         = "${amundi_product}-redis-admin-password"
          keyvault_key = azure_devops.keyvault_key
        } if contains(keys(var.azure_devops_default_specification.amundi_products[amundi_product].dependencies), "redis")
      }

      devops_group = { for key, value in var.azure_devops_group : key => value if
        var.azure_devops_creation && contains(value.environment, var.environment)
      }
    }
  ) if var.azure_devops_creation }

  azure_devops_group_membership = { for azure_devops_key, azure_devops in var.azure_devops : azure_devops_key =>
    { for group_membership_key, group_membership in azure_devops.group_membership : group_membership_key => merge(
      {
      },
      group_membership,
      {
        entra_id_user_member          = concat(group_membership.entra_id_user_member, group_membership.entra_id_user_member_default)
        entra_id_group_member_default = concat(group_membership.entra_id_group_member, group_membership.entra_id_group_member_default)
        entra_id_service_principal_member = concat(
          group_membership.entra_id_service_principal_member,
          !var.init && contains(keys(var.container_aks), azure_devops.container_aks_key) && var.container_creation && var.container_default_specification.aks.create ? [module.aks[azure_devops.container_aks_key].aks_workload_identity["argocd"].principal_id] : []
        )
      }
    ) } if var.azure_devops_creation
  }

  azure_devops_agent_pool = { for agent_pool_key, agent_pool in var.azure_devops_agent_pool : agent_pool_key =>
    merge(
      {
        location                                 = var.region
        postfix                                  = "${coalesce(agent_pool.region_code, local.region_code)}-${coalesce(agent_pool.workload_name, var.project_name)}-${var.environment}${agent_pool.instance_name}"
        log_analytics_workspace_creation_enabled = false
        log_analytics_workspace_id               = var.regional_shared_resources[var.region].log_analytics_workspace_id
        use_default_container_image              = false
        custom_container_registry_images = {
          container_app = {
            task_name       = "a" # This `a` is a dummy value because we don't use ACR task to build image, the image is already built and pushed to ACR
            dockerfile_path = "a" # This `a` is a dummy value because we don't use ACR task to build image, the image is already built and pushed to ACR
            context_path    = "a" # This `a` is a dummy value because we don't use ACR task to build image, the image is already built and pushed to ACR
            image_names     = [var.azure_devops_default_specification.devops_agent.image_name]
          }
          container_instance = {
            task_name       = "a" # This `a` is a dummy value because we don't use ACR task to build image, the image is already built and pushed to ACR
            dockerfile_path = "a" # This `a` is a dummy value because we don't use ACR task to build image, the image is already built and pushed to ACR
            context_path    = "a" # This `a` is a dummy value because we don't use ACR task to build image, the image is already built and pushed to ACR
            image_names     = [var.azure_devops_default_specification.devops_agent.image_name]
          }
        }
        environment_variables = [
          {
            name  = "AZP_TENANTID"
            value = data.azurerm_client_config.current.tenant_id
          },
          /*Not using a service principal because we are using a PAT of an Entra ID account that expires in months, the service principal generate a PAT avaiable for less than one hour and this broke AMT CRM SFE pipeline, see https://git.intramundi.com/docker/azp-agent/-/blob/2025.10.07/Dockerfile?ref_type=heads
                     {
            name  = "AZP_CLIENTID"
            value = var.azure_devops_default_specification.devops_agent.self_hosted_agent_enrolment.client_id
          }, */
        ]
        sensitive_environment_variables = [
          {
            name                      = "AZP_CLIENTSECRET"
            value                     = local.shared_services_existing_secret[var.azure_devops_default_specification.devops_agent.self_hosted_agent_enrolment.client_secret_key].value
            container_app_secret_name = var.azure_devops_default_specification.devops_agent.self_hosted_agent_enrolment.container_app_secret_name
          },
        ]
        version_control_system_organization                  = var.azure_devops_default_specification.org_service_url
        version_control_system_type                          = "azuredevops"
        compute_types                                        = var.azure_devops_default_specification.devops_agent.compute_types
        container_app_subnet_id                              = azurerm_subnet.connectivity[agent_pool.container_app_subnet_key].id
        container_instance_count                             = var.azure_devops_default_specification.devops_agent.container_instance_count
        container_instance_subnet_id                         = azurerm_subnet.connectivity[agent_pool.container_instance_subnet_key].id
        container_registry_creation_enabled                  = false
        custom_container_registry_login_server               = "${basename(module.acr[var.container_default_specification.container_app.acr_key].container_registry.id)}.azurecr.io"
        custom_container_registry_id                         = module.acr[var.container_default_specification.container_app.acr_key].container_registry.id
        container_registry_private_dns_zone_creation_enabled = false
        resource_group_creation_enabled                      = false
        resource_group_name                                  = azurerm_resource_group.azure_devops[var.azure_devops_default_specification.resource_group_key].name
        container_app_infrastructure_resource_group_name     = replace(azurerm_resource_group.azure_devops[var.azure_devops_default_specification.resource_group_key].name, "01", "02")
        tags                                                 = merge(lookup(agent_pool, "tags", local.tags))
        version_control_system_personal_access_token         = var.ADO_SYNC_REPO_PAT
        nat_gateway_creation_enabled                         = false
        public_ip_creation_enabled                           = false
        virtual_network_creation_enabled                     = false
        virtual_network_id                                   = azurerm_virtual_network.connectivity[agent_pool.virtual_network_key].id
      },
      agent_pool,
      {
        name = "${coalesce(agent_pool.region_code, local.region_code)}-agp-${coalesce(agent_pool.workload_name, var.project_name)}-${var.environment}-${agent_pool.instance_name}"
      }
    ) if var.azure_devops_creation && var.azure_devops_default_specification.devops_agent_create
  }

  azure_devops_variable_group = { for azure_devops_key, azure_devops in var.azure_devops : azure_devops_key => {
    devops_project = { for devops_project_key, devops_project in lookup(azure_devops, "devops_project", {}) : devops_project_key =>
      {
        for variable_group_key, variable_group in devops_project.variable_group : variable_group_key => merge(
          variable_group,
          {
            project_key = devops_project_key
            variable = { for variable_key, variable in variable_group.variable : variable_key => merge(variable, {
              secret_value = coalesce(variable.secret_value, local.shared_services_existing_secret[variable.secret_key].value)
              })
            }
          }
        )
      }
    }
  } if var.azure_devops_creation && var.environment == "prd" }
}
