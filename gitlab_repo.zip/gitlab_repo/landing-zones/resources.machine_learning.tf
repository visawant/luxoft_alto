resource "azurerm_resource_provider_registration" "machine_learning" {
  for_each = { for key, value in toset(var.machine_learning_default_specification.required_resource_provider) : key => value if var.machine_learning_creation }
  name     = each.value

  lifecycle {
    ignore_changes = [
      # Ignoring the following parameters because we will manage the secret lifecycle outside from terraform
      feature
    ]
  }
}

resource "azurerm_resource_group" "machine_learning" {
  depends_on = [azurerm_resource_provider_registration.machine_learning]
  for_each   = local.machine_learning_resource_group

  name     = "${var.region_code[coalesce(each.value.location, var.region)]}-rg-machine-learning-${var.environment}-${each.value.instance_name}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}

resource "azurerm_role_assignment" "machine_learning_resource_group" {
  for_each = local.machine_learning_resource_group_role_assignment

  scope                = azurerm_resource_group.machine_learning[each.value.resource_group_key].id
  role_definition_name = each.value.role_definition_name
  principal_id         = each.value.principal_id
  principal_type       = each.value.principal_type
}

resource "azurerm_application_insights" "machine_learning" {
  for_each = { for key, value in var.machine_learning_workspace_hub : key => value if value.application_insights_create && var.machine_learning_creation }

  name                = "${var.region_code[azurerm_resource_group.machine_learning[coalesce(each.value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location]}-appi-${coalesce(each.value.workload_name, var.project_name)}-${var.environment}-${each.value.instance_name}"
  location            = azurerm_resource_group.machine_learning[coalesce(each.value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].location
  resource_group_name = azurerm_resource_group.machine_learning[coalesce(each.value.resource_group_key, var.machine_learning_default_specification.resource_group_key)].name
  workspace_id        = var.regional_shared_resources[var.region].log_analytics_workspace_id
  application_type    = "web"
  tags                = merge(local.tags, each.value.tags)
}
