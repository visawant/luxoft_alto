locals {
  include_subscription_tags = {
    for key, value in data.azurerm_subscription.subscription_id_client.tags :
    key => value if contains(["ops_team", "it_owner", "project_name"], key)
  }
}

/*locals {
  exclude_subscription_tags = {
    for key, value in data.azurerm_subscription.subscription_id_client.tags :
    key => value if key != "name"
  }
}

{                               Exclude few tags
    for key, value in data.azurerm_subscription.subscription_id_client.tags :
    key => value if !contains(["sensitive_data", "legacy_tag"], key)
  }
*/
