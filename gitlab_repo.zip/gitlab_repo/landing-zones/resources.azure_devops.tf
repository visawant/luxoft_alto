resource "azapi_resource_action" "azure_devops" {
  for_each = { for key, value in var.azure_devops_default_specification.required_resource_provider : key => value if var.azure_devops_creation }

  action      = "providers/${each.value.resource_provider}/register"
  method      = "POST"
  resource_id = "/subscriptions/${var.subscription_id_client}"
  type        = "Microsoft.Resources/subscriptions@2021-04-01"
}

resource "azurerm_resource_group" "azure_devops" {
  depends_on = [azapi_resource_action.azure_devops]
  for_each   = { for key, value in var.azure_devops_resource_group : key => value if var.azure_devops_creation }

  name     = "${local.region_code}-rg-azure-devops-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
