locals {
  app_service_resource_group = { for key, value in var.app_service_resource_group : key => value if var.app_service_creation }

  app_service_storage_account = { for key, value in var.app_service : "app_service_storage_account_${key}" => merge(
    {
      name                          = substr(replace("${local.region_code}-func-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.app_service_storage_account.instance_name}", "-", ""), 0, 24)
      resource_group_name           = azurerm_resource_group.app_service[value.resource_group_key].name
      location                      = azurerm_resource_group.app_service[value.resource_group_key].location
      account_tier                  = coalesce(value.app_service_storage_account.account_tier, "Standard")
      account_kind                  = coalesce(value.app_service_storage_account.account_kind, "StorageV2")
      is_hns_enabled                = coalesce(value.app_service_storage_account.is_hns_enabled, false)
      account_replication_type      = var.environment == "prd" ? "ZRS" : "LRS"
      role_assignment               = value.app_service_storage_account.role_assignment
      share                         = value.app_service_storage_account.share
      public_network_access_enabled = coalesce(value.public_network_access_enabled, false)
      network_rules                 = value.app_service_storage_account.network_rules
    },
    value.app_service_storage_account,
    {
      private_endpoint = { for private_endpoint_key, private_endpoint in value.app_service_storage_account.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = private_endpoint.instance_name
            region_code         = coalesce(private_endpoint.region_code, local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.app_service[private_endpoint.resource_group_key].location) : coalesce(private_endpoint.location, azurerm_resource_group.app_service[private_endpoint.resource_group_key].location)
            resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, private_endpoint.resource_group_custom ? null : azurerm_resource_group.private_link[private_endpoint.private_link_resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
            dns_private_zone_id = private_endpoint.alias == "current" ? (private_endpoint.dns_custom ? private_endpoint.private_dns_zone_ids : module.dns["privatelink.${private_endpoint.subresource_name}.core.windows.net"].resource.id) : var.dns_default_specification.dns_private_zone["privatelink_${private_endpoint.subresource_name}_core_windows_net"].private_dns_zone_id
            subnet_id           = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix      = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
            ip_configuration    = private_endpoint.ip_configuration
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      tags = merge(local.tags, value.app_service_storage_account.tags)
    }
    ) if var.app_service_creation
  }

  app_service_plans = { for app_service_plans_key, app_service_plans in var.app_service_plans : app_service_plans_key => merge(
    {
      name                = "${local.region_code}-asp-${coalesce(app_service_plans.workload_name, var.project_name)}-${var.environment}-${app_service_plans.instance_name}"
      resource_group_name = azurerm_resource_group.app_service[coalesce(app_service_plans.resource_group_key, "01")].name
      location            = azurerm_resource_group.app_service[coalesce(app_service_plans.resource_group_key, "01")].location
      os_type             = coalesce(app_service_plans.os_type, var.app_service_default_specification.app_service.app_service_plans.os_type)
      sku_name            = coalesce(app_service_plans.sku_name, var.app_service_default_specification.app_service.app_service_plans.sku_name)
    },
    app_service_plans,
    {
      tags = merge(local.tags, coalesce(app_service_plans.tags, {}))
    }
  ) if var.app_service_creation }

  app_service = { for app_service_key, app_service in var.app_service : app_service_key => merge(
    {
      name                                           = "${local.region_code}-func-${coalesce(app_service.workload_name, var.project_name)}-${var.environment}-${app_service.instance_name}"
      resource_group_name                            = azurerm_resource_group.app_service[app_service.resource_group_key].name
      location                                       = azurerm_resource_group.app_service[app_service.resource_group_key].location
      kind                                           = coalesce(app_service.kind, var.app_service_default_specification.app_service.kind)
      https_only                                     = coalesce(app_service.https_only, var.app_service_default_specification.app_service.https_only)
      virtual_network_subnet_id                      = azurerm_subnet.connectivity[coalesce(app_service.subnet_key, var.app_service_default_specification.app_service.subnet_key)].id
      public_network_access_enabled                  = coalesce(app_service.public_network_access_enabled, var.app_service_default_specification.app_service.public_network_access_enabled)
      ftp_publish_basic_authentication_enabled       = coalesce(app_service.ftp_publish_basic_authentication_enabled, var.app_service_default_specification.app_service.ftp_publish_basic_authentication_enabled)
      webdeploy_publish_basic_authentication_enabled = coalesce(app_service.webdeploy_publish_basic_authentication_enabled, var.app_service_default_specification.app_service.webdeploy_publish_basic_authentication_enabled)
      site_config                                    = coalesce(app_service.site_config, var.app_service_default_specification.app_service.site_config)
      key_vault_id                                   = coalesce(app_service.enable_key_vault_roles, true) ? module.keyvault[coalesce(app_service.key_vault_key, var.app_service_default_specification.app_service.key_vault_key)].key_vault.id : null
      app_settings = merge(
        coalesce(app_service.app_settings, var.app_service_default_specification.app_service.app_settings, {}),
        {
          "AzureWebJobsStorage__credential" = coalesce(app_service.AzureWebJobsStorage__credential, var.app_service_default_specification.app_service.AzureWebJobsStorage__credential)
        }
      )
      managed_identities = {
        system_assigned = coalesce(app_service.managed_identities.system_assigned, var.app_service_default_specification.app_service.managed_identities.system_assigned)
      }
      storage_uses_managed_identity = coalesce(app_service.storage_uses_managed_identity, var.app_service_default_specification.app_service.storage_uses_managed_identity)
    },
    app_service,
    {
      application_insights = {
        name                  = "${local.region_code}-appi-${coalesce(app_service.workload_name, var.project_name)}-${var.environment}-${app_service.instance_name}"
        workspace_resource_id = var.regional_shared_resources[var.region].log_analytics_workspace_id
        tags                  = merge(coalesce(app_service.application_insights.tags, {}), local.tags)
      }
      private_endpoint = { for private_endpoint_key, private_endpoint in app_service.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name        = private_endpoint.instance_name
            region_code          = coalesce(private_endpoint.region_code, local.region_code)
            location             = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.app_service[app_service.resource_group_key].location) : coalesce(private_endpoint.location, azurerm_resource_group.app_service[app_service.resource_group_key].location)
            resource_group_name  = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, private_endpoint.resource_group_custom ? null : azurerm_resource_group.private_link[private_endpoint.private_link_resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"
            private_dns_zone_ids = private_endpoint.alias == "current" ? (private_endpoint.dns_custom ? [lookup(private_endpoint, "private_dns_zone_ids", null)] : [module.dns["privatelink.azurewebsites.net"].resource.id]) : [var.dns_default_specification.dns_private_zone["privatelink_azure_websites_net"].private_dns_zone_id]
            subnet_id            = private_endpoint.alias == "current" ? coalesce(private_endpoint.subnet_id, private_endpoint.custom_subnet_id ? null : azurerm_subnet.connectivity[private_endpoint.subnet_key].id) : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix       = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
            ip_configuration     = private_endpoint.ip_configuration
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }
      tags = merge(local.tags, coalesce(app_service.tags), {})
    }
  ) if var.app_service_creation }
}
