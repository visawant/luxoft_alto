# landing-zones

Terraform module to create application landing zone respecting the following [guidelines](https://confluence.intramundi.com/display/ITSPCI/Terraform+guidelines).
