resource "azurerm_resource_group" "event" {
  for_each = local.event_resource_group

  name     = "${local.region_code}-rg-${each.value.workload_name}-${var.environment}-${each.value.instance_name}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}

resource "azurerm_role_assignment" "event" {
  for_each = local.event_resource_group_role_assignment

  scope                = azurerm_resource_group.database[each.value.resource_group_key].id
  role_definition_name = each.value.role_definition_name
  principal_id         = each.value.principal_id
  principal_type       = each.value.principal_type
}
