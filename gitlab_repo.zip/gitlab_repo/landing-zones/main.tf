module "acr" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/acr/azurerm"
  version = "0.2.5"

  for_each              = local.shared_services_container_registry
  resource_group_name   = each.value.resource_group_name
  location              = each.value.location
  name                  = each.value.name
  acr_sku               = each.value.sku
  private_endpoint      = each.value.private_endpoint
  role_assignment       = each.value.role_assignment
  export_policy_enabled = each.value.export_policy_enabled
  encryption            = each.value.encryption

  tags = each.value.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "aks" {
  depends_on = [aviatrix_spoke_ha_gateway.connectivity]
  source     = "artifactory.intramundi.com/terraform-virtual__corporate/aks/azurerm"
  version    = "0.2.24"

  for_each                                         = local.container_aks
  resource_group_name                              = each.value.resource_group_name
  node_resource_group                              = each.value.node_resource_group
  location                                         = each.value.location
  name                                             = each.value.name
  tenant_id                                        = each.value.tenant_id
  kubernetes_version                               = each.value.kubernetes_version
  workload_identity_enabled                        = each.value.workload_identity_enabled
  workload_identity                                = each.value.workload_identity
  customer_managed_key                             = each.value.customer_managed_key
  default_node_pool                                = each.value.default_node_pool
  automatic_upgrade_channel                        = each.value.automatic_upgrade_channel
  maintenance_window_auto_upgrade                  = each.value.maintenance_window_auto_upgrade
  image_cleaner                                    = each.value.image_cleaner
  node_pool                                        = each.value.node_pool
  network_profile                                  = each.value.network_profile
  aks_subnet_id                                    = each.value.aks_subnet_id
  aks_vnet_name                                    = each.value.aks_vnet_name
  aks_vnet_id                                      = each.value.aks_vnet_id
  aks_network_security_group_ids                   = each.value.aks_network_security_group_ids
  aks_route_table_ids                              = each.value.aks_route_table_ids
  aks_private_dns_id                               = each.value.aks_private_dns_id
  azure_intramundi_private_dns_id                  = each.value.azure_intramundi_private_dns_id
  blob_private_dns_id                              = each.value.blob_private_dns_id
  disk_access                                      = each.value.disk_access
  private_endpoint                                 = each.value.private_endpoint
  log_analytics_workspace                          = each.value.log_analytics_workspace
  service_mesh_profile                             = each.value.service_mesh_profile
  key_vault_secrets_provider                       = each.value.key_vault_secrets_provider
  azure_active_directory_role_based_access_control = each.value.azure_active_directory_role_based_access_control
  aks_paired_keyvaults_scopes                      = each.value.aks_paired_keyvaults_scopes
  aks_attach_registries_scopes                     = each.value.aks_attach_registries_scopes
  aks_file_shares_scopes                           = each.value.aks_file_shares_scopes
  federated_identity_credential                    = each.value.federated_identity_credential
  workbook                                         = each.value.workbook
  prometheus                                       = each.value.prometheus
  role_assignment                                  = each.value.role_assignment
  tags                                             = merge(local.tags, lookup(each.value, "tags", {}))

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
    azurerm.networking          = azurerm.networking
  }
}

module "aks-post-install" {
  depends_on = [module.aks]
  source     = "artifactory.intramundi.com/terraform-virtual__corporate/aks-post-install/azurerm"
  version    = "0.1.42"

  for_each            = local.container_aks_post_install
  helm_release        = { for key, value in each.value.helm_release : key => value if value != null }
  prometheus_password = local.shared_services_existing_secret["prometheus-basic-auth-${local.environment_type}-raw-secret"].value
}

module "app-service" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/app-services/azurerm"
  version = "0.0.16"

  app_service       = local.app_service
  app_service_plans = local.app_service_plans
  storage_account   = local.app_service_storage_account
  tags              = local.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "application-gateway" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/application-gateway/azurerm"
  version = "0.1.0"

  for_each                                 = local.connectivity_application_gateway
  name                                     = each.value.name
  location                                 = each.value.location
  resource_group_name                      = each.value.resource_group_name
  http2                                    = each.value.http2
  sku                                      = each.value.sku
  gateway_ip_configuration                 = each.value.gateway_ip_configuration
  frontend_port                            = each.value.frontend_port
  frontend_ip_configuration                = each.value.frontend_ip_configuration
  backend_address_pool                     = each.value.backend_address_pool
  backend_http_settings                    = each.value.backend_http_settings
  http_listener                            = each.value.http_listener
  request_routing_rule                     = each.value.request_routing_rule
  agw_paired_keyvaults_scopes              = each.value.agw_paired_keyvaults_scopes
  ssl_certificates                         = each.value.ssl_certificates
  probes                                   = each.value.probes
  azure_intramundi_com_private_dns_zone_id = var.dns_default_specification.dns_private_zone.azure_intramundi_com.private_dns_zone_id
  tags                                     = each.value.tags
  providers = {
    azurerm.dns = azurerm.dns
  }
}

module "azure-devops" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/azure-devops/azurerm"
  version = "0.1.15"

  for_each                            = local.azure_devops
  devops_project                      = each.value.devops_project
  git_repository                      = merge(each.value.git_repository, each.value.git_repository_amundi_products)
  git_repository_file                 = each.value.git_repository_file
  git_repository_file_amundi_products = each.value.git_repository_file_amundi_products
  group_membership                    = local.azure_devops_group_membership[each.key]
  agent_pool                          = local.azure_devops_agent_pool
  devops_group                        = each.value.devops_group
  variable_group                      = { for k, v in local.azure_devops_variable_group : k => v.devops_project[each.key][each.key] if k == each.key }
  tags                                = merge(lookup(each.value, "tags", {}), local.tags)
}

module "azure_region" {
  source  = "claranet/regions/azurerm"
  version = "~> 7.0"

  azure_region = var.region
}

module "backup" {
  /*   source  = "artifactory.intramundi.com/terraform-virtual__corporate/backup/azurerm"
  version = "0.1.0" */
  source = "git::https://git.intramundi.com/public-cloud-infrastructure/microsoft-azure/terraform/modules/backup.git?ref=main"

  for_each     = local.backup_vault
  backup_vault = each.value

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "bastion" {
  source  = "Azure/avm-res-network-bastionhost/azurerm"
  version = "0.4.0"

  enable_telemetry = var.avm_enable_telemetry

  for_each               = local.bastion
  name                   = "${local.region_code}-bas-${lookup(each.value, "workload_name", var.project_name)}-${var.environment}-${lookup(each.value, "instance_name", each.key)}"
  resource_group_name    = azurerm_resource_group.bastion[lookup(each.value, "resource_group_key", "01")].name
  location               = azurerm_resource_group.bastion[lookup(each.value, "resource_group_key", "01")].location
  sku                    = var.bastion_sku
  copy_paste_enabled     = lookup(var.bastion_default_specification[var.bastion_sku], "copy_paste_enabled", null)
  file_copy_enabled      = lookup(var.bastion_default_specification[var.bastion_sku], "file_copy_enabled", null)
  ip_connect_enabled     = lookup(var.bastion_default_specification[var.bastion_sku], "ip_connect_enabled", null)
  scale_units            = lookup(var.bastion_default_specification[var.bastion_sku], "scale_units", null)
  shareable_link_enabled = lookup(var.bastion_default_specification[var.bastion_sku], "shareable_link_enabled", null)
  tunneling_enabled      = lookup(var.bastion_default_specification[var.bastion_sku], "tunneling_enabled", null)
  kerberos_enabled       = lookup(var.bastion_default_specification[var.bastion_sku], "kerberos_enabled", null)
  ip_configuration       = var.bastion_sku != "Developer" ? local.bastion[each.key].ip_configuration : null
  virtual_network_id     = var.bastion_sku == "Developer" ? local.bastion[each.key].virtual_network_id : null
  tags                   = merge(local.tags, lookup(each.value, "tags", {}))
}

module "containerapp" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/containerapp/azurerm"
  version = "0.0.4"

  container_app_environment = local.container_app_environment
  container_app             = local.container_app

  tags = local.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "dbsqware" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/dbsqware/azurerm"
  version = "0.0.2"

  for_each         = local.database_dbsqware
  dbsqware_payload = each.value.dbsqware_payload
  name_server      = each.value.name_server
  api_username     = each.value.api_username
  api_password     = each.value.api_password
}

module "dns" {
  source  = "Azure/avm-res-network-privatednszone/azurerm"
  version = "0.3.4"

  enable_telemetry = var.avm_enable_telemetry

  for_each              = local.dns_private_zone
  domain_name           = each.value.domain_name
  resource_group_name   = azurerm_resource_group.dns[lookup(each.value, "resource_group_key", "01")].name
  virtual_network_links = { for key, value in local.dns_virtual_network_links : key => value if value.private_zone_key == each.key }
  soa_record            = lookup(each.value, "soa_record", var.dns_default_specification.soa_record)
  a_records             = { for key, value in local.dns_private_zone_a_records : key => value if value.dns_private_zone_key == each.key }
  tags                  = merge(local.tags, lookup(each.value, "tags", var.dns_default_specification.dns_private_zone.tags))
}

module "dns-resolver" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/dns-resolver/azurerm"
  version = "0.2.5"

  for_each                   = local.dns_private_resolver
  azure_dns_private_resolver = each.value.azure_dns_private_resolver
  vmss_private_resolver      = each.value.vmss_private_resolver
  tags                       = merge(local.tags, lookup(each.value, "tags", {}))
}

module "dns_zones" {
  source  = "Azure/avm-res-network-dnszone/azurerm"
  version = "0.2.1"

  for_each            = local.dns_public_zone
  name                = each.value.name
  resource_group_name = each.value.resource_group_name
  tags                = each.value.tags
  caa_records         = each.value.caa_records
  aaaa_records        = each.value.aaaa_records
  ns_records          = each.value.ns_records
  a_records           = each.value.a_records
  cname_records       = each.value.cname_records
  mx_records          = each.value.mx_records
  ptr_records         = each.value.ptr_records
  srv_records         = each.value.srv_records
  txt_records         = each.value.txt_records
  enable_telemetry    = each.value.enable_telemetry
}

module "event" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/event/azurerm"
  version = "0.0.10"

  event_servicebus_namespace = local.event_servicebus_namespace

  tags = local.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "flex-postgre" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/flex-postgre/azurerm"
  version = "0.1.6"

  for_each                       = local.database_postgresql_flexible_server
  name_server                    = each.value.name_server
  location                       = each.value.location
  resource_group_name            = each.value.resource_group_name
  auto_grow_enabled              = each.value.auto_grow_enabled
  storage_mb                     = each.value.storage_mb
  login                          = each.value.login
  password                       = each.value.password
  authentication                 = each.value.authentication
  active_directory_administrator = each.value.active_directory_administrator
  sku                            = each.value.sku
  version_db                     = each.value.version_db
  delegated_subnet_id            = each.value.delegated_subnet_id
  private_dns_zone_id            = each.value.private_dns_zone_id
  private_endpoint               = each.value.private_endpoint
  zone                           = each.value.zone
  high_availability              = each.value.high_availability
  database                       = each.value.database
  server_configuration           = each.value.server_configuration
  tags                           = each.value.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "keyvault" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/keyvault/azurerm"
  version = "0.1.20"

  for_each                      = local.shared_services_key_vault
  resource_group_name           = each.value.resource_group_name
  location                      = each.value.location
  name                          = each.value.name
  tenant_id                     = data.azurerm_client_config.current.tenant_id
  private_endpoint              = each.value.private_endpoint
  public_network_access_enabled = each.value.public_network_access_enabled
  network_acls                  = each.value.network_acls
  secret                        = each.value.secret
  certificate                   = each.value.certificate
  key                           = each.value.key
  role_assignment               = each.value.role_assignment
  access_policy                 = each.value.access_policy
  aad_application               = each.value.aad_application
  sku_name                      = each.value.sku_name
  enable_rbac_authorization     = each.value.enable_rbac_authorization
  microsoft_graph               = var.microsoft_graph

  tags = each.value.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "machine-learning" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/machine-learning/azurerm"
  version = "0.0.14"

  ai_services       = local.machine_learning.ai_services
  workspace_hub     = local.machine_learning.workspace_hub
  cognitive_account = local.machine_learning.cognitive_account
  project           = local.machine_learning.project
  model             = local.machine_learning.model
  storage_account   = local.machine_learning.storage_account
  tags              = local.machine_learning.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "mssql" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/mssql/azurerm"
  version = "0.0.5"

  mssql_servers  = local.database_mssql_server
  mssql_database = local.database_mssql_database
  tags           = local.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "mysql_flexible_servers" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/mysqlflex/azurerm"
  version = "0.0.7"

  mysql_flexible_servers = local.database_mysql_flexible_servers
  tags                   = local.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "private_link" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/private-link/azurerm"
  version = "0.1.5"

  for_each                                 = local.private_link
  region                                   = azurerm_resource_group.private_link[lookup(each.value, "resource_group_key", "01")].location
  resource_group_name                      = azurerm_resource_group.private_link[lookup(each.value, "resource_group_key", "01")].name
  tags                                     = local.tags
  private_endpoint                         = local.private_link_private_endpoint
  azure_intramundi_com_private_dns_zone_id = var.dns_default_specification.dns_private_zone.azure_intramundi_com.private_dns_zone_id

  providers = {
    azurerm                     = azurerm
    azurerm.dns                 = azurerm.dns
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "private_link_forwarding_rule" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/private-link-forwarding-rule/azurerm"
  version = "0.1.8"

  for_each                                                  = local.private_link_forwarding_rule
  location                                                  = each.value.location
  additional_tags                                           = each.value.additional_tags
  virtual_machine_scale_set_name                            = each.value.virtual_machine_scale_set_name
  private_link_service_name                                 = each.value.private_link_service_name
  lb_name                                                   = each.value.lb_name
  prefix                                                    = each.value.prefix
  suffix                                                    = each.value.suffix
  resource_group_name                                       = each.value.resource_group_name
  subnet_id_private_link                                    = each.value.subnet_id_private_link
  subnet_id_load_balancer                                   = each.value.subnet_id_load_balancer
  subnet_id_virtual_machine_scale_set                       = each.value.subnet_id_virtual_machine_scale_set
  forwarding_rules                                          = each.value.forwarding_rules
  vmss_linux_admin                                          = each.value.vmss_linux_admin
  custom_network_interface_backend_address_pool_association = each.value.custom_network_interface_backend_address_pool_association
  private_link_service_visibility_subscription_ids          = each.value.private_link_service_visibility_and_auto_approval_subscription_ids
  private_link_service_auto_approval_subscription_ids       = each.value.private_link_service_visibility_and_auto_approval_subscription_ids
  customer_managed_key                                      = each.value.customer_managed_key
}

module "storage" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/storage/azurerm"
  version = "0.1.10"

  for_each                         = local.shared_services_storage_account
  resource_group_name              = each.value.resource_group_name
  location                         = each.value.location
  name                             = each.value.name
  account_tier                     = each.value.account_tier
  account_kind                     = each.value.account_kind
  is_hns_enabled                   = each.value.is_hns_enabled
  account_replication_type         = each.value.account_replication_type
  role_assignment                  = each.value.role_assignment
  container                        = each.value.container
  share                            = each.value.share
  customer_managed_key             = each.value.customer_managed_key
  private_endpoint                 = each.value.private_endpoint
  public_network_access_enabled    = each.value.public_network_access_enabled
  cross_tenant_replication_enabled = each.value.cross_tenant_replication_enabled
  allowed_copy_scope               = each.value.allowed_copy_scope
  allow_nested_items_to_be_public  = each.value.allow_nested_items_to_be_public
  network_rules                    = each.value.network_rules
  blob_properties                  = each.value.blob_properties
  management_policy                = each.value.management_policy
  tags                             = each.value.tags

  providers = {
    azurerm                     = azurerm
    azurerm.shared_services_np  = azurerm.shared_services_np
    azurerm.shared_services_prd = azurerm.shared_services_prd
  }
}

module "virtual-desktop" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/virtual-desktop/azurerm"
  version = "0.0.1"

  for_each            = local.virtual_desktop
  location            = each.value.location
  resource_group_name = each.value.resource_group_name
  tags                = each.value.tags
  host_pool           = each.value.host_pool
  application_group   = each.value.application_group
  desktop_application = each.value.desktop_application
}

module "vm" {
  source  = "artifactory.intramundi.com/terraform-virtual__corporate/vm/azurerm"
  version = "0.1.3"

  for_each               = local.iaas_vm
  type                   = each.value.type
  name                   = each.value.name
  name_interface         = each.value.name_interface
  resource_group_name    = each.value.resource_group_name
  location               = each.value.location
  subnet_id              = each.value.subnet_id
  vm_ip                  = each.value.vm_ip
  size                   = each.value.size
  user                   = each.value.user
  password               = each.value.password
  vm-shutdown            = each.value.vm-shutdown
  daily_recurrence_time  = each.value.daily_recurrence_time
  timezone               = each.value.timezone
  disk                   = each.value.disk
  adddisk                = each.value.adddisk
  source_image_reference = each.value.source_image_reference
  extension              = each.value.extension
  tags                   = each.value.tags
}
