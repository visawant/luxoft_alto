locals {
  connectivity_resource_group = { for key, value in var.connectivity_resource_group : key => value if var.virtual_network_creation }

  connectivity_virtual_network = { for key, value in var.connectivity_virtual_network : key => value if var.virtual_network_creation }

  # Récupérer toutes les clés uniques des deux maps
  connectivity_security_rule_all_keys = distinct(concat(keys(var.connectivity_network_security_group_rules_default_specification), keys(var.connectivity_network_security_group_rules_additional_specification)))

  # Fusionner les listes d'objets pour chaque clé
  connectivity_security_rule = {
    for k in local.connectivity_security_rule_all_keys : k => concat(
      lookup(var.connectivity_network_security_group_rules_default_specification, k, []),
      lookup(var.connectivity_network_security_group_rules_additional_specification, k, [])
    )
  }

  connectivity_network_security_group = { for network_security_group_key, network_security_group in local.connectivity_subnet : network_security_group_key => merge(
    network_security_group,
    {
      name                = network_security_group.name == "AzureBastionSubnet" ? "${local.region_code}-nsg-azure-bastion-01" : "${local.region_code}-${replace(network_security_group.name, "snet", "nsg")}"
      location            = azurerm_resource_group.connectivity[network_security_group.virtual_network_key].location
      resource_group_name = azurerm_resource_group.connectivity[network_security_group.virtual_network_key].name
      tags                = merge(local.tags, azurerm_resource_group.connectivity[network_security_group.virtual_network_key].tags, lookup(network_security_group, "tags", {}))
      security_rule = [for security_rule in local.connectivity_security_rule[
        //Select the correct network security group rules depending on the subnet name
        network_security_group.name == "AzureBastionSubnet" ? "azure_bastion" : can(regex("snet-aviatrix-spoke-gateway", network_security_group.name)) ? "aviatrix" : can(regex("snet-application-gateway", network_security_group.name)) ? "application_gateway" : "default"
        ] : {
        description           = security_rule.description == null ? null : substr(security_rule.description, 0, 140)
        direction             = security_rule.direction
        name                  = coalesce(security_rule.name, "${security_rule.suffix_name}${security_rule.direction}")
        access                = security_rule.access
        priority              = security_rule.priority
        source_address_prefix = security_rule.source_address_prefix
        source_address_prefixes = try(
          coalesce(
            security_rule.source_address_prefixes,
            concat(
              flatten([for source_subnet_key in security_rule.source_subnet_key : azurerm_subnet.connectivity[source_subnet_key == "current_subnet" ? network_security_group_key : source_subnet_key].address_prefixes]),
              flatten([for source_virtual_network_key in security_rule.source_virtual_network_key : azurerm_virtual_network.connectivity[source_virtual_network_key].address_space])
            )
          ),
        ["192.168.0.255"]) //This is a workaround to deal with non existing subnet
        source_application_security_group_ids = security_rule.source_application_security_group_ids
        destination_address_prefix            = security_rule.destination_address_prefix
        destination_address_prefixes = try(
          coalesce(
            security_rule.destination_address_prefixes,
            concat(
              flatten([for destination_subnet_key in security_rule.destination_subnet_key : azurerm_subnet.connectivity[destination_subnet_key == "current_subnet" ? network_security_group_key : destination_subnet_key].address_prefixes]),
              flatten([for destination_virtual_network_key in security_rule.destination_virtual_network_key : azurerm_virtual_network.connectivity[destination_virtual_network_key].address_space])
            )
          ), ["192.168.0.255"]
        ) //This is a workaround to deal with non existing subnet
        destination_application_security_group_ids = security_rule.destination_application_security_group_ids
        destination_port_range                     = security_rule.destination_port_range
        destination_port_ranges                    = security_rule.destination_port_ranges
        protocol                                   = security_rule.protocol
        source_port_range                          = security_rule.source_port_range
        source_port_ranges                         = security_rule.source_port_ranges
        }
      ]
    }
  ) if var.virtual_network_creation }

  connectivity_route_table = { for key, value in var.connectivity_route_table : key => value if var.virtual_network_creation }

  connectivity_public_ip = merge(
    { for key, value in var.connectivity_public_ip : key => value if var.virtual_network_creation },
    { for spoke_gateway_key, spoke_gateway in merge(local.connectivity_aviatrix_gateway, local.connectivity_aviatrix_gateway_private_link_forwarding_rule) : "aviatrix-gw-${spoke_gateway_key}" => merge(spoke_gateway, {
      location            = azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].location
      resource_group_name = azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].resource_group_name
      workload_name       = spoke_gateway.gateway_type == "specialty" ? "aviatrix-specialty-${var.project_name}" : "aviatrix-${var.project_name}"
      instance_name       = spoke_gateway.instance_name
      zones               = var.connectivity_aviatrix_gateway_default_specification.public_ip.zones
      allocation_method   = lookup(spoke_gateway, "allocation_method", var.connectivity_aviatrix_gateway_default_specification.public_ip.allocation_method)
      sku                 = lookup(spoke_gateway, "sku", var.connectivity_aviatrix_gateway_default_specification.public_ip.sku)
    }) if var.connectivity_aviatrix_gateway_default_specification.allocate_new_eip != true },
    { for spoke_gateway_key, spoke_gateway in merge(local.connectivity_aviatrix_gateway, local.connectivity_aviatrix_gateway_private_link_forwarding_rule) : "aviatrix-ha-gw-${spoke_gateway_key}" => merge(spoke_gateway, {
      location            = azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].location
      resource_group_name = azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].resource_group_name
      workload_name       = spoke_gateway.gateway_type == "specialty" ? "aviatrix-ha-specialty-${var.project_name}" : "aviatrix-ha-${var.project_name}"
      instance_name       = spoke_gateway.ha_instance_name
      zones               = var.connectivity_aviatrix_gateway_default_specification.public_ip.zones
      allocation_method   = lookup(spoke_gateway, "allocation_method", var.connectivity_aviatrix_gateway_default_specification.public_ip.allocation_method)
      sku                 = lookup(spoke_gateway, "sku", var.connectivity_aviatrix_gateway_default_specification.public_ip.sku)
    }) if spoke_gateway.ha_gw && var.connectivity_aviatrix_gateway_default_specification.allocate_new_eip != true && var.virtual_network_creation },
  )

  connectivity_aviatrix_public_ip = concat(
    [for spoke_gateway_key, spoke_gateway in local.connectivity_aviatrix_gateway : azurerm_public_ip.connectivity["aviatrix-gw-${spoke_gateway_key}"].ip_address if var.connectivity_aviatrix_gateway_default_specification.allocate_new_eip != true],
    [for spoke_gateway_key, spoke_gateway in local.connectivity_aviatrix_gateway : azurerm_public_ip.connectivity["aviatrix-ha-gw-${spoke_gateway_key}"].ip_address if spoke_gateway.ha_gw && var.connectivity_aviatrix_gateway_default_specification.allocate_new_eip != true && var.virtual_network_creation]
  )

  connectivity_subnet_name_without_route_table = ["AzureBastionSubnet"]

  connectivity_subnet = tomap({
    for subnet in
    flatten([
      for network_key, network in local.connectivity_virtual_network : [
        for subnet_key, subnet in network.subnets : merge(
          subnet,
          {
            private_link_service_network_policies_enabled = lookup(subnet, "private_link_service_network_policies_enabled", null)
            default_outbound_access_enabled               = true
            route_table = contains(local.connectivity_subnet_name_without_route_table, subnet.name) ? null : {
              id = azurerm_route_table.connectivity[lookup(subnet, "route_table_key", can(regex("snet-aviatrix-spoke-gateway", subnet.name)) ? "aviatrix-01" : can(regex("snet-application-gateway", subnet.name)) ? "internet-01" : "default-01")].id
            }
            network_security_group_association = lookup(subnet, "network_security_group_association", true)
            virtual_network_key                = network_key
            subnet_key                         = subnet_key
            delegation                         = lookup(subnet, "delegation", [])
            service_endpoints                  = lookup(subnet, "service_endpoints", [])
          }
        )
      ]
    ]) : subnet.subnet_key => subnet if var.virtual_network_creation
  })

  connectivity_aviatrix_gateway = { for spoke_gateway_key, spoke_gateway in var.connectivity_aviatrix_gateway : spoke_gateway_key => merge(
    {
      aviatrix_account_create = coalesce(spoke_gateway.aviatrix_account_create, var.connectivity_aviatrix_gateway_default_specification.aviatrix_account_create)
      cloud_type              = var.connectivity_aviatrix_gateway_default_specification.cloud_type
      account_name            = "azu-${local.region_code}-${coalesce(spoke_gateway.workload_name, var.project_name)}-${var.environment}-${coalesce(spoke_gateway.instance_name, spoke_gateway_key)}"
      rbac_groups             = var.connectivity_aviatrix_gateway_default_specification.rbac_groups
      subscription_id         = var.subscription_id_client
      arm_directory_id        = data.azurerm_client_config.current.tenant_id
      gw_name                 = tostring("azu-${local.region_code}-cld-${spoke_gateway.gateway_type}-${coalesce(spoke_gateway.workload_name, var.project_name)}-${var.environment}-${coalesce(spoke_gateway.instance_name, spoke_gateway_key)}")
      ha_gw_name              = tostring("azu-${local.region_code}-cld-${spoke_gateway.gateway_type}-${coalesce(spoke_gateway.workload_name, var.project_name)}-${var.environment}-${spoke_gateway.ha_instance_name}")
      location                = module.azure_region.location
      tags                    = merge(local.tags, coalesce(spoke_gateway.tags, var.connectivity_aviatrix_gateway_default_specification.tags))
      enable_vpc_dns_server   = coalesce(spoke_gateway.enable_vpc_dns_server, var.connectivity_aviatrix_gateway_default_specification.enable_vpc_dns_server)
      gw_subnet               = azurerm_subnet.connectivity[spoke_gateway.subnet_key].address_prefixes[0]
      zone                    = coalesce(spoke_gateway.zone, var.connectivity_aviatrix_gateway_default_specification.zone)
      single_ip_snat          = coalesce(spoke_gateway.single_ip_snat, var.connectivity_aviatrix_gateway_default_specification.single_ip_snat)
      allocate_new_eip        = var.connectivity_aviatrix_gateway_default_specification.allocate_new_eip
      spoke_vpc_id = format("%s:%s:%s",
        azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].name,
        azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].resource_group_name,
        azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].guid
      )
      filtered_spoke_vpc_routes = spoke_gateway.filtered_spoke_vpc_routes
      address_space             = azurerm_virtual_network.connectivity[spoke_gateway.virtual_network_key].address_space
      manage_ha_gateway         = var.connectivity_aviatrix_ha_gw == null ? var.environment == "prd" ? true : false : var.connectivity_aviatrix_ha_gw
      ha_subnet                 = azurerm_subnet.connectivity[spoke_gateway.subnet_key].address_prefixes[0]
      ha_gw                     = var.connectivity_aviatrix_ha_gw == null ? var.environment == "prd" ? true : false : var.connectivity_aviatrix_ha_gw
      ha_zone                   = coalesce(spoke_gateway.ha_zone, var.connectivity_aviatrix_gateway_default_specification.ha_zone)
    },
    spoke_gateway,
    {
      instance_size = coalesce(spoke_gateway.instance_size, var.connectivity_aviatrix_gateway_default_specification.location_specific_config[module.azure_region.location].instance_size)
      ha_gw_size    = coalesce(spoke_gateway.instance_size, var.connectivity_aviatrix_gateway_default_specification.location_specific_config[module.azure_region.location].instance_size)
    }
    )
  if var.virtual_network_creation }

  connectivity_aviatrix_gateway_private_link_forwarding_rule = { for key, value in var.private_link_forwarding_rule : "specialty-${key}" => merge(
    {
      aviatrix_account_create = coalesce(value.aviatrix.aviatrix_account_create, var.connectivity_aviatrix_gateway_default_specification.aviatrix_account_create)
      cloud_type              = var.connectivity_aviatrix_gateway_default_specification.cloud_type
      account_name            = "azu-${local.region_code}-${coalesce(value.aviatrix.workload_name, var.project_name)}-${var.environment}-${coalesce(value.aviatrix.instance_name, key)}"
      rbac_groups             = var.connectivity_aviatrix_gateway_default_specification.rbac_groups
      subscription_id         = var.subscription_id_client
      arm_directory_id        = data.azurerm_client_config.current.tenant_id
      gw_name                 = tostring("azu-${local.region_code}-cld-${value.aviatrix.gateway_type}-${coalesce(value.aviatrix.workload_name, var.project_name)}-${var.environment}-${coalesce(value.aviatrix.instance_name, key)}")
      ha_gw_name              = tostring("azu-${local.region_code}-cld-${value.aviatrix.gateway_type}-${coalesce(value.aviatrix.workload_name, var.project_name)}-${var.environment}-${value.aviatrix.ha_instance_name}")
      location                = module.azure_region.location
      tags                    = merge(local.tags, coalesce(value.aviatrix.tags, var.connectivity_aviatrix_gateway_default_specification.tags))
      enable_vpc_dns_server   = coalesce(value.aviatrix.enable_vpc_dns_server, var.connectivity_aviatrix_gateway_default_specification.enable_vpc_dns_server)
      instance_size           = coalesce(value.aviatrix.instance_size, var.connectivity_aviatrix_gateway_default_specification.instance_size)
      gw_subnet               = azurerm_subnet.connectivity[value.aviatrix.subnet_key].address_prefixes[0]
      zone                    = coalesce(value.aviatrix.zone, var.connectivity_aviatrix_gateway_default_specification.zone)
      single_ip_snat          = coalesce(value.aviatrix.single_ip_snat, var.connectivity_aviatrix_gateway_default_specification.single_ip_snat)
      allocate_new_eip        = var.connectivity_aviatrix_gateway_default_specification.allocate_new_eip
      spoke_vpc_id = format("%s:%s:%s",
        azurerm_virtual_network.connectivity[value.aviatrix.virtual_network_key].name,
        azurerm_virtual_network.connectivity[value.aviatrix.virtual_network_key].resource_group_name,
        azurerm_virtual_network.connectivity[value.aviatrix.virtual_network_key].guid
      )
      filtered_spoke_vpc_routes = value.aviatrix.filtered_spoke_vpc_routes
      address_space             = azurerm_virtual_network.connectivity[value.aviatrix.virtual_network_key].address_space
      manage_ha_gateway         = var.connectivity_aviatrix_ha_gw == null ? var.environment == "prd" ? true : false : var.connectivity_aviatrix_ha_gw
      ha_gw_size                = coalesce(value.aviatrix.instance_size, var.connectivity_aviatrix_gateway_default_specification.instance_size)
      ha_subnet                 = azurerm_subnet.connectivity[value.aviatrix.subnet_key].address_prefixes[0]
      ha_gw                     = var.connectivity_aviatrix_ha_gw == null ? var.environment == "prd" ? true : false : var.connectivity_aviatrix_ha_gw
      ha_zone                   = coalesce(value.aviatrix.ha_zone, var.connectivity_aviatrix_gateway_default_specification.ha_zone)
    },
    value.aviatrix
    )
  if var.virtual_network_creation && value.aviatrix.use }

  connectivity_application_gateway = { for application_gateway_key, application_gateway in var.connectivity_application_gateway : application_gateway_key => merge(
    application_gateway,
    {
      name                = "${local.region_code}-agw-${lookup(application_gateway, "workload_name", var.project_name)}-${var.environment}-${application_gateway.instance_name}"
      resource_group_name = azurerm_resource_group.connectivity[lookup(application_gateway, "resource_group_key", "02")].name
      location            = azurerm_resource_group.connectivity[lookup(application_gateway, "resource_group_key", "02")].location
      http2               = lookup(application_gateway, "http2", var.connectivity_application_gateway_default_specification.application_gateway.http2)
      tags                = merge(local.tags, lookup(application_gateway, "tags", var.connectivity_application_gateway_default_specification.application_gateway.tags))

      sku = lookup(application_gateway, "sku", var.connectivity_application_gateway_default_specification.application_gateway.sku)

      gateway_ip_configuration = [for value in lookup(application_gateway, "gateway_ip_configuration", var.connectivity_application_gateway_default_specification.application_gateway.gateway_ip_configuration) :
        {
          name      = lookup(value, "name", "${local.region_code}-agw-${lookup(application_gateway, "workload_name", var.project_name)}-${var.environment}-${application_gateway.instance_name}-ipconfig-01")
          subnet_id = azurerm_subnet.connectivity[value.subnet_key].id
        }
      ]
      frontend_port = [for value in lookup(application_gateway, "frontend_port", var.connectivity_application_gateway_default_specification.application_gateway.frontend_port) :
        {
          name = value.name
          port = value.port
        }
      ]
      frontend_ip_configuration = [for value in lookup(application_gateway, "frontend_ip_configuration", var.connectivity_application_gateway_default_specification.application_gateway.frontend_ip_configuration) :
        {
          name                          = value.name
          subnet_id                     = lookup(value, "subnet_key", null) == null ? null : azurerm_subnet.connectivity[value.subnet_key].id
          private_ip_address            = lookup(value, "subnet_key", null) == null ? null : lookup(value, "private_ip_address", cidrhost(azurerm_subnet.connectivity[value.subnet_key].address_prefixes[0], value.cidrhost_hostnum))
          private_ip_address_allocation = lookup(value, "subnet_key", null) == null ? null : lookup(value, "private_ip_address_allocation", null)
          public_ip                     = lookup(value, "subnet_key", null) == null ? true : false
        }
      ]
      backend_address_pool = [for value in lookup(application_gateway, "backend_address_pool", var.connectivity_application_gateway_default_specification.application_gateway.backend_address_pool) :
        {
          name         = value.name
          fqdns        = lookup(value, "fqdns", null)
          ip_addresses = lookup(value, "ip_addresses", null)
        }
      ]
      backend_http_settings = [for value in lookup(application_gateway, "backend_http_settings", var.connectivity_application_gateway_default_specification.application_gateway.backend_http_settings) :
        {
          name                                = value.name
          cookie_based_affinity               = lookup(value, "cookie_based_affinity", "Disabled")
          path                                = lookup(value, "path", "/")
          port                                = value.port
          protocol                            = lookup(value, "protocol", title(element(split("-", value.name), 1)))
          timeout                             = value.timeout
          probe_name                          = lookup(value, "probe_name", null)
          pick_host_name_from_backend_address = lookup(value, "pick_host_name_from_backend_address", null)
        }
      ]
      http_listener = [for value in lookup(application_gateway, "http_listener", var.connectivity_application_gateway_default_specification.application_gateway.http_listener) :
        {
          name                           = value.name
          frontend_ip_configuration_name = lookup(value, "frontend_ip_configuration_name", "${element(split("-", value.name), 1)}-front-end-ip")
          frontend_port_name             = lookup(value, "frontend_port_name", element(split("-", value.name), 2))
          protocol                       = lookup(value, "protocol", title(element(split("-", value.name), 2)))
          ssl_certificate_name           = lookup(value, "ssl_certificate_name", null)
          host_names                     = lookup(value, "host_names", null)
        }
      ]
      request_routing_rule = [for value in lookup(application_gateway, "request_routing_rule", var.connectivity_application_gateway_default_specification.application_gateway.request_routing_rule) :
        {
          name                       = value.name
          priority                   = value.priority
          rule_type                  = lookup(value, "rule_type", "Basic")
          http_listener_name         = lookup(value, "http_listener_name", "${element(split("-", value.name), 0)}-${element(split("-", value.name), 1)}-${element(split("-", value.name), 2)}-listener")
          backend_address_pool_name  = value.backend_address_pool_name
          backend_http_settings_name = lookup(value, "backend_http_settings_name", "back-${element(split("-", value.name), 2)}-settings")
        }
      ]
      ssl_certificates = [for value in lookup(application_gateway, "ssl_certificates", var.connectivity_application_gateway_default_specification.application_gateway.ssl_certificates) :
        {
          name                = value.name
          key_vault_secret_id = value.key_vault_secret_id
        }
      ]
      probes = [for value in lookup(application_gateway, "probes", var.connectivity_application_gateway_default_specification.application_gateway.probes) :
        {
          name                                      = value.name
          protocol                                  = value.protocol
          path                                      = lookup(value, "path", "/")
          interval                                  = lookup(value, "interval", 30)
          timeout                                   = lookup(value, "timeout", 30)
          unhealthy_threshold                       = lookup(value, "unhealthy_threshold", 3)
          pick_host_name_from_backend_http_settings = lookup(value, "pick_host_name_from_backend_http_settings", false)
          host                                      = lookup(value, "host", null)
        }
      ]
      agw_paired_keyvaults_scopes = {
        "01" = {
          scope_id = module.keyvault["02"].key_vault.id
          enabled  = var.connectivity_application_gateway_default_specification.application_gateway.ssl_certificates[0].key_vault_secret_id != null ? true : false
        }
      }
    }
    ) if var.connectivity_application_gateway_creation && var.virtual_network_creation == true
  }
}
