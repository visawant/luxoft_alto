terraform {
  required_version = "~> 1.11"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "3.110.0"
    }
  }

  backend "local" {} #Using a local backend just for the demo, the reco is to use a remote backend, see : https://jamesdld.github.io/terraform/Best-Practice/BestPractice-1/
}

#Set the Provider
variable "subscription_id" {
  description = "Azure subscription Id."
  default     = "86009f81-beb1-43e3-b6b7-a117b5cc85fa"
}

provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
}

##
## Aviatrix related config
variable "CONTROLLER_PUBLIC_IP" {
  type        = string
  description = "Controller public IP"
}

variable "CONTROLLER_USERNAME" {
  type        = string
  description = "Controller username"
}

variable "CONTROLLER_PASSWORD" {
  description = "Controller password"
  type        = string
}

variable "AD_SP_AVIATRIX_DAT_APP_ID" {
  type        = string
  description = "AAD Aviatrix account App ID"
}

variable "AD_SP_AVIATRIX_DAT_SECRET" {
  description = "AAD Aviatrix account secret"
  type        = string
}

module "landing-zone" {
  source                      = "../../"
  subscription_id_client      = var.subscription_id
  application                 = "bcp"
  environment                 = "uat"
  connectivity_aviatrix_ha_gw = true
  region                      = "France Central"
  virtual_network_creation    = false
  AD_SP_AVIATRIX_DAT_APP_ID   = var.AD_SP_AVIATRIX_DAT_APP_ID
  AD_SP_AVIATRIX_DAT_SECRET   = var.AD_SP_AVIATRIX_DAT_SECRET
  CONTROLLER_PUBLIC_IP        = var.CONTROLLER_PUBLIC_IP
  CONTROLLER_USERNAME         = var.CONTROLLER_USERNAME
  CONTROLLER_PASSWORD         = var.CONTROLLER_PASSWORD
}
