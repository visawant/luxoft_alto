# Introduction

Deploy connectivity resources including virtual network and Aviatrix spoke gateways.

## Create the Aviatrix secret file

Write the following values into the file "./env/aviatrix.secret.env"

```
AD_SP_AVIATRIX_DAT_APP_ID = "f1"
AD_SP_AVIATRIX_DAT_SECRET = "Ib"
CONTROLLER_PUBLIC_IP      = "4."
CONTROLLER_USERNAME       = "av"
CONTROLLER_PASSWORD       = "Jd"
```

# Manual deployment

```
aviatrix_secret_file="./env/aviatrix.secret.env"

terraform init

terraform plan -var-file=$aviatrix_secret_file

terraform apply -var-file=$aviatrix_secret_file
```
