resource "azurerm_resource_group" "connectivity" {
  for_each = local.connectivity_resource_group

  name     = "${local.region_code}-rg-connectivity-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, local.tags, coalesce(each.value.tags, {}))
}

resource "azurerm_virtual_network" "connectivity" {
  for_each            = { for key, value in var.connectivity_virtual_network : key => value if var.virtual_network_creation }
  name                = "${local.region_code}-vnet-${lookup(each.value, "workload_name", var.project_name)}-${var.environment}-${lookup(each.value, "instance_name", each.key)}"
  location            = azurerm_resource_group.connectivity[lookup(each.value, "resource_group_key", "01")].location
  resource_group_name = azurerm_resource_group.connectivity[lookup(each.value, "resource_group_key", "01")].name
  tags                = merge(local.tags, lookup(each.value, "tags", {}))
  address_space       = each.value.address_space
  dns_servers         = lookup(each.value, "dns_servers", null)

  dynamic "ddos_protection_plan" {
    for_each = lookup(each.value, "ddos_protection_plan", [])
    content {
      id     = lookup(ddos_protection_plan.value, "id", null)
      enable = lookup(ddos_protection_plan.value, "enable", false)
    }
  }
}

resource "azurerm_subnet" "connectivity" {
  for_each            = local.connectivity_subnet
  name                = each.value.name
  resource_group_name = azurerm_virtual_network.connectivity[each.value.virtual_network_key].resource_group_name
  address_prefixes    = each.value.address_prefixes
  service_endpoints   = lookup(each.value, "service_endpoints", var.virtual_network_default_specification.service_endpoints)

  private_endpoint_network_policies             = lookup(each.value, "private_endpoint_network_policies", var.virtual_network_default_specification.private_endpoint_network_policies)
  private_link_service_network_policies_enabled = lookup(each.value, "private_link_service_network_policies_enabled", null)

  virtual_network_name = azurerm_virtual_network.connectivity[each.value.virtual_network_key].name

  dynamic "delegation" {
    for_each = lookup(each.value, "delegation", [])
    content {
      name = lookup(delegation.value, "name", null)
      dynamic "service_delegation" {
        for_each = lookup(delegation.value, "service_delegation", [])
        content {
          name    = lookup(service_delegation.value, "name", null)    # (Required) The name of service to delegate to. Possible values include Microsoft.BareMetal/AzureVMware, Microsoft.BareMetal/CrayServers, Microsoft.Batch/batchAccounts, Microsoft.ContainerInstance/containerGroups, Microsoft.Databricks/workspaces, Microsoft.HardwareSecurityModules/dedicatedHSMs, Microsoft.Logic/integrationServiceEnvironments, Microsoft.Netapp/volumes, Microsoft.ServiceFabricMesh/networks, Microsoft.Sql/managedInstances, Microsoft.Sql/servers, Microsoft.Web/hostingEnvironments and Microsoft.Web/serverFarms.
          actions = lookup(service_delegation.value, "actions", null) # (Required) A list of Actions which should be delegated. Possible values include Microsoft.Network/virtualNetworks/sub/prepareNetworkPolicies/action, Microsoft.Network/virtualNetworks/sub/action and Microsoft.Network/virtualNetworks/sub/join/action.
        }
      }
    }
  }
}

resource "azurerm_network_security_group" "connectivity" {
  for_each            = local.connectivity_network_security_group
  name                = each.value.name
  location            = each.value.location
  resource_group_name = each.value.resource_group_name
  tags                = each.value.tags

  dynamic "security_rule" {
    for_each = each.value.security_rule
    content {
      description                                = security_rule.value.description
      direction                                  = security_rule.value.direction
      name                                       = security_rule.value.name
      access                                     = security_rule.value.access
      priority                                   = security_rule.value.priority
      source_address_prefix                      = security_rule.value.source_address_prefix
      source_address_prefixes                    = security_rule.value.source_address_prefixes
      source_application_security_group_ids      = security_rule.value.source_application_security_group_ids
      destination_address_prefix                 = security_rule.value.destination_address_prefix
      destination_address_prefixes               = security_rule.value.destination_address_prefixes
      destination_application_security_group_ids = security_rule.value.destination_application_security_group_ids
      destination_port_range                     = security_rule.value.destination_port_range
      destination_port_ranges                    = security_rule.value.destination_port_ranges
      protocol                                   = security_rule.value.protocol
      source_port_range                          = security_rule.value.source_port_range
      source_port_ranges                         = security_rule.value.source_port_ranges
    }
  }
}

resource "azurerm_subnet_network_security_group_association" "connectivity_security_group_associations" {
  for_each                  = { for key, value in local.connectivity_network_security_group : key => value if value.network_security_group_association }
  network_security_group_id = azurerm_network_security_group.connectivity[each.key].id
  subnet_id                 = azurerm_subnet.connectivity[each.key].id
}

resource "azurerm_route_table" "connectivity" {
  for_each            = local.connectivity_route_table
  name                = "${local.region_code}-rt-${lookup(each.value, "workload_name", var.project_name)}-${var.environment}-${each.value.instance_name}"
  location            = azurerm_resource_group.connectivity[each.value.virtual_network_key].location
  resource_group_name = azurerm_resource_group.connectivity[each.value.virtual_network_key].name
  tags                = merge(local.tags, lookup(each.value, "tags", {}))

  dynamic "route" {
    for_each = lookup(each.value, "route", [])
    content {
      name                   = lookup(route.value, "name", null)
      address_prefix         = lookup(route.value, "address_prefix", null)
      next_hop_type          = lookup(route.value, "next_hop_type", null)
      next_hop_in_ip_address = lookup(route.value, "next_hop_in_ip_address", null)
    }
  }

  lifecycle {
    ignore_changes = [
      // Ignore changes that are managed outside Terraform
      route // Managed by Aviatrix
    ]
  }
}

resource "azurerm_subnet_route_table_association" "connectivity_route_table_associations" {
  for_each       = { for key, value in local.connectivity_subnet : key => value if lookup(value, "route_table", null) != null }
  route_table_id = each.value.route_table.id
  subnet_id      = azurerm_subnet.connectivity[each.key].id
}

resource "azurerm_public_ip" "connectivity" {
  for_each            = local.connectivity_public_ip
  name                = "${local.region_code}-pip-${lookup(each.value, "workload_name", var.project_name)}-${var.environment}-${lookup(each.value, "instance_name", each.key)}"
  location            = lookup(each.value, "location", azurerm_resource_group.connectivity[lookup(each.value, "resource_group_key", "01")].location)
  resource_group_name = lookup(each.value, "resource_group_name", azurerm_resource_group.connectivity[lookup(each.value, "resource_group_key", "01")].name)
  allocation_method   = each.value.allocation_method
  sku                 = each.value.sku
  zones               = lookup(each.value, "zones", null)
  tags = {
    for key, value in merge(local.tags, lookup(each.value, "tags", {})) :
    key => replace(value, "/", "-")
  }

  lifecycle {
    ignore_changes = [
      // Ignore changes that are managed outside Terraform
      tags["Aviatrix-Created-Resource"], tags["Controller"], tags["Name"], tags["Type"] // Managed by Aviatrix
    ]
  }
}

resource "aviatrix_account" "connectivity" {
  for_each            = { for key, value in local.connectivity_aviatrix_gateway : key => value if value.aviatrix_account_create }
  account_name        = each.value.account_name
  cloud_type          = each.value.cloud_type
  arm_subscription_id = each.value.subscription_id
  arm_directory_id    = each.value.arm_directory_id
  arm_application_id  = var.AD_SP_AVIATRIX_DAT_APP_ID
  arm_application_key = var.AD_SP_AVIATRIX_DAT_SECRET
  rbac_groups         = each.value.rbac_groups
}

# Create an Aviatrix Azure Specialty Gateway
resource "aviatrix_gateway" "connectivity" {
  depends_on                              = [azurerm_subnet_route_table_association.connectivity_route_table_associations, aviatrix_spoke_gateway.connectivity]
  for_each                                = { for key, value in merge(local.connectivity_aviatrix_gateway, local.connectivity_aviatrix_gateway_private_link_forwarding_rule) : key => value if value.gateway_type == "specialty" }
  cloud_type                              = each.value.cloud_type
  account_name                            = aviatrix_account.connectivity[each.value.account_key].account_name
  gw_name                                 = each.value.gw_name
  vpc_id                                  = each.value.spoke_vpc_id
  vpc_reg                                 = each.value.location
  gw_size                                 = coalesce(each.value.instance_size, var.connectivity_aviatrix_gateway_default_specification.location_specific_config[module.azure_region.location].instance_size)
  subnet                                  = each.value.gw_subnet
  allocate_new_eip                        = each.value.allocate_new_eip
  monitor_exclude_list                    = each.value.monitor_exclude_list
  public_subnet_filtering_ha_route_tables = each.value.public_subnet_filtering_ha_route_tables
  public_subnet_filtering_route_tables    = each.value.public_subnet_filtering_route_tables

  eip = each.value.allocate_new_eip ? null : azurerm_public_ip.connectivity["aviatrix-gw-${each.key}"].ip_address
  azure_eip_name_resource_group = each.value.allocate_new_eip ? null : format("%s:%s",
    azurerm_public_ip.connectivity["aviatrix-gw-${each.key}"].name,
    azurerm_public_ip.connectivity["aviatrix-gw-${each.key}"].resource_group_name
  )
  zone                  = each.value.zone
  single_ip_snat        = each.value.single_ip_snat
  enable_vpc_dns_server = each.value.enable_vpc_dns_server

  peering_ha_subnet  = each.value.ha_gw ? each.value.ha_subnet : null
  peering_ha_gw_size = each.value.ha_gw ? each.value.ha_gw_size : null
  peering_ha_zone    = each.value.ha_gw ? each.value.ha_zone : null
  peering_ha_eip     = each.value.ha_gw ? each.value.allocate_new_eip ? null : azurerm_public_ip.connectivity["aviatrix-ha-gw-${each.key}"].ip_address : null
  peering_ha_azure_eip_name_resource_group = each.value.ha_gw ? each.value.allocate_new_eip ? null : format("%s:%s",
    azurerm_public_ip.connectivity["aviatrix-ha-gw-${each.key}"].name,
    azurerm_public_ip.connectivity["aviatrix-ha-gw-${each.key}"].resource_group_name
  ) : null

  tags = {
    for key, value in merge(local.tags, lookup(each.value, "tags", {})) :
    key => replace(value, "/", "-")
  }

  lifecycle {
    ignore_changes = [
      // Ignore changes that are managed outside Terraform
    ]
  }
}

resource "aviatrix_gateway_dnat" "connectivity" {
  for_each = { for key, value in var.private_link_forwarding_rule : key => value if value.aviatrix.use }
  gw_name  = aviatrix_gateway.connectivity["specialty-${each.key}"].gw_name

  dynamic "dnat_policy" {
    for_each = values(each.value.forwarding_rules)
    content {
      //dst_cidr  = "${aviatrix_gateway.connectivity["specialty-${each.key}"].private_ip}/32" //Ip privée de la specialty mais pas supporté
      dst_port  = dnat_policy.value.source_port
      dnat_ips  = dnat_policy.value.destination_address
      dnat_port = dnat_policy.value.destination_port
      interface = dnat_policy.value.interface
      protocol  = "tcp" //Port specification is not supported for protocol all
    }
  }
}

# Create an Aviatrix Azure Spoke Gateway
resource "aviatrix_spoke_gateway" "connectivity" {
  depends_on       = [azurerm_subnet_route_table_association.connectivity_route_table_associations]
  for_each         = { for key, value in local.connectivity_aviatrix_gateway : key => value if value.gateway_type == "spoke" }
  cloud_type       = each.value.cloud_type
  account_name     = aviatrix_account.connectivity[each.key].account_name
  gw_name          = each.value.gw_name
  vpc_id           = each.value.spoke_vpc_id
  vpc_reg          = each.value.location
  gw_size          = each.value.instance_size
  subnet           = each.value.gw_subnet
  allocate_new_eip = each.value.allocate_new_eip
  eip              = each.value.allocate_new_eip ? null : azurerm_public_ip.connectivity["aviatrix-gw-${each.key}"].ip_address
  azure_eip_name_resource_group = each.value.allocate_new_eip ? null : format("%s:%s",
    azurerm_public_ip.connectivity["aviatrix-gw-${each.key}"].name,
    azurerm_public_ip.connectivity["aviatrix-gw-${each.key}"].resource_group_name
  )
  zone                      = each.value.zone
  single_ip_snat            = each.value.single_ip_snat
  single_az_ha              = each.value.single_az_ha
  enable_vpc_dns_server     = each.value.enable_vpc_dns_server
  filtered_spoke_vpc_routes = each.value.filtered_spoke_vpc_routes
  manage_ha_gateway         = each.value.ha_gw ? null : false


  tags = {
    for key, value in merge(local.tags, lookup(each.value, "tags", {})) :
    key => replace(value, "/", "-")
  }

  lifecycle {
    ignore_changes = [
      // Ignore changes that are managed outside Terraform
      ha_gw_size, ha_subnet // Managed by Aviatrix
    ]
  }
}

resource "aviatrix_spoke_ha_gateway" "connectivity" {
  depends_on      = [azurerm_subnet_route_table_association.connectivity_route_table_associations, aviatrix_spoke_transit_attachment.connectivity]
  for_each        = { for key, value in local.connectivity_aviatrix_gateway : key => value if value.ha_gw && value.gateway_type == "spoke" }
  primary_gw_name = aviatrix_spoke_gateway.connectivity[each.key].gw_name
  gw_name         = each.value.ha_gw_name
  gw_size         = each.value.ha_gw_size
  subnet          = each.value.ha_subnet
  eip             = each.value.allocate_new_eip ? null : azurerm_public_ip.connectivity["aviatrix-ha-gw-${each.key}"].ip_address
  azure_eip_name_resource_group = each.value.allocate_new_eip ? null : format("%s:%s",
    azurerm_public_ip.connectivity["aviatrix-ha-gw-${each.key}"].name,
    azurerm_public_ip.connectivity["aviatrix-ha-gw-${each.key}"].resource_group_name
  )
  zone = each.value.ha_zone
}

# Create an Aviatrix Spoke Transit Attachment
resource "aviatrix_spoke_transit_attachment" "connectivity" {
  for_each        = { for key, value in local.connectivity_aviatrix_gateway : key => value if var.connectivity_spoke_transit_attachment }
  spoke_gw_name   = aviatrix_spoke_gateway.connectivity[each.key].gw_name
  transit_gw_name = var.connectivity_aviatrix_gateway_default_specification.location_specific_config[module.azure_region.location].transit_gw_name
}


resource "aviatrix_gateway_snat" "connectivity" {
  depends_on = [aviatrix_spoke_transit_attachment.connectivity, aviatrix_spoke_ha_gateway.connectivity]
  for_each   = { for key, value in local.connectivity_aviatrix_gateway : key => value if length(value.snat_policy) > 0 }
  gw_name    = aviatrix_spoke_gateway.connectivity[each.key].gw_name
  snat_mode  = "customized_snat"
  sync_to_ha = true

  dynamic "snat_policy" {
    for_each = each.value.snat_policy
    content {
      src_cidr          = snat_policy.value.src_cidr
      dst_cidr          = snat_policy.value.dst_cidr
      dst_port          = lookup(snat_policy.value, "dst_port", "443")
      protocol          = lookup(snat_policy.value, "protocol", "all")
      interface         = lookup(snat_policy.value, "interface", "eth0")
      connection        = lookup(snat_policy.value, "connection", "None")
      snat_ips          = lookup(snat_policy.value, "snat_ips", each.value.ha_gw ? "${aviatrix_spoke_gateway.connectivity[each.key].private_ip}-${aviatrix_spoke_ha_gateway.connectivity[each.key].private_ip}" : aviatrix_spoke_gateway.connectivity[each.key].private_ip)
      apply_route_entry = lookup(snat_policy.value, "apply_route_entry", true)
    }
  }
}
