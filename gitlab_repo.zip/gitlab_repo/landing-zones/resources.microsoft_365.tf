resource "azurerm_resource_group" "microsoft_365" {
  for_each = local.microsoft_365_resource_group

  name     = "${local.region_code}-rg-${lookup(each.value, "workload_name", var.project_name)}-${var.environment}-${lookup(each.value, "instance_name", "01")}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}

resource "azurerm_powerbi_embedded" "microsoft_365" {
  for_each = local.microsoft_365_powerbi_embedded

  name                = each.value.name
  location            = each.value.location
  resource_group_name = each.value.resource_group_name
  sku_name            = each.value.sku_name
  administrators      = each.value.administrators
  mode                = each.value.mode
  tags                = each.value.tags
}

resource "azurerm_fabric_capacity" "microsoft_365" {
  for_each = local.microsoft_365_fabric_capacity

  name                   = each.value.name
  location               = each.value.location
  resource_group_name    = each.value.resource_group_name
  administration_members = each.value.administration_members

  dynamic "sku" {
    for_each = each.value.sku
    content {
      name = sku.value.name
      tier = sku.value.tier
    }
  }
  tags = each.value.tags
}

resource "azurerm_bot_service_azure_bot" "microsoft_365" {
  for_each = local.microsoft_365_bot_service_azure_bot

  name                                  = each.value.name
  location                              = each.value.location
  resource_group_name                   = each.value.resource_group_name
  microsoft_app_id                      = each.value.microsoft_app_id
  sku                                   = each.value.sku
  developer_app_insights_api_key        = each.value.developer_app_insights_api_key
  developer_app_insights_application_id = each.value.developer_app_insights_application_id
  developer_app_insights_key            = each.value.developer_app_insights_key
  display_name                          = each.value.display_name
  endpoint                              = each.value.endpoint
  icon_url                              = each.value.icon_url
  microsoft_app_msi_id                  = each.value.microsoft_app_msi_id
  cmk_key_vault_key_url                 = each.value.cmk_key_vault_key_url
  microsoft_app_tenant_id               = each.value.microsoft_app_tenant_id
  microsoft_app_type                    = each.value.microsoft_app_type
  local_authentication_enabled          = each.value.local_authentication_enabled
  luis_app_ids                          = each.value.luis_app_ids
  luis_key                              = each.value.luis_key
  public_network_access_enabled         = each.value.public_network_access_enabled
  streaming_endpoint_enabled            = each.value.streaming_endpoint_enabled
  tags                                  = each.value.tags
}

resource "azurerm_bot_channel_ms_teams" "microsoft_365" {
  for_each = local.microsoft_365_bot_channel_ms_teams

  bot_name               = each.value.bot_name
  location               = each.value.location
  resource_group_name    = each.value.resource_group_name
  calling_web_hook       = each.value.calling_web_hook
  deployment_environment = each.value.deployment_environment
  enable_calling         = each.value.enable_calling
}
