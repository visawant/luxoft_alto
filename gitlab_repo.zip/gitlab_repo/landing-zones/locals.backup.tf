locals {
  backup_resource_group = { for key, value in var.backup_resource_group : key => value if var.backup_creation }

  backup_resource_group_role_assignment = tomap({
    for son in
    flatten([
      for father_key, father in var.backup_resource_group : [
        for son_key, son in father.role_assignment : {
          key = "${father_key}-${son_key}"
          role_assignment = merge(
            son,
            {
              resource_group_key = father_key
            }
          )
        }
      ]
    ]) : son.key => son.role_assignment if var.backup_creation
  })

  backup_key_vault_key = var.backup_creation ? {
    "backup-01" = {
      key_vault_key = var.backup_vault_default_specification.key_vault_key
      name          = "${var.project_name}-backup-01"
    }
  } : {}

  backup_vault = { for key, value in var.backup_vault : key => merge(
    {
      name                = "${local.region_code}-bvault-${coalesce(value.workload_name, var.project_name)}-${var.environment}-${value.instance_name}"
      resource_group_name = azurerm_resource_group.backup[value.resource_group_key].name
      location            = azurerm_resource_group.backup[value.resource_group_key].location
    },
    value,
    {
      tags       = merge(azurerm_resource_group.backup[value.resource_group_key].tags, local.tags, value.tags)
      redundancy = coalesce(value.redundancy, var.backup_vault_default_specification["${local.environment_type}"].redundancy)

      # Backup Instances Configuration
      backup_instances = merge([
        for k, v in local.database_postgresql_flexible_server_backup_vault : v.backup_instances if v.backup_vault_key == key
      ]...)

      role_assignments = merge([
        for k, v in local.database_postgresql_flexible_server_backup_vault : v.role_assignments if v.backup_vault_key == key
      ]...)

      soft_delete                = "Off" //"AlwaysOn", "Off", "On"
      retention_duration_in_days = null  //The soft delete retention duration for this Backup Vault. Valid values are between 14 and 180. Defaults to 14.

      cross_region_restore_enabled = coalesce(value.cross_region_restore_enabled, var.backup_vault_default_specification["${local.environment_type}"].cross_region_restore_enabled)

      customer_managed_key = {
        key_vault_resource_id = module.keyvault[coalesce(value.key_vault_key, var.backup_vault_default_specification.key_vault_key)].key_vault.id
        key_name              = basename(module.keyvault[coalesce(value.key_vault_key, var.backup_vault_default_specification.key_vault_key)].key["backup-01"].resource_versionless_id)
        key_versionless_id    = module.keyvault[coalesce(value.key_vault_key, var.backup_vault_default_specification.key_vault_key)].key["backup-01"].versionless_id
      }

      diagnostic_settings = {
        "01" = {
          name                  = "setByTerraform-LogAnalytics"
          workspace_resource_id = var.regional_shared_resources[var.region].log_analytics_workspace_id
        }
      }
    }
  ) if var.backup_creation }



  //This variable is used to map workspace hub storage accounts to their respective keys.
  backup_vault_storage_account = { for key, value in var.backup_vault_default_specification.storage_account : "backup_vault_${key}" => merge(
    {
      customer_managed_key = [
        {
          key_vault_id     = module.keyvault[coalesce(value.key_vault_key, var.backup_vault_default_specification.key_vault_key)].key_vault.id
          key_vault_key_id = module.keyvault[coalesce(value.key_vault_key, var.backup_vault_default_specification.key_vault_key)].key["backup-01"].versionless_id
          identity_name    = "${local.region_code}-id-st-bvault-${var.project_name}-${var.environment}-${value.instance_name}"
        }
      ]
    },
    value.storage_account,
    {
      workload_name       = "bvault-${var.project_name}"
      resource_group_name = azurerm_resource_group.backup[value.resource_group_key].name
      location            = azurerm_resource_group.backup[value.resource_group_key].location
      tags = merge(azurerm_resource_group.backup[value.resource_group_key].tags, local.tags,
        {
          Storage_accounts_should_prevent_cross_tenant_object_replication = "exclude" // Required by Azure Backup Vault, see https://learn.microsoft.com/en-us/azure/backup/restore-azure-database-postgresql-flex#prerequisites?WT.mc_id=AZ-MVP-5003548
          Amundi_Deny_Storage_CopyScope                                   = "exclude" // Required by Azure Backup Vault, see https://learn.microsoft.com/en-us/azure/backup/restore-azure-database-postgresql-flex#prerequisites?WT.mc_id=AZ-MVP-5003548
      })
      role_assignment = merge({ for k, v in var.backup_vault :
        "Storage Blob Data Contributor-Backup Vault Identity ${k}" => {
          role_definition_name = "Storage Blob Data Contributor"
          principal_id         = module.backup[k].identity_principal_id
          principal_type       = "ServicePrincipal"
        } },
        value.storage_account.role_assignment
      )
      network_rules = { for k, v in var.backup_vault : "Backup Vault rule ${k}" => merge(
        value.storage_account.network_rules["01"],
        {
          private_link_access = [{
            endpoint_resource_id = replace(module.backup[k].backup_vault_id, "resourceGroups/${azurerm_resource_group.backup[value.resource_group_key].name}/providers/Microsoft.DataProtection/backupVaults", "resourcegroups/${azurerm_resource_group.backup[value.resource_group_key].name}/providers/Microsoft.DataProtection/BackupVaults")
          }]
        }
      ) }

      management_policy = value.storage_account.management_policy
    }
    ) if var.backup_creation
  }
}
