locals {
  container_resource_group = { for key, value in var.container_resource_group : key => value if
    var.container_creation &&
    (key == "01" && var.container_default_specification.aks.create) || (key == "10" && var.container_default_specification.container_app.create)
  }

  # Used to share values across multiple modules and prevent us from having to duplicate code and cycle issues
  container_aks_common_values = { for container_aks_key, container_aks in var.container_aks : container_aks_key => merge(
    {
      name = "${local.region_code}-aks-${lookup(container_aks, "workload_name", var.project_name)}-${var.environment}-${container_aks.instance_name}"
    }
  ) }

  container_aks_namespace = distinct(concat(flatten([for amundi_product in var.azure_devops["01"].amundi_products : var.azure_devops_default_specification.amundi_products[amundi_product].namespaces]), var.container_default_specification.aks.namespace))

  container_key_vault_key = var.container_creation ? {
    "container-01" = {
      key_vault_key = var.container_default_specification.key_vault_key
      name          = "${var.project_name}-container-01"
    }
  } : {}

  container_aks = { for container_aks_key, container_aks in var.container_aks : container_aks_key => merge(
    {
      name                                             = local.container_aks_common_values[container_aks_key].name
      resource_group_name                              = azurerm_resource_group.container[lookup(container_aks, "resource_group_key", "01")].name
      node_resource_group                              = replace(azurerm_resource_group.container[lookup(container_aks, "resource_group_key", "01")].name, "01", "02")
      location                                         = azurerm_resource_group.container[lookup(container_aks, "resource_group_key", "01")].location
      tenant_id                                        = data.azurerm_client_config.current.tenant_id
      kubernetes_version                               = lookup(container_aks, "kubernetes_version", var.container_default_specification.aks.kubernetes_version)
      workload_identity_enabled                        = var.container_default_specification.aks.workload_identity_enabled
      service_mesh_profile                             = [for v in lookup(container_aks, "service_mesh_profile", var.container_default_specification.aks.service_mesh_profile) : v if v.status != "disabled"]
      key_vault_secrets_provider                       = lookup(container_aks, "key_vault_secrets_provider", var.container_default_specification.aks.key_vault_secrets_provider)
      azure_active_directory_role_based_access_control = lookup(container_aks, "azure_active_directory_role_based_access_control", var.container_default_specification.aks.azure_active_directory_role_based_access_control)
      role_assignment                                  = lookup(container_aks, "role_assignment", var.container_default_specification.aks.role_assignment)
      image_cleaner                                    = lookup(container_aks, "image_cleaner", var.container_default_specification.aks.default_node_pool["${local.environment_type}"].image_cleaner)
      automatic_upgrade_channel                        = lookup(container_aks, "automatic_upgrade_channel", var.container_default_specification.aks.default_node_pool["${local.environment_type}"].automatic_upgrade_channel)
      maintenance_window_auto_upgrade = [for maintenance_window_auto_upgrade in lookup(container_aks, "maintenance_window_auto_upgrade", var.container_default_specification.aks.default_node_pool["${local.environment_type}"].maintenance_window_auto_upgrade) : merge(
        maintenance_window_auto_upgrade,
        {
          utc_offset = coalesce(maintenance_window_auto_upgrade.utc_offset, var.regional_shared_resources[var.region].utc_offset)
        }
      )]
      default_node_pool = merge(
        {
          "name"               = "${substr(replace(lookup(container_aks, "workload_name", var.project_name), "-", ""), 0, 7)}${var.environment}${container_aks.instance_name}"
          pod_subnet_id        = azurerm_subnet.connectivity["01-snet-aks-02"].id
          vm_size              = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].vm_size
          os_disk_type         = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].os_disk_type
          auto_scaling_enabled = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].auto_scaling_enabled
          min_count            = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].min_count
          max_count            = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].max_count
          max_surge            = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].max_surge
        },
        lookup(container_aks, "default_node_pool", var.container_default_specification.aks.default_node_pool)
      )
      private_cluster_enabled = lookup(container_aks, "private_cluster_enabled", var.container_default_specification.aks.private_cluster_enabled)
      network_profile         = lookup(container_aks, "network_profile", var.container_default_specification.aks.network_profile)
      aks_subnet_id           = azurerm_subnet.connectivity["01-snet-aks-01"].id
      aks_vnet_name           = azurerm_subnet.connectivity["01-snet-aks-01"].virtual_network_name
      aks_vnet_id             = azurerm_virtual_network.connectivity["01"].id
      aks_network_security_group_ids = {
        "01-snet-aks-01" = {
          id = azurerm_network_security_group.connectivity["01-snet-aks-01"].id
        }
      }
      aks_route_table_ids = {
        "default-01" = {
          id = azurerm_route_table.connectivity["default-01"].id
        }
      }
      aks_private_dns_id  = module.dns["private.${local.location_cli}.azmk8s.io"].resource.id
      blob_private_dns_id = module.dns["privatelink.blob.core.windows.net"].resource.id
      disk_access         = lookup(container_aks, "disk_access", var.container_default_specification.aks.disk_access)
      log_analytics_workspace = merge(
        var.container_default_specification.aks.log_analytics_workspace,
        {
          id                      = var.regional_shared_resources[var.region].log_analytics_workspace_id
          data_collection_rule_id = var.regional_shared_resources[var.region].dcr_container_insight_id
        }
      )
      azure_intramundi_private_dns_id = module.dns["azure.intramundi.com"].resource.id
      aks_paired_keyvaults_scopes = {
        "01" = {
          scope_id = module.keyvault["01"].key_vault.id
          enabled  = true
        }
      }
      aks_attach_registries_scopes = {
        "01" = {
          scope_id = module.acr["01"].container_registry.id
          enabled  = true
        }
      }
      aks_file_shares_scopes = {
        "01" = {
          scope_id = module.storage["01"].storage_account.id
          enabled  = true
        }
        "02" = {
          scope_id = module.storage["02"].storage_account.id
          enabled  = true
        }
      }
      federated_identity_credential = lookup(container_aks, "federated_identity_credential", var.container_default_specification.aks.federated_identity_credential)

      workbook = { for k, v in local.container_workbook : k =>
        merge(
          {
            display_name = "${v.prefix_name} - ${local.region_code}-aks-${lookup(container_aks, "workload_name", var.project_name)}-${var.environment}-${container_aks.instance_name}"
          },
          v
        ) if contains(var.container_default_specification.aks.workbook, k)
      }
      workload_identity = { for workload_identity_key, workload_identity in var.container_default_specification.aks.prometheus.enable ? merge(var.container_aks_workload_identity, var.container_default_specification.aks.argocd.aks_workload_identity, var.container_default_specification.aks.prometheus.aks_workload_identity) : merge(var.container_aks_workload_identity, var.container_default_specification.aks.argocd.aks_workload_identity) : workload_identity_key => merge(
        {
          id_name             = "${local.region_code}-id-${lookup(container_aks, "workload_name", var.project_name)}-${var.environment}-${container_aks.instance_name}-${workload_identity.namespace}-${workload_identity.application_name}-${workload_identity.instance_name}"
          fed_id_name         = "${local.region_code}-fd-${lookup(container_aks, "workload_name", var.project_name)}-${var.environment}-${container_aks.instance_name}-${workload_identity.namespace}-${workload_identity.application_name}-${workload_identity.instance_name}"
          resource_group_name = azurerm_resource_group.container[workload_identity.resource_group_key].name
          location            = azurerm_resource_group.container[workload_identity.resource_group_key].location
          tags                = workload_identity.tags
        },
        workload_identity,
        {
          role_assignment = { for role_assignment_key, role_assignment in workload_identity.role_assignment : role_assignment_key => merge(
            role_assignment,
            {
              scope_id = try("${role_assignment.scope_sa_key != null ? module.storage[role_assignment.scope_sa_key].storage_account.id : role_assignment.scope_acr_key != null ? module.acr[role_assignment.scope_acr_key].container_registry.id : role_assignment.scope_id}${role_assignment.scope_suffix}", null)
            })
          }
        }
        ) if workload_identity.container_aks_key == container_aks_key
      }
      customer_managed_key = {
        key_vault_key_id                      = module.keyvault[var.container_default_specification.key_vault_key].key["container-01"].versionless_id
        key_vault_resource_id                 = module.keyvault[var.container_default_specification.key_vault_key].key_vault.id
        disable_container_aks_disk_encryption = var.disable_container_aks_disk_encryption
      }
    },
    container_aks,
    {
      node_pool = { for node_pool_key, node_pool in var.container_aks_node_pool : node_pool_key =>
        merge(
          {
            name                 = "${substr(replace(lookup(container_aks, "workload_name", var.project_name), "-", ""), 0, 7)}${var.environment}${node_pool.instance_name}"
            os_disk_type         = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].os_disk_type
            auto_scaling_enabled = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].auto_scaling_enabled
            min_count            = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].min_count
            max_count            = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].max_count
            max_surge            = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].max_surge
            priority             = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].priority
            spot_max_price       = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].spot_max_price
            eviction_policy      = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].eviction_policy
          },
          node_pool,
          {
            os_disk_type = coalesce(node_pool.os_disk_type, var.container_default_specification.aks.default_node_pool["${local.environment_type}"].os_disk_type)
            vm_size      = coalesce(node_pool.vm_size, var.container_default_specification.aks.default_node_pool["${local.environment_type}"].vm_size)
            node_taints  = try(coalescelist(node_pool.node_taints, var.container_default_specification.aks.default_node_pool["${local.environment_type}"].node_taints), null)
          }
        )
      }
      prometheus = merge(
        lookup(container_aks, "prometheus", var.container_default_specification.aks.prometheus),
        {
          private_endpoint = { for private_endpoint_key, private_endpoint in var.container_default_specification.aks.prometheus.private_endpoint : private_endpoint_key =>
            merge(
              private_endpoint,
              {
                alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

                instance_name       = private_endpoint.instance_name
                region_code         = coalesce(private_endpoint.region_code, local.region_code)
                location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.container[lookup(container_aks, "resource_group_key", "01")].location) : coalesce(private_endpoint.location, azurerm_resource_group.container[lookup(container_aks, "resource_group_key", "01")].location)
                resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[lookup(container_aks, "resource_group_key", "01")].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

                private_dns_zone_ids = private_endpoint.alias == "current" ? [module.dns["privatelink.${local.location_cli}.prometheus.monitor.azure.com"].resource.id] : [var.dns_default_specification.dns_private_zone["privatelink_${local.location_cli}_prometheus_monitor_azure_com"].private_dns_zone_id]
                subnet_id            = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
                address_prefix       = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
                ip_configuration     = private_endpoint.ip_configuration
              }
            )
          if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }
        }
      )
    },
    {
      private_endpoint = { for private_endpoint_key, private_endpoint in container_aks.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = lookup(private_endpoint, "instance_name", "01")
            region_code         = lookup(private_endpoint, "region_code", local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[lookup(container_aks, "resource_group_key", "01")].location) : lookup(private_endpoint, "location", azurerm_resource_group.shared_services[lookup(container_aks, "resource_group_key", "01")].location)
            resource_group_name = private_endpoint.alias == "current" ? lookup(private_endpoint, "resource_group_name", azurerm_resource_group.private_link[lookup(container_aks, "resource_group_key", "01")].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            blob_private_dns_id         = private_endpoint.alias == "current" ? module.dns["privatelink.blob.core.windows.net"].resource.id : var.dns_default_specification.dns_private_zone.privatelink_blob_core_windows_net.private_dns_zone_id
            aks_private_dns_id          = private_endpoint.alias == "current" ? module.dns["private.${local.location_cli}.azmk8s.io"].resource.id : var.dns_default_specification.dns_private_zone["${local.location_cli}_azmk8s_io"].private_dns_zone_id
            aks_private_endpoint_dns_id = private_endpoint.alias == "current" ? null : lookup(var.dns_default_specification.dns_private_zone["${local.location_cli}_azmk8s_io"], "private_endpoint_dns_zone_id", null)

            subnet_id = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id

            address_prefix = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[lookup(private_endpoint, "subnet_key", "01-snet-back-private-endpoints-01")].address_prefixes[0] : null

            ip_configuration = lookup(private_endpoint, "ip_configuration", [])
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }

      tags = merge(lookup(container_aks, "tags", local.tags))
    }
  ) if var.container_creation && var.container_default_specification.aks.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation }

  container_aks_post_install = { for helm_release_key, helm_release in var.container_aks : helm_release_key => {
    helm_release = merge({
      "caas-system" = {
        chart_type = "Namespace"
        set = [
          {
            name  = "name"
            value = "caas-system"
          },
          {
            name  = "istio_version"
            value = coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].status == "enabled" ? coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].revisions[0] : ""
          }
        ]
      }

      "intramundi-forwarder-namespace" = {
        chart_type = "Namespace"
        set = [
          {
            name  = "name"
            value = "intramundi-forwarder"
          },
          {
            name  = "istio_version"
            value = coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].status == "enabled" ? coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].revisions[0] : ""
          }
        ]
      }

      "file-share-01-ssd" = {
        chart_type   = "StorageClassFile"
        force_update = true
        set = [
          {
            name  = "name"
            value = "file-share-01-ssd"
          },
          {
            name  = "resourceGroup"
            value = split("/", module.storage["01"].storage_account.id)[4]
          },
          {
            name  = "reclaimPolicy"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_file_share.reclaim_policy
          },
          {
            name  = "storageAccount"
            value = basename(module.storage["01"].storage_account.id)
          },
          {
            name  = "server"
            value = "${basename(module.storage["01"].storage_account.id)}.file.core.windows.net"
          },
        ]
      }

      "file-share-02-hdd" = {
        chart_type   = "StorageClassFile"
        force_update = true
        set = [
          {
            name  = "name"
            value = "file-share-02-hdd"
          },
          {
            name  = "resourceGroup"
            value = split("/", module.storage["02"].storage_account.id)[4]
          },
          {
            name  = "reclaimPolicy"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_file_share.reclaim_policy
          },
          {
            name  = "storageAccount"
            value = basename(module.storage["02"].storage_account.id)
          },
          {
            name  = "server"
            value = "${basename(module.storage["02"].storage_account.id)}.file.core.windows.net"
          },
        ]
      }

      "disk-access-01" = {
        chart_type   = "StorageClassDisk"
        force_update = true
        set = concat([
          {
            name  = "name"
            value = "disk-access-01"
          },
          {
            name  = "DiskAccessID"
            value = module.aks[helm_release_key].aks_private_disk_access["01"].id
          },
          {
            name  = "skuname"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_disk_01.disk_sku_name
          },
          {
            name  = "reclaimPolicy"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_disk_01.reclaim_policy
          },
          {
            name  = "volumeBindingMode"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_disk_01.volume_binding_mode
          }
          ], module.aks[helm_release_key].aks_disk_encryption_set_id != null ? [{
            name  = "diskEncryptionSetID"
            value = module.aks[helm_release_key].aks_disk_encryption_set_id
        }] : [])
      }

      "disk-access-02" = {
        chart_type   = "StorageClassDisk"
        force_update = true
        set = concat([
          {
            name  = "name"
            value = "disk-access-02"
          },
          {
            name  = "DiskAccessID"
            value = module.aks[helm_release_key].aks_private_disk_access["01"].id
          },
          {
            name  = "skuname"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_disk_02.disk_sku_name
          },
          {
            name  = "reclaimPolicy"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_disk_02.reclaim_policy
          },
          {
            name  = "volumeBindingMode"
            value = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].storage_class_disk_02.volume_binding_mode
          }
          ], module.aks[helm_release_key].aks_disk_encryption_set_id != null ? [{
            name  = "diskEncryptionSetID"
            value = module.aks[helm_release_key].aks_disk_encryption_set_id
        }] : [])
      }

      "coredns-custom" = {
        chart_type = "coredns"
        namespace  = "kube-system"
        set = [
          {
            name  = "serviceCidr"
            value = var.container_default_specification.aks.network_profile.service_cidr
          }
        ]
      }

      "psql-trading-secret" = {
        chart_type = "SecretProviderClass-psql"
        set = [
          {
            name  = "namespace"
            value = var.container_default_specification.aks.helm_release.psql-trading-secret.namespace
          },
          {
            name  = "tenantId"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "userAssignedIdentityID"
            value = module.aks[helm_release_key].aks_key_vault_secrets_provider_client_id
          },
          {
            name  = "keyvaultName"
            value = basename(module.keyvault["01"].key_vault.id)
          }
        ]
      }

      "traefik" = {
        chart_type = "traefik"
        namespace  = "caas-system"

        private_link_id = "/subscriptions/${var.subscription_id_client}/resourceGroups/${local.container_aks["01"].node_resource_group}/providers/Microsoft.Network/privateLinkServices/${local.region_code}-pl-${var.project_name}-traefik-${var.environment}-01"

        set = [
          {
            name  = "traefik.service.annotations.service\\.beta\\.kubernetes\\.io/azure-load-balancer-ipv4"
            value = var.container_default_specification.aks.traefik_azure_load_balancer_ipv4
          },
          {
            name  = "traefik.service.annotations.service\\.beta\\.kubernetes\\.io/azure-pls-name"
            value = "${local.region_code}-pl-${var.project_name}-traefik-${var.environment}-01"
          },
          {
            name  = "traefik.service.annotations.service\\.beta\\.kubernetes\\.io/azure-pls-visibility"
            value = "${var.environment == "prd" ? var.subscription_id_shared_services_prd : var.subscription_id_shared_services_np}"
          },
          {
            name  = "traefik.service.annotations.service\\.beta\\.kubernetes\\.io/azure-pls-auto-approval"
            value = "${var.environment == "prd" ? var.subscription_id_shared_services_prd : var.subscription_id_shared_services_np}"
          },
          {
            name  = "traefik.deployment.replicas"
            value = var.container_default_specification.aks.helm_release["${local.environment_type}"].replicas["traefik.deployment.replicas"]
          },
          {
            name  = "traefik.image.registry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "traefik.image.repository"
            value = "container/vendors/traefik"
          },
          {
            name  = "traefik.image.registry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "traefik.image.repository"
            value = "container/vendors/traefik"
          },
          {
            name  = "secrets.tenantId"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "secrets.userAssignedIdentityID"
            value = module.aks[helm_release_key].aks_key_vault_secrets_provider_client_id
          },
          {
            name  = "secrets.keyvaultName"
            value = basename(module.keyvault["01"].key_vault.id)
          },
          {
            name  = "custom.ingress.dashboard.host"
            value = "${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-traefik-${var.project_name}.azure.intramundi.com"
          },
        ]
      }

      "argocd" = {
        chart_type = "argocd"
        namespace  = "caas-system"
        set = [
          {
            name  = "argo-cd.global.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/argoproj/argocd"
          },
          {
            name  = "argo-cd.global.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/argoproj/argocd"
          },
          {
            name  = "argo-cd.configs.cm.url"
            value = "https://${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-argocd-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "argo-cd.server.ingress.hostname"
            value = "${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-argocd-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "argo-cd.controller.replicas"
            value = var.container_default_specification.aks.helm_release["${local.environment_type}"].replicas["argo-cd.controller.replicas"]
          },
          {
            name  = "argo-cd.server.replicas"
            value = var.container_default_specification.aks.helm_release["${local.environment_type}"].replicas["argo-cd.server.replicas"]
          },
          {
            name  = "argo-cd.repoServer.replicas"
            value = var.container_default_specification.aks.helm_release["${local.environment_type}"].replicas["argo-cd.repoServer.replicas"]
          },
          {
            name  = "argo-cd.repoServer.serviceAccount.annotations.azure\\.workload\\.identity/client-id"
            value = module.aks[helm_release_key].aks_workload_identity["argocd"].client_id
          },
          {
            name  = "argo-cd.repoServer.extraContainers[0].image"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/argoproj/argocd:v2.11.14"
          },
          {
            name  = "argo-cd.repoServer.extraContainers[0].image"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/argoproj/argocd:v2.11.14"
          },
          {
            name  = "argo-cd.applicationSet.replicas"
            value = var.container_default_specification.aks.helm_release["${local.environment_type}"].replicas["argo-cd.applicationSet.replicas"]
          },
          {
            name  = "argo-cd.redis.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/redis"
          },
          {
            name  = "argo-cd.redis.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/redis"
          },
          {
            name  = "argo-cd.redis.metrics.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/oliver006/redis_exporter"
          },
          {
            name  = "cronJob.env[0].name"
            value = "tenantId"
          },
          {
            name  = "cronJob.env[0].value"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "cronJob.env[1].name"
            value = "keyvaultName"
          },
          {
            name  = "cronJob.env[1].value"
            value = basename(module.keyvault["01"].key_vault.id)
          },
          {
            name  = "cronJob.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "secrets.tenantId"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "secrets.userAssignedIdentityID"
            value = module.aks[helm_release_key].aks_key_vault_secrets_provider_client_id
          },
          {
            name  = "secrets.keyvaultName"
            value = basename(module.keyvault["01"].key_vault.id)
          },
          {
            name  = "secret.custom_ca_certificates.namespace"
            value = "caas-system"
          },
          {
            name  = "secret.helm_private_repo.namespace"
            value = "caas-system"
          },
          {
            name  = "secret.helm_private_repo.url"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "secret.helm_private_repo.name"
            value = "${basename(module.acr["01"].container_registry.id)}"
          },
        ]

        values = [
          <<EOT
argo-cd:
  configs:
    cm:
      oidc.config: |
        name: Keycloak
        issuer: ${var.regional_shared_resources[var.region].argocd[var.environment].realms_uri}
        clientID: ${var.regional_shared_resources[var.region].argocd[var.environment].client_id}
        clientSecret: $argocd-oidc-secret:oidc.keycloak.clientSecret
        requestedScopes: ["openid", "offline_access", "email"]
EOT
        ]
      }

      "sysdig-namespace" = {
        chart_type = "Namespace"
        set = [
          {
            name  = "name"
            value = "sysdig"
          },
          {
            name  = "istio_version"
            value = coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].status == "enabled" ? coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].revisions[0] : ""
          }
        ]
      }

      "sysdig" = {
        chart_type = "sysdig"
        namespace  = "sysdig"
        set = [
          {
            name  = "shield.cluster.image.registry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "shield.cluster.image.repository"
            value = "container/vendors/sysdig/cluster-shield"
          },
          {
            name  = "shield.cluster.image.registry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "shield.cluster.image.repository"
            value = "container/vendors/sysdig/cluster-shield"
          },
          {
            name  = "shield.cluster.replica_count"
            value = var.container_default_specification.aks.helm_release["${local.environment_type}"].replicas["shield.cluster.replica_count"]
          },
          {
            name  = "shield.host.image.registry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "shield.host.image.repository"
            value = "container/vendors/sysdig"
          },
          {
            name  = "shield.host.image.registry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "shield.host.image.repository"
            value = "container/vendors/sysdig"
          },
          {
            name  = "secrets.tenantId"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "secrets.userAssignedIdentityID"
            value = module.aks[helm_release_key].aks_key_vault_secrets_provider_client_id
          },
          {
            name  = "secrets.keyvaultName"
            value = basename(module.keyvault["01"].key_vault.id)
          },
          {
            name  = "shield.cluster_config.name"
            value = "${local.region_code}-aks-${lookup(helm_release, "workload_name", var.project_name)}-${var.environment}-${helm_release.instance_name}"
          },
        ]
      }

      "istio" = coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].status == "enabled" ? {
        chart_type = "istio"
        namespace  = "aks-istio-system"
        set = [
          {
            name  = "PeerAuthentication.name"
            value = "default"
          },
          {
            name  = "PeerAuthentication.namespace"
            value = "aks-istio-system"
          },
          {
            name  = "PeerAuthentication.spec.mtls.mode"
            value = coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].mtls_mode
          },
        ]
      } : null

      "prometheus" = var.container_default_specification.aks.prometheus.enable ? {
        chart_type = "prometheus"
        namespace  = "caas-system"
        set = [
          {
            name  = "prometheus-azure.global.imageRegistry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "prometheus-azure.alertmanager.alertmanagerSpec.image.repository"
            value = "container/vendors/prometheus/alertmanager"
          },
          {
            name  = "prometheus-azure.grafana.image.repository"
            value = "container/vendors/grafana/grafana"
          },
          {
            name  = "prometheus-azure.grafana.sidecar.image.repository"
            value = "container/vendors/kiwigrid/k8s-sidecar"
          },
          {
            name  = "prometheus-azure.prometheusOperator.image.repository"
            value = "container/vendors/prometheus-operator/prometheus-operator"
          },
          {
            name  = "prometheus-azure.kube-state-metrics.image.repository"
            value = "container/vendors/kube-state-metrics/kube-state-metrics"
          },
          {
            name  = "prometheus-azure.prometheus.prometheusSpec.image.repository"
            value = "container/vendors/prometheus/prometheus"
          },
          {
            name  = "prometheus-azure.prometheusOperator.prometheusConfigReloader.image.repository"
            value = "container/vendors/prometheus-operator/prometheus-config-reloader"
          },
          {
            name  = "prometheus-azure.prometheus.ingress.hosts[0]"
            value = "${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-prometheus-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "prometheus-azure.global.imageRegistry"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
          },
          {
            name  = "prometheus-azure.alertmanager.alertmanagerSpec.image.repository"
            value = "container/vendors/prometheus/alertmanager"
          },
          {
            name  = "prometheus-azure.grafana.image.repository"
            value = "container/vendors/grafana/grafana"
          },
          {
            name  = "prometheus-azure.grafana.sidecar.image.repository"
            value = "container/vendors/kiwigrid/k8s-sidecar"
          },
          {
            name  = "prometheus-azure.prometheusOperator.image.repository"
            value = "container/vendors/prometheus-operator/prometheus-operator"
          },
          {
            name  = "prometheus-azure.kube-state-metrics.image.repository"
            value = "container/vendors/kube-state-metrics/kube-state-metrics"
          },
          {
            name  = "prometheus-azure.prometheus.prometheusSpec.image.repository"
            value = "container/vendors/prometheus/prometheus"
          },
          {
            name  = "prometheus-azure.prometheusOperator.prometheusConfigReloader.image.repository"
            value = "container/vendors/prometheus-operator/prometheus-config-reloader"
          },
          {
            name  = "prometheus-azure.prometheus.ingress.hosts[0]"
            value = "${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-prometheus-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "prometheus-azure.prometheus.prometheusSpec.externalLabels.cluster"
            value = local.container_aks_common_values[helm_release_key].name
          },
          {
            name  = "prometheus-azure.prometheus.prometheusSpec.containers[0].image"
            value = "mcr.microsoft.com/azuremonitor/containerinsights/ciprod/prometheus-remote-write/images:prom-remotewrite-20250326.1"
          },
          {
            name  = "prometheus-azure.prometheus.prometheusSpec.containers[0].env[0].value"
            value = module.aks[helm_release_key].aks_workload_identity["prometheus"].metrics_ingestion_endpoint
          },
          {
            name  = "prometheus-azure.prometheus.serviceAccount.annotations.azure\\.workload\\.identity/client-id"
            value = module.aks[helm_release_key].aks_workload_identity["prometheus"].client_id
          },
          {
            name  = "prometheus-azure.alertmanager.ingress.hosts[0]"
            value = "${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-alertmanager-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "prometheus-azure.alertmanager.alertmanagerSpec.externalUrl"
            value = "https://${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-alertmanager-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "secrets.tenantId"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "secrets.userAssignedIdentityID"
            value = module.aks[helm_release_key].aks_key_vault_secrets_provider_client_id
          },
          {
            name  = "secrets.keyvaultName"
            value = basename(module.keyvault["01"].key_vault.id)
          },
          {
            name  = "prometheus-azure.alertmanager.ingress.hosts[0]"
            value = "${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-alertmanager-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "prometheus-azure.alertmanager.alertmanagerSpec.externalUrl"
            value = "https://${var.environment == "prd" ? "" : "${var.environment}-"}${local.region_code}-alertmanager-${var.project_name}.azure.intramundi.com"
          },
          {
            name  = "secrets.tenantId"
            value = data.azurerm_client_config.current.tenant_id
          },
          {
            name  = "secrets.userAssignedIdentityID"
            value = module.aks[helm_release_key].aks_key_vault_secrets_provider_client_id
          },
          {
            name  = "secrets.keyvaultName"
            value = basename(module.keyvault["01"].key_vault.id)
          },
          {
            name  = "aks-cluster-name"
            value = module.aks[helm_release_key].aks.name
          }
        ]
      } : null

      "gemini" = {
        chart_type = "gemini"
        namespace  = "caas-system"
        set = [
          {
            name  = "gemini.image.repository"
            value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io/container/vendors/fairwinds/gemini"
          }
        ]
      }

      },
      {
        for amundi_product in var.azure_devops["01"].amundi_products : "01-argocd-bootstrap-${amundi_product}" => {
          chart_type = "argocd-bootstrap"
          namespace  = "caas-system"
          set = [
            {
              name  = "bootstrap.source.gitRepoURL"
              value = "https://dev.azure.com/amundi-technology/${coalesce(var.azure_devops["01"].region_code, local.region_code)}-${coalesce(var.azure_devops["01"].devops_project["01"].workload_name, var.project_name)}-prd-${coalesce(var.azure_devops["01"].devops_project["01"].instance_name, "01")}/_git"
            },
            {
              name  = "bootstrap.source.helmRegistry"
              value = "${basename(module.acr["01"].container_registry.id)}.azurecr.io"
            },
            {
              name  = "bootstrap.source.subPath"
              value = "argocd-manifest/${var.environment}"
            },
            {
              name  = "bootstrap.projects[0].name"
              value = "${local.container_aks_common_values["01"].name}-bootstrap-${amundi_product}"
            },
            {
              name  = "bootstrap.destination.namespace"
              value = "caas-system"
            },
            {
              name  = "bootstrap.projects[0].apps[0].name"
              value = "${local.container_aks_common_values["01"].name}-bootstrap-${amundi_product}"
            },
            {
              name  = "bootstrap.projects[0].apps[0].repo"
              value = "${amundi_product}"
            },
            {
              name  = "secret.git_private_repo.name"
              value = replace("git_private_repo-${amundi_product}", "_", "-")
            },
            {
              name  = "secret.git_private_repo.namespace"
              value = "caas-system"
            },
            {
              name  = "secret.git_private_repo.url"
              value = "https://dev.azure.com/amundi-technology/${coalesce(var.azure_devops["01"].region_code, local.region_code)}-${coalesce(var.azure_devops["01"].devops_project["01"].workload_name, var.project_name)}-prd-${coalesce(var.azure_devops["01"].devops_project["01"].instance_name, "01")}/_git"
            },
          ]
        }
      },
      {
        for namespace in local.container_aks_namespace : "01-namespace-${namespace}" => {
          chart_type = "Namespace"
          set = [
            {
              name  = "name"
              value = namespace
            },
            {
              name  = "istio_version"
              value = coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].status == "enabled" ? coalescelist(local.container_aks[helm_release_key].service_mesh_profile, var.container_default_specification.aks.service_mesh_profile)[0].revisions[0] : ""
            }
          ]
        }
      }
    )
    }
  if var.container_creation && var.container_default_specification.aks.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation }

  container_endpoints = merge(
    {
      for container_aks_key, container_aks in var.container_aks :
      #traefik private endpoint in the shared services zone
      "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-traefik" => {
        alias               = "shared_services_${local.environment_type}"
        instance_name       = container_aks.instance_name
        environment_type    = local.environment_type
        subnet_key          = null
        location            = var.region_shared_services != null ? var.region_shared_services : var.region
        resource_group_name = var.region_shared_services != null ? "${var.region_code[var.region_shared_services]}-rg-private-link-${local.environment_type}-01" : "${local.region_code}-rg-private-link-${local.environment_type}-01"
        subnet_id           = var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
        dns_a_record = {
          name = local.traefik_dns_a_record_name
          tags = merge({
            probeUriPrefixPath         = "https://"
            probeUriSuffixPath         = "/dashboard/#/"
            probeSuccessHttpStatusCode = "200"
          }, local.tags)
        }
        dns_cname_record = { for name in toset(local.traefik_dns_cname_record_name) : name =>
          {
            name = name
            tags = merge(contains(keys(local.traefik_private_endpoint_cname_record), name) ? merge(local.traefik_private_endpoint_cname_record[name].tags, local.tags) : merge({
              probeUriPrefixPath         = "https://"
              probeUriSuffixPath         = "/"
              probeSuccessHttpStatusCode = strcontains(name, "-prometheus-") || strcontains(name, "-alertmanager-") ? "401" : "200"
            }, local.tags))
          }
        }
        tags = merge(lookup(container_aks, "tags", {}), local.tags)
        private_service_connection = {
          name                           = "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-traefik"
          private_connection_resource_id = lookup(local.container_aks_post_install[container_aks_key].helm_release, "traefik", null) == null ? null : local.container_aks_post_install[container_aks_key].helm_release.traefik.private_link_id
        }
        ip_configuration = var.container_default_specification.aks.traefik_shared_services_private_ip_address == null ? [] : [{
          private_ip_address = var.container_default_specification.aks.traefik_shared_services_private_ip_address
        }]
      } if var.container_creation && var.container_default_specification.aks.create
    },
    {
      for container_aks_key, container_aks in var.container_aks :
      #shared on-premise application keycloak private endpoint in the client zone
      "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-keycloak" => {
        alias               = "current"
        instance_name       = container_aks.instance_name
        environment_type    = local.environment_type
        subnet_key          = null
        location            = var.region
        resource_group_name = azurerm_resource_group.private_link[lookup(container_aks, "resource_group_key", "01")].name
        subnet_id           = azurerm_subnet.connectivity[var.container_default_specification.aks.default_node_pool["${local.environment_type}"].keycloak.shared_application.subnet_key].id
        dns_a_record        = null
        dns_cname_record    = null
        tags                = merge(lookup(container_aks, "tags", {}), local.tags)
        private_service_connection = {
          name                           = "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-keycloak"
          private_connection_resource_id = var.container_default_specification.aks.default_node_pool["${local.environment_type}"].keycloak.shared_application.private_link_id
        }
        ip_configuration = [for value in var.container_default_specification.aks.default_node_pool["${local.environment_type}"].keycloak.shared_application.ip_configuration :
          {
            name               = "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-keycloak"
            private_ip_address = cidrhost(azurerm_subnet.connectivity[var.container_default_specification.aks.default_node_pool["${local.environment_type}"].keycloak.shared_application.subnet_key].address_prefixes[0], value.cidrhost_hostnum)
          }
        ]

      } if var.container_creation && var.container_default_specification.aks.create && var.container_default_specification.aks.default_node_pool["${local.environment_type}"].keycloak.shared_application.private_link_id != null
    },
    {
      for container_aks_key, container_aks in var.container_aks :
      #shared regional infrastructure keycloak private endpoint in the client zone
      "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-keycloak-infrastructure" => {
        alias               = "current"
        instance_name       = container_aks.instance_name
        environment_type    = local.environment_type
        subnet_key          = null
        location            = var.region
        resource_group_name = azurerm_resource_group.private_link[lookup(container_aks, "resource_group_key", "01")].name
        subnet_id           = azurerm_subnet.connectivity[var.regional_shared_resources[var.region].keycloak_infrastructure.subnet_key].id
        dns_a_record        = null
        dns_cname_record    = null
        tags                = merge(lookup(container_aks, "tags", {}), local.tags)
        private_service_connection = {
          name                           = "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-keycloak-infrastructure"
          private_connection_resource_id = var.regional_shared_resources[var.region].keycloak_infrastructure["${local.environment_type}_private_link_id"]
        }
        ip_configuration = [for value in var.regional_shared_resources[var.region].keycloak_infrastructure.ip_configuration :
          {
            name               = "${var.environment}-${lookup(container_aks, "workload_name", var.project_name)}-keycloak"
            private_ip_address = cidrhost(azurerm_subnet.connectivity[var.regional_shared_resources[var.region].keycloak_infrastructure.subnet_key].address_prefixes[0], value.cidrhost_hostnum)
          }
        ]

      } if var.container_creation && var.container_default_specification.aks.create && var.regional_shared_resources[var.region].keycloak_infrastructure["${local.environment_type}_private_link_id"] != null
      //local.environment_type
    }
  )
  container_workbook = {
    "AksLogs" = {
      workbook_file_name = "AksLogs.json"
      prefix_name        = "AKS container logs"
    }
  }

  container_app_environment = { for environment_key, environment in var.container_app_environment : environment_key => merge(
    {
      name                               = "${local.region_code}-cae-${coalesce(environment.workload_name, var.project_name)}-${var.environment}-${environment.instance_name}"
      resource_group_name                = azurerm_resource_group.container[environment.resource_group_key].name
      location                           = azurerm_resource_group.container[environment.resource_group_key].location
      infrastructure_resource_group_name = replace(azurerm_resource_group.container[environment.resource_group_key].name, "-10", "-11")
      infrastructure_subnet_id           = azurerm_subnet.connectivity[environment.subnet_key].id
      log_analytics_workspace_id         = var.regional_shared_resources[var.region].log_analytics_workspace_id
      logs_destination                   = var.container_default_specification.container_app.logs_destination
    },
    environment,
    {
      zone_redundancy_enabled = coalesce(environment.zone_redundancy_enabled, var.container_default_specification.container_app[local.environment_type].zone_redundancy_enabled)
      tags                    = merge(environment.tags, local.tags)
      workload_profile        = coalescelist(environment.workload_profile, var.container_default_specification.container_app.workload_profile)
      private_endpoint = { for private_endpoint_key, private_endpoint in environment.private_endpoint : private_endpoint_key =>
        merge(
          private_endpoint,
          {
            alias = private_endpoint.alias == "current" ? private_endpoint.alias : var.environment == "prd" ? "shared_services_prd" : "shared_services_np"

            instance_name       = private_endpoint.instance_name
            region_code         = coalesce(private_endpoint.region_code, local.region_code)
            location            = private_endpoint.alias == "shared-services" ? var.region_shared_services != null ? var.region_shared_services : coalesce(private_endpoint.location, azurerm_resource_group.container[environment.resource_group_key].location) : coalesce(private_endpoint.location, azurerm_resource_group.container[environment.resource_group_key].location)
            resource_group_name = private_endpoint.alias == "current" ? coalesce(private_endpoint.resource_group_name, azurerm_resource_group.private_link[environment.private_link_resource_group_key].name) : var.environment == "prd" ? "frc-rg-private-link-prd-01" : "frc-rg-private-link-np-01"

            private_dns_zone_ids = private_endpoint.alias == "current" ? [module.dns["privatelink.${local.location_cli}.azurecontainerapps.io"].resource.id] : [var.dns_default_specification.dns_private_zone["${local.location_cli}_azurecontainerapps_io"].private_dns_zone_id]
            subnet_id            = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].id : var.environment == "prd" ? var.regional_shared_resources[var.region].subnet_shared_services.prd_id : var.regional_shared_resources[var.region].subnet_shared_services.np_id
            address_prefix       = private_endpoint.alias == "current" ? azurerm_subnet.connectivity[private_endpoint.subnet_key].address_prefixes[0] : null
            ip_configuration     = private_endpoint.ip_configuration
          }
        )
      if contains(["current", "shared-services"], private_endpoint.alias) && (private_endpoint.alias == "current" && var.virtual_network_creation == false ? false : true) }
    }
  ) if var.container_creation && var.container_default_specification.container_app.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation }


  container_app = { for app_key, app in var.container_app : app_key => merge(
    {},
    app,
    {
      container_registry_id         = lookup(app, "container_registry_id", module.acr[var.container_default_specification.container_app.acr_key].container_registry.id)
      key_vault_id                  = module.keyvault[lookup(app, "key_vault_key", var.container_default_specification.container_app.key_vault_key)].key_vault.id
      name                          = "${local.region_code}-ca-${lookup(app, "workload_name", var.project_name)}-${lookup(app, "name", app_key)}-${var.environment}-${lookup(app, "instance_name", "01")}"
      resource_group_name           = lookup(app, "resource_group_name", azurerm_resource_group.container[var.container_default_specification.container_app.resource_group_key].name)
      container_app_environment_key = lookup(app, "container_app_environment_key", var.container_default_specification.container_app.container_app_environment_key)
      workload_profile_name         = lookup(app, "workload_profile_name", var.container_default_specification.container_app.workload_profile_name)
      auth_configs = lookup(app, "auth_configs", null) != null ? {
        for config_key, config in app.auth_configs : config_key => merge(
          config,
          {
            name = lookup(config, "name", config_key)
            identity_providers = {
              azure_active_directory = {
                enabled             = lookup(config.identity_providers.azure_active_directory, "enabled", true)
                is_auto_provisioned = false
                registration = {
                  client_id                  = module.keyvault[lookup(app, "key_vault_key", var.container_default_specification.container_app.key_vault_key)].aad_application[config.aad_application_key].application_client_id
                  open_id_issuer             = "https://login.microsoftonline.com/${data.azurerm_client_config.current.tenant_id}/v2.0"
                  client_secret_setting_name = lookup(config.identity_providers.azure_active_directory.registration, "client_secret_setting_name", null)
                }
              }
            }
          }
        )
      } : null
    }
    ) if var.container_creation && var.container_default_specification.container_app.create && var.shared_services_creation && var.private_link_creation && var.virtual_network_creation
  }
}
