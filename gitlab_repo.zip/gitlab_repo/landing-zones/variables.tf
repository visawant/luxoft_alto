variable "subscription_id_client" {
  type        = string
  description = "value of the subscription ID for the Client subscription"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_client))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "subscription_id_shared_services" {
  type        = string
  description = "value of the subscription id for the Shared Services subscription"
  default     = "cf199ca0-37f5-4acb-8dff-9e4d284790b7"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_shared_services))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "subscription_id_shared_services_np" {
  type        = string
  description = "value of the subscription id for the Shared Services subscription np"
  default     = "cf199ca0-37f5-4acb-8dff-9e4d284790b7"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_shared_services_np))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "subscription_id_shared_services_prd" {
  type        = string
  description = "value of the subscription id for the Shared Services subscription prd"
  default     = "06990571-f710-403d-b219-b59325a657d6"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_shared_services_prd))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "subscription_id_networking" {
  type        = string
  description = "value of the subscription id for the network domain"
  default     = "e45c4f94-9c06-4fce-b933-eccc2963e937"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_networking))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "avm_enable_telemetry" {
  description = <<DESCRIPTION
This variable controls whether or not telemetry is enabled for Azure Verified Modules (AVM) the module.
For more information see https://aka.ms/avm/telemetryinfo.
If it is set to false, then no telemetry will be collected.

Example usage:
enable_telemetry = false
DESCRIPTION
  type        = bool
  default     = true
}

variable "project_name" {
  description = "Project name used by our Cloud naming convention: https://confluence.intramundi.com/display/ITSPCI/Cloud+naming+convention"
  type        = string
  validation {
    // When higher than 10 you need to overwrite the key vault workbload name
    condition     = length(var.project_name) <= 15 && can(regex("^[a-zA-Z0-9-]*$", var.project_name))
    error_message = "The Project name must be less than 15 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "ops_team" {
  description = "Team accountable for day-to-day operations."
  type        = string
  validation {
    condition     = length(var.ops_team) <= 256 && can(regex("^[a-zA-Z0-9-]*$", var.ops_team))
    error_message = "The ops_team name must be less than 256 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "it_owner" {
  description = "Top-level division of your company that owns the subscription or workload that the resource belongs to. In smaller organizations, this tag might represent a single corporate or shared top-level organizational element."
  type        = string
  validation {
    condition     = length(var.it_owner) <= 256 && can(regex("^[a-zA-Z0-9-@.]*$", var.it_owner))
    error_message = "The it_owner name must be less than 256 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  validation {
    condition     = length(var.environment) <= 3 && contains(["dmo", "tst", "rct", "dev", "uat", "np", "ppr", "prd"], var.environment)
    error_message = "Valid value is one of the following: dmo, tst, rct,  dev, uat, np, ppr, prd."
  }
}

variable "tags" {
  description = "Additional tags"
  type        = map(any)
  default     = {}
}

variable "microsoft_graph" {
  description = "Microsoft Graph application ID and its OAuth2 permission scopes"
  type = object({
    id = optional(string)
    oauth2_permission_scopes = optional(map(object({
      admin_consent_description  = optional(string)
      admin_consent_display_name = optional(string)
      enabled                    = optional(bool)
      id                         = optional(string)
      type                       = optional(string)
      user_consent_description   = optional(string)
      user_consent_display_name  = optional(string)
      value                      = optional(string)
    })))
  })

  default = {
    id = "00000003-0000-0000-c000-000000000000"
    oauth2_permission_scopes = {
      "User.Read" = {
        admin_consent_description  = "Allows users to sign-in to the app, and allows the app to read the profile of signed-in users. It also allows the app to read basic company information of signed-in users."
        admin_consent_display_name = "Sign in and read user profile"
        enabled                    = true
        id                         = "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
        type                       = "User"
        user_consent_description   = "Allows you to sign in to the app with your organizational account and let the app read your profile. It also allows the app to read basic company information."
        user_consent_display_name  = "Sign you in and read your profile"
        value                      = "User.Read"
      }
      "email" = {
        admin_consent_description  = "Allows the app to read your users' primary email address"
        admin_consent_display_name = "View users' email address"
        enabled                    = true
        id                         = "64a6cdd6-aab1-4aaf-94b8-3cc8405e90d0"
        type                       = "User"
        user_consent_description   = "Allows the app to read your primary email address"
        user_consent_display_name  = "View your email address"
        value                      = "email"
      }
      "openid" = {
        admin_consent_description  = "Allows users to sign in to the app with their work or school accounts and allows the app to see basic user profile information."
        admin_consent_display_name = "Sign users in"
        enabled                    = true
        id                         = "37f7f235-527c-4136-accd-4a02d197296e"
        type                       = "User"
        user_consent_description   = "Allows you to sign in to the app with your work or school account and allows the app to read your basic profile information."
        user_consent_display_name  = "Sign in as you"
        value                      = "openid"
      }
      "profile" = {
        admin_consent_description  = "Allows the app to see your users' basic profile (e.g., name, picture, user name, email address)"
        admin_consent_display_name = "View users' basic profile"
        enabled                    = true
        id                         = "14dad69e-099b-42c9-810b-d002981feec1"
        type                       = "User"
        user_consent_description   = "Allows the app to see your basic profile (e.g., name, picture, user name, email address)"
        user_consent_display_name  = "View your basic profile"
        value                      = "profile"
      }
      "Organization.Read.All" = {
        admin_consent_description  = "Allows the app to read the organization and related resources, without a signed-in user. Related resources include things like subscribed skus and tenant branding information."
        admin_consent_display_name = "Read organization information"
        enabled                    = true
        id                         = "498476ce-e0fe-48b0-b801-37ba7e2685c6"
        type                       = "User"
        user_consent_description   = ""
        user_consent_display_name  = "Read organization information"
        value                      = "Organization.Read.All"
      }
      "Application.Read.All" = {
        admin_consent_description  = "Allows the app to read all applications and service principals without a signed-in user"
        admin_consent_display_name = "Read all applications"
        enabled                    = true
        id                         = "9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30"
        type                       = "User"
        user_consent_description   = "Allows the app to read all applications and service principals without a signed-in user"
        user_consent_display_name  = "Read all applications"
        value                      = "Application.Read.All"
      }
      "AuditLog.Read.All" = {
        admin_consent_description  = "Allows the app to read and query your audit log activities, without a signed-in user"
        admin_consent_display_name = "Read all audit log data"
        enabled                    = true
        id                         = "b0afded3-3588-46d8-8b3d-9842eff778da"
        type                       = "User"
        user_consent_description   = "Allows the app to read and query your audit log activities, without a signed-in user"
        user_consent_display_name  = "Read all audit log data"
        value                      = "AuditLog.Read.All"
      }
      "Directory.Read.All" = {
        admin_consent_description  = "Allows the app to read data in your organization's directory, such as users, groups and apps, without a signed-in user"
        admin_consent_display_name = "Read directory data"
        enabled                    = true
        id                         = "7ab1d382-f21e-4acd-a863-ba3e13f7da61"
        type                       = "User"
        user_consent_description   = "Allows the app to read data in your organization's directory, such as users, groups and apps, without a signed-in user"
        user_consent_display_name  = "Read directory data"
        value                      = "Directory.Read.All"
      }
      "Group.Read.All" = {
        admin_consent_description  = "Allows the app to read group properties and memberships, and read conversations for all groups, without a signed-in user"
        admin_consent_display_name = "Read all groups"
        enabled                    = true
        id                         = "5b567255-7703-4780-807c-7be8301ae99b"
        type                       = "User"
        user_consent_description   = "Allows the app to read group properties and memberships, and read conversations for all groups, without a signed-in user"
        user_consent_display_name  = "Read all groups"
        value                      = "Group.Read.All"
      }
      "Policy.Read.All" = {
        admin_consent_description  = "Allows an app to read published sensitivity labels and label policy settings for the entire organization or a specific user, without a signed in user"
        admin_consent_display_name = "Read all published labels and label policies for an organization"
        enabled                    = true
        id                         = "246dd0d5-5bd0-4def-940b-0421030a5b68"
        type                       = "User"
        user_consent_description   = "Allows an app to read published sensitivity labels and label policy settings for the entire organization or a specific user, without a signed in user"
        user_consent_display_name  = "Read all published labels and label policies for an organization"
        value                      = "Policy.Read.All"
      }
      "User.Read.All" = {
        admin_consent_description  = "Allows the app to read user profiles without a signed in user"
        admin_consent_display_name = "Read all users' full profiles"
        enabled                    = true
        id                         = "df021288-bdef-4463-88db-98f22de89214"
        type                       = "User"
        user_consent_description   = "Allows the app to read user profiles without a signed in user"
        user_consent_display_name  = "Read all users' full profiles"
        value                      = "User.Read.All"
      }
    }
  }
}

variable "region" {
  description = "Azure region"
  type        = string
  validation {
    condition     = contains(["France Central", "Central India", "East Asia", "East US 2", "Sweden Central", "Switzerland North", "West Europe"], var.region)
    error_message = "The region must be one of the following: France Central, Central India, East Asia, East US 2, Sweden Central, Switzerland North, West Europe."
  }
}

variable "disable_container_registry_encryption" {
  description = "Legacy option for unencrypted ACR, as mentioned in the following documentation we can currently enable a customer-managed key only while creating a registry"
  type        = bool
  default     = false
}

variable "disable_container_aks_disk_encryption" {
  description = "Legacy option for unencrypted AKS, as mentioned in the following documentation we can currently enable a customer-managed key only while creating an AKS cluster registry https://learn.microsoft.com/en-us/azure/aks/azure-disk-customer-managed-keys?WT.mc_id=AZ-MVP-5003548"
  type        = bool
  default     = false
}

variable "region_shared_services" {
  description = "Only use this variable if the shared services is different than the Azure region"
  type        = string
  default     = null
}

variable "region_code" {
  description = "Azure region code defined by the Cloud Adoption Framework: https://github.com/Azure/terraform-azurerm-caf-enterprise-scale/blob/main/modules/connectivity/locals.geo_codes.tf.json"
  type        = map(any)
  default = {
    "France Central"    = "frc"
    "francecentral"     = "frc"
    "Central India"     = "inc"
    "centralindia"      = "inc"
    "East Asia"         = "ea"
    "East US 2"         = "eus2"
    "Sweden Central"    = "sdc"
    "swedencentral"     = "sdc"
    "West Europe"       = "we"
    "westeurope"        = "we"
    "Switzerland North" = "szn"
    "switzerlandnorth"  = "szn"
  }
}

variable "regional_shared_resources" {
  description = "Regional shared resources"
  type = map(object({
    log_analytics_workspace_id = optional(string, "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.OperationalInsights/workspaces/frc-log-management-01")
    dcr_container_insight_id   = optional(string, "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.Insights/dataCollectionRules/frc-dcr-container-insight-01")
    mysql = optional(object({
      user_assigned_identity_entra_id_np_id  = optional(string, "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-database-np-01/providers/Microsoft.ManagedIdentity/userAssignedIdentities/frc-id-mysql-shared-services-np-01")
      user_assigned_identity_entra_id_prd_id = optional(string, "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-database-prd-01/providers/Microsoft.ManagedIdentity/userAssignedIdentities/frc-id-mysql-shared-services-prd-01")
    }), {})
    subnet_shared_services = object({
      np_id  = string
      prd_id = string
    })
    subnet_shared_services_nic_with_multiple_ips = object({
      np_id  = string
      prd_id = string
    })
    utc_offset = string
    keycloak_infrastructure = optional(object({
      np_private_link_id  = optional(string)
      prd_private_link_id = optional(string)
      private_link_id     = optional(string)
      subnet_key          = optional(string, "01-snet-front-private-endpoints-01")
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = optional(string, null)
        })), [
        {
          cidrhost_hostnum = 32 // Take the IP address number "cidrhost_hostnum" of the current subnet
        }
      ])
    }), {})
    argocd = optional(object({
      dev = optional(object({
        realms_uri = optional(string, "https://rct.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "dev-ac2-240061")
      }), {})
      rct = optional(object({
        realms_uri = optional(string, "https://rct.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "rct-ac2-240062")
      }), {})
      uat = optional(object({
        realms_uri = optional(string, "https://rct.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "rct-ac2-240062")
      }), {})
      dmo = optional(object({
        realms_uri = optional(string, "https://ppr.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "ppr-ac2-240063")
      }), {})
      tst = optional(object({
        realms_uri = optional(string, "https://ppr.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "ppr-ac2-240063")
      }), {})
      ppr = optional(object({
        realms_uri = optional(string, "https://ppr.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "ppr-ac2-240063")
      }), {})
      np = optional(object({
        realms_uri = optional(string, "https://ppr.accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "ppr-ac2-240063")
      }), {})
      prd = optional(object({
        realms_uri = optional(string, "https://accounts.amundi.com/auth/realms/amundi")
        client_id  = optional(string, "prd-ac2-240064")
      }), {})
    }), {})
  }))
  default = {
    "France Central" = {
      subnet_shared_services = {
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-02"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-02"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-03"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-03"
      }
      utc_offset = "+01:00"
    }
    "Central India" = {
      subnet_shared_services = {
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/inc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/inc-vnet-shared-services-np-01/subnets/snet-shared-01"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/inc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/inc-vnet-shared-services-prd-01/subnets/snet-shared-01"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/inc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/inc-vnet-shared-services-np-01/subnets/snet-shared-01"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/inc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/inc-vnet-shared-services-prd-01/subnets/snet-shared-01"
      }
      mysql = {
        user_assigned_identity_entra_id_np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/inc-rg-database-np-01/providers/Microsoft.ManagedIdentity/userAssignedIdentities/inc-id-mysql-shared-services-np-01"
        user_assigned_identity_entra_id_prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/inc-rg-database-prd-01/providers/Microsoft.ManagedIdentity/userAssignedIdentities/inc-id-mysql-shared-services-prd-01"
      }
      utc_offset = "+05:30"
    }
    "East Asia" = {
      subnet_shared_services = {
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/ea-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/ea-vnet-shared-services-np-01/subnets/snet-shared-01"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/ea-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/ea-vnet-shared-services-prd-01/subnets/snet-shared-01"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        //Currently is the same because we have enough IP space in the subnet.
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/ea-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/ea-vnet-shared-services-np-01/subnets/snet-shared-01"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/ea-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/ea-vnet-shared-services-prd-01/subnets/snet-shared-01"
      }
      utc_offset = "+08:00"
      keycloak_infrastructure = {
        np_private_link_id = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/ea-rg-container-np-02/providers/Microsoft.Network/privateLinkServices/ea-pl-management-traefik-np-01"
      }
      mysql = {
        user_assigned_identity_entra_id_np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/ea-rg-database-np-01/providers/Microsoft.ManagedIdentity/userAssignedIdentities/ea-id-mysql-shared-services-np-01"
        user_assigned_identity_entra_id_prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/ea-rg-database-prd-01/providers/Microsoft.ManagedIdentity/userAssignedIdentities/ea-id-mysql-shared-services-prd-01"
      }
      argocd = {
        dev = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        rct = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        dmo = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        tst = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        uat = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        np = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        ppr = {
          realms_uri = "https://np-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
        }
        /* Doesn't exist yet       
      prd = {
        realms_uri = "https://prd-ea-sso-infra.azure.intramundi.com/auth/realms/admin-infra"
      } */
      }
    }
    "East US 2" = {
      subnet_shared_services = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-02"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-02"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-03"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-03"
      }
      utc_offset = "-05:00"
    }
    "Sweden Central" = {
      log_analytics_workspace_id = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.OperationalInsights/workspaces/frc-log-management-01"
      dcr_container_insight_id   = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.Insights/dataCollectionRules/frc-dcr-container-insight-01"
      subnet_shared_services = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-02"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-02"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-03"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-03"
      }
      utc_offset = "+01:00"
    }
    "West Europe" = {
      log_analytics_workspace_id = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.OperationalInsights/workspaces/frc-log-management-01"
      dcr_container_insight_id   = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.Insights/dataCollectionRules/frc-dcr-container-insight-01"
      subnet_shared_services = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-02"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-02"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-03"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-03"
      }
      utc_offset = "+00:00"
    }
    "Switzerland North" = {
      log_analytics_workspace_id = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.OperationalInsights/workspaces/frc-log-management-01"
      dcr_container_insight_id   = "/subscriptions/ee7a9bed-4936-4aa8-a7ed-d9cb2fc1a781/resourceGroups/frc-rg-management-01/providers/Microsoft.Insights/dataCollectionRules/frc-dcr-container-insight-01"
      subnet_shared_services = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-02"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-02"
      }
      subnet_shared_services_nic_with_multiple_ips = {
        // Will be updated when we will have the shared-services regional vnet
        np_id  = "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-connectivity-np-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-np-01/subnets/snet-shared-03"
        prd_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-connectivity-prd-01/providers/Microsoft.Network/virtualNetworks/frc-vnet-shared-services-prd-01/subnets/snet-shared-03"
      }
      utc_offset = "+01:00"
    }
  }
}

variable "init" {
  type        = bool
  default     = false
  description = "Workaround to deal with unfixe terraform depedencies - Set to true to initialize the landing zone and false to deploy the workload"
}

##############################################
###### connectivity area specifications
##############################################
variable "virtual_network_creation" {
  description = "Create a Virtual Network"
  type        = bool
  default     = false
}

variable "virtual_network_default_specification" {
  description = "Virtual Network default specifications"
  type        = any
  default = {
    private_endpoint_network_policies = "Enabled"
    service_endpoints                 = [] //Set it to null to prevent Data exfiltration
  }
}

variable "connectivity_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure-network",
        it_owner = "g-x-admin-azure-network"
      }
    }
  }
}

variable "connectivity_virtual_network" {
  description = "Virtual Network specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        description = "default vnet"
        ops_team    = "g-x-admin-azure-network",
        it_owner    = "g-x-admin-azure-network"
      }
      address_space = ["10.0.0.0/16", "10.1.0.0/16", "10.3.0.0/16"]
      subnets = {
        "01-AzureBastionSubnet" = {
          name             = "AzureBastionSubnet"
          address_prefixes = ["10.0.0.0/26"]
        }
        "01-snet-front-01" = {
          name             = "snet-front-01"
          address_prefixes = ["10.0.0.64/26"]
        }
        "01-snet-front-private-endpoints-01" = {
          name             = "snet-front-private-endpoints-01"
          address_prefixes = ["10.0.0.128/25"]
        }
        "01-snet-back-private-endpoints-01" = {
          name             = "snet-back-private-endpoints-01"
          address_prefixes = ["10.0.1.0/25", "10.0.2.128/26"]
        }
        "01-snet-back-private-endpoints-02" = {
          name             = "snet-back-private-endpoints-02"
          address_prefixes = ["10.0.2.64/26"]
        }
        "01-snet-private-link-01" = {
          name                                          = "snet-private-link-01"
          address_prefixes                              = ["10.0.1.128/25"]
          private_link_service_network_policies_enabled = false
        }
        "01-snet-psql-flexible-01" = {
          name             = "snet-psql-flexible-01"
          address_prefixes = ["10.0.2.0/26"]
          delegation = [{
            name = "psql-flexible"
            service_delegation = [{
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/join/action",
              ]
              name = "Microsoft.DBforPostgreSQL/flexibleServers"
            }]
          }]
        }
        "01-snet-aks-01" = {
          name                                          = "snet-aks-01"
          address_prefixes                              = ["10.0.240.0/20"]
          private_link_service_network_policies_enabled = false //Seems to be not supported when the subnet is managed by aks
        }
        "01-snet-aks-02" = {
          name             = "snet-aks-02"
          address_prefixes = ["10.1.0.0/20"]
          delegation = [{
            name = "aks-delegation"
            service_delegation = [{
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/join/action",
              ]
              name = "Microsoft.ContainerService/managedClusters"
            }]
          }]
        }
        "01-snet-app-service-01" = {
          name             = "snet-snet-app-service-01"
          address_prefixes = ["10.0.192.0/26"]
          delegation = [{
            name = "Microsoft.Web.serverFarms"
            service_delegation = [{
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/action",
              ]
              name = "Microsoft.Web/serverFarms"
            }]
          }]
        }
        "01-snet-container-app-01" = {
          name             = "snet-container-app-01"
          address_prefixes = ["10.0.224.0/23"]
          delegation = [{
            name = "container-app-delegation"
            service_delegation = [{
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/join/action",
              ]
              name = "Microsoft.App/environments"
            }]
          }]
        }
        "01-snet-container-app-devops-01" = {
          name             = "snet-container-app-devops-01"
          address_prefixes = ["10.0.226.0/25"]
          delegation = [{
            name = "container-app-delegation"
            service_delegation = [{
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/join/action",
              ]
              name = "Microsoft.App/environments"
            }]
          }]
        }
        "01-snet-container-instance-devops-01" = {
          name             = "snet-container-instance-devops-01"
          address_prefixes = ["10.0.226.128/25"]
          delegation = [{
            name = "container-instance-delegation"
            service_delegation = [{
              actions = [
                "Microsoft.Network/virtualNetworks/subnets/action",
              ]
              name = "Microsoft.ContainerInstance/containerGroups"
            }]
          }]
        }
        "01-snet-aviatrix-spoke-gateway-01" = {
          name             = "snet-aviatrix-spoke-gateway-01"
          address_prefixes = ["10.0.239.240/28"]
        }
        "01-snet-iaas-01" = {
          name             = "snet-iaas-01"
          address_prefixes = ["10.3.0.0/26"]
        }
      }
    }
  }
}

variable "connectivity_route_table" {
  description = "Route table specifications"
  type = map(object({
    instance_name       = optional(string, "01")
    resource_group_key  = optional(string, "01")
    virtual_network_key = optional(string, "01")
    workload_name       = optional(string, "default")
    tags                = optional(map(string), {})
    route = optional(list(object({
      name                   = optional(string, null)
      address_prefix         = optional(string)
      next_hop_type          = optional(string)
      next_hop_in_ip_address = optional(string, null)
    })), [])
  }))
  default = {
    "default-01" = {
      instance_name       = "01"
      resource_group_key  = "01"
      virtual_network_key = "01"
      workload_name       = "default"
      tags = {
        description = "default route table"
        ops_team    = "g-x-admin-azure-network",
        it_owner    = "g-x-admin-azure-network"
      }
      route = [
        {
          name           = "Default"
          address_prefix = "0.0.0.0/0"
          next_hop_type  = "None"
        }
      ]
    }
    "internet-01" = {
      instance_name       = "01"
      resource_group_key  = "01"
      virtual_network_key = "01"
      workload_name       = "internet"
      tags = {
        description = "default internet table"
        ops_team    = "g-x-admin-azure-network",
        it_owner    = "g-x-admin-azure-network"
      }
      route = [
        {
          name           = "internet"
          address_prefix = "0.0.0.0/0"
          next_hop_type  = "Internet"
        }
      ]
    }
    "aviatrix-01" = {
      instance_name       = "01"
      resource_group_key  = "01"
      virtual_network_key = "01"
      workload_name       = "aviatrix"
      route               = []
      tags = {
        description = "aviatrix route table"
        ops_team    = "g-x-admin-azure-network",
        it_owner    = "g-x-admin-azure-network"
      }
    }
  }
}

variable "connectivity_public_ip" {
  description = "Public Ip specifications"
  type        = any
  default     = {}
}

variable "connectivity_aviatrix_gateway" {
  description = "Aviatrix spoke gateway"
  type = map(object({
    instance_name             = optional(string, "01")
    gateway_type              = optional(string, "spoke")
    ha_instance_name          = optional(string, "02")
    subnet_key                = optional(string, "01-snet-aviatrix-spoke-gateway-01")
    virtual_network_key       = optional(string, "01")
    aviatrix_account_create   = optional(bool, true)
    workload_name             = optional(string)
    enable_vpc_dns_server     = optional(bool, false)
    instance_size             = optional(string)
    zone                      = optional(string, "az-1")
    ha_zone                   = optional(string, "az-2")
    single_ip_snat            = optional(bool, true)
    single_az_ha              = optional(bool, true)
    filtered_spoke_vpc_routes = optional(string, null)
    snat_policy = optional(list(object({
      src_cidr          = optional(string)
      dst_cidr          = optional(string)
      protocol          = optional(string)
      dst_port          = optional(string)
      interface         = optional(string)
      connection        = optional(string)
      apply_route_entry = optional(bool, true)
      snat_ips          = optional(string)
    })), [])
    tags = optional(map(string), {
      description                                          = "aviatrix spoke gateway"
      Audit_Amundi_Network_interfaces_IP_forwarding        = "exclude"
      Amundi_Network_interfaces_should_not_have_public_IPs = "exclude"
      ops_team                                             = "g-x-admin-azure-network",
      it_owner                                             = "g-x-admin-azure-network"
    })
  }))
  default = {
    "default" = {
      instance_name       = "01"
      ha_instance_name    = "02"
      subnet_key          = "01-snet-aviatrix-spoke-gateway-01"
      virtual_network_key = "01"
    }
  }
}
variable "connectivity_aviatrix_gateway_default_specification" {
  description = "Aviatrix spoke gateway default specifications"
  type = object({
    aviatrix_account_create   = optional(bool, true)
    cloud_type                = optional(number, 8)
    rbac_groups               = optional(list(string), ["dat-team"])
    zone                      = optional(string, "az-1")
    ha_zone                   = optional(string, "az-2")
    single_ip_snat            = optional(bool, true)
    enable_vpc_dns_server     = optional(bool, false)
    allocate_new_eip          = optional(bool, false)
    filtered_spoke_vpc_routes = optional(string, null)
    tags = optional(map(string), {
      description                                          = "aviatrix spoke gateway"
      Audit_Amundi_Network_interfaces_IP_forwarding        = "exclude"
      Amundi_Network_interfaces_should_not_have_public_IPs = "exclude"
      ops_team                                             = "g-x-admin-azure-network",
      it_owner                                             = "g-x-admin-azure-network"
    })
    location_specific_config = optional(map(object({
      transit_gw_name   = string
      transit_vnet_name = string
      transit_vnet_rg   = string
      transit_vnet_guid = string
      instance_size     = string
      })), {
      "France Central" = {
        transit_gw_name   = "azu-frc-cld-transit"
        transit_vnet_name = "vnet-frc-avx-cld-transit"
        transit_vnet_rg   = "rg-frc-avx-cld-transit"
        transit_vnet_guid = "fbe8c2e7-0b80-4108-8065-3458b63d6c20"
        instance_size     = "Standard_B1ms"
      }
      "East Asia" = {
        transit_gw_name   = "azu-ea-cld-transit"
        transit_vnet_name = "vnet-ea-avx-cld-transit"
        transit_vnet_rg   = "rg-ea-avx-cld-transit"
        transit_vnet_guid = "976f0d15-af46-4f5b-84e3-f3690ad46f54"
        instance_size     = "Standard_B1ms"
      }
      "Central India" = {
        transit_gw_name   = "azu-inc-cld-transit"
        transit_vnet_name = "vnet-inc-avx-cld-transit"
        transit_vnet_rg   = "rg-inc-avx-cld-transit"
        transit_vnet_guid = "9c1da4aa-aca5-4ff2-9646-927195cb2480"
        instance_size     = "Standard_D2as_v5"
      }
      "Sweden Central" = {
        transit_gw_name   = null
        transit_vnet_name = null
        transit_vnet_rg   = null
        transit_vnet_guid = null
        instance_size     = "Standard_B1ms"
      }
    })
    public_ip = optional(object({
      allocation_method = optional(string, "Static")
      sku               = optional(string, "Standard")
      zones             = optional(list(string), ["1", "2", "3"])
      }), {
      allocation_method = "Static"
      sku               = "Standard"
      zones             = ["1", "2", "3"]
    })
  })

  default = {}
}
variable "connectivity_aviatrix_ha_gw" {
  description = "Aviatrix High Availability Gateway"
  type        = bool
  default     = null
}

variable "connectivity_spoke_transit_attachment" {
  description = "Aviatrix spoke transit attachment"
  type        = bool
  default     = false
}

variable "CONTROLLER_PUBLIC_IP" {
  type        = string
  description = "Controller public IP"

  validation {
    condition     = can(regex("^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$", var.CONTROLLER_PUBLIC_IP))
    error_message = "The Controller public IP must be a valid IPv4 address."
  }
}

variable "CONTROLLER_USERNAME" {
  type        = string
  description = "Controller username"
}

variable "CONTROLLER_PASSWORD" {
  description = "Controller password"
  type        = string
}

variable "AD_SP_AVIATRIX_DAT_APP_ID" {
  type        = string
  description = "AAD Aviatrix DAT account App ID"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}\\-[0-9a-fA-F]{4}\\-[0-9a-fA-F]{4}\\-[0-9a-fA-F]{4}\\-[0-9a-fA-F]{12}$", var.AD_SP_AVIATRIX_DAT_APP_ID))
    error_message = "The AAD Aviatrix DAT account App ID must be a valid GUID/UUID (e.g., 12345678-1234-1234-1234-123456789abc)."
  }
}

variable "AD_SP_AVIATRIX_DAT_SECRET" {
  description = "AAD Aviatrix DAT account secret"
  type        = string
  sensitive   = true
}

variable "connectivity_application_gateway_creation" {
  description = "Create the application gateway "
  type        = bool
  default     = false
}

variable "connectivity_application_gateway" {
  description = "Application gateway specifications"
  type        = any
  default = {
    "01" = {
      instance_name      = "01"
      resource_group_key = "02"
    }
  }
}

variable "connectivity_application_gateway_default_specification" {
  description = "Application gateway default specifications"
  type        = any
  default = {
    application_gateway = {
      instance = "01"
      sku      = {}
      http2    = true
      gateway_ip_configuration = [
        {
          subnet_key = "01-snet-application-gateway-01"
        }
      ]
      frontend_port = [
        {
          name = "http"
          port = 80
        },
        {
          name = "https"
          port = 443
        }
      ]
      frontend_ip_configuration = [
        {
          name                          = "private-front-end-ip"
          subnet_key                    = "01-snet-application-gateway-01"
          cidrhost_hostnum              = 8
          private_ip_address_allocation = "Static"
        },
        {
          name = "public-front-end-ip"
        }
      ]
      backend_address_pool  = []
      backend_http_settings = []
      http_listener = [
        {
          name = "public-http-listener"
        }
      ]
      request_routing_rule = []
      probes               = []
      ssl_certificates = [
        {
          name                = "azure-intramundi-com"
          key_vault_secret_id = "https://frc-kv-shared-prd-02.vault.azure.net/secrets/azure-intramundi-com/a395377ec11a4ed891005b0ec9ca1ade"
        }
      ]

      tags = {
        description                             = "Shared Service Application gateway"
        Exclude_Application_Gateway_Without_WAF = "exclude"
      }
    }
  }
}

variable "application_gateway_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure-network",
        it_owner = "g-x-admin-azure-network"
      }
    }
  }
}
##############################################
###### artifact store
##############################################
variable "ARTIFACT_URL" {
  description = "Artifact store URL"
  type        = string
  default     = "oci://helm-virtual-oci.intramundi.com"
}

variable "ARTIFACT_USERNAME" {
  description = "Artifact store username"
  type        = string
  sensitive   = true
}

variable "ARTIFACT_PASSWORD" {
  description = "Artifact store password"
  type        = string
  sensitive   = true
}

##############################################
###### bastion area specifications
##############################################
variable "bastion_creation" {
  description = "Create a Bastion"
  type        = bool
  default     = false
}

variable "bastion_sku" {
  description = "Bastion SKU"
  type        = string
  validation {
    condition     = contains(["Developer", "Standard"], var.bastion_sku)
    error_message = "Valid value is one of the following: Standard, Developer."
  }
  default = "Developer"
}

variable "bastion_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {

      }
    }
  }
}

variable "bastion_resource" {
  description = "Bastion resources specifications"
  type        = any
  default = {
    "01" = {
      virtual_network_key   = "01"
      subnet_key            = "01-AzureBastionSubnet"
      public_ip_address_key = "01"
      tags = {
        description = "azure bastion"
      }
    }
  }
}

variable "bastion_public_ip" {
  description = "Public Ip specifications"
  type        = any
  default = {
    "01" = {
      resource_group_key = "01"
      allocation_method  = "Static"
      sku                = "Standard"
      tags = {
        description = "azure bastion"
      }
    }
  }
}

variable "bastion_default_specification" {
  description = "Bastion default specifications"
  type        = any
  default = {
    zones     = ["1", "2", "3"]
    Developer = {}
    Standard = {
      copy_paste_enabled     = true
      file_copy_enabled      = false
      scale_units            = 2
      shareable_link_enabled = true
    }
  }
}

##############################################
###### dns area specifications
##############################################
variable "dns_creation" {
  description = "Create a DNS area"
  type        = bool
  default     = true
}

variable "dns_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "dns_default_specification" {
  description = "DNS default specifications"
  type        = any
  default = {
    soa_record = {
      email         = "ff5d5b28.amundi.com.fr.teams.ms"
      minimum_ttl   = 10
      refresh_time  = 3600
      retry_time    = 300
      serial_number = 1
      ttl           = 3600
    }
    dns_private_zone = {
      azure_intramundi_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/azure.intramundi.com"
      }
      privatelink_azure_websites_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"
      }
      privatelink_servicebus_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.windows.net"
      }
      privatelink_vaultcore_azure_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
      }
      privatelink_azurecr_io = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io"
      }
      privatelink_blob_core_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
      }
      privatelink_queue_core_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
      }
      privatelink_table_core_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.windows.net"
      }
      privatelink_dfs_core_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
      }
      privatelink_file_core_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.windows.net"
      }
      francecentral_azmk8s_io = {
        private_dns_zone_id          = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/francecentral.azmk8s.io"
        private_endpoint_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/private.francecentral.azmk8s.io"
      }
      centralindia_azmk8s_io = {
        private_dns_zone_id          = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/centralindia.azmk8s.io"
        private_endpoint_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/private.centralindia.azmk8s.io"
      }
      eastasia_azmk8s_io = {
        private_dns_zone_id          = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/eastasia.azmk8s.io"
        private_endpoint_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/private.eastasia.azmk8s.io"
      }
      eastus2_azmk8s_io = {
        private_dns_zone_id          = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/eastus2.azmk8s.io"
        private_endpoint_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/private.eastus2.azmk8s.io"
      }
      swedencentral_azmk8s_io = {
        private_dns_zone_id          = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/swedencentral.azmk8s.io"
        private_endpoint_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/private.swedencentral.azmk8s.io"
      }
      privatelink_postgres_database_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.postgres.database.azure.com"
      }
      privatelink_database_windows_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"
      }
      privatelink_mysql_database_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.mysql.database.azure.com"
      }
      privatelink_openai_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.openai.azure.com"
      }
      privatelink_cognitiveservices_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com"
      }
      privatelink_services_ai_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.services.ai.azure.com"
      }
      privatelink_api_azureml_ms = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.api.azureml.ms"
      }
      privatelink_notebooks_azure_net = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.notebooks.azure.net"
      }
      francecentral_azurecontainerapps_io = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.francecentral.azurecontainerapps.io"
      }
      centralindia_azurecontainerapps_io = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.centralindia.azurecontainerapps.io"
      }
      eastasia_azurecontainerapps_io = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.eastasia.azurecontainerapps.io"
      }
      eastus2_azurecontainerapps_io = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.eastus2.azurecontainerapps.io"
      }
      swedencentral_azurecontainerapps_io = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.swedencentral.azurecontainerapps.io"
      }
      privatelink_francecentral_prometheus_monitor_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.francecentral.prometheus.monitor.azure.com"
      }
      privatelink_eastus2_prometheus_monitor_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.eastus2.prometheus.monitor.azure.com"
      }
      privatelink_eastasia_prometheus_monitor_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.eastasia.prometheus.monitor.azure.com"
      }
      privatelink_centralindia_prometheus_monitor_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.centralindia.prometheus.monitor.azure.com"
      }
      privatelink_swedencentral_prometheus_monitor_azure_com = {
        private_dns_zone_id = "/subscriptions/e45c4f94-9c06-4fce-b933-eccc2963e937/resourceGroups/frc-rg-dns-01/providers/Microsoft.Network/privateDnsZones/privatelink.swedencentral.prometheus.monitor.azure.com"
      }
      virtual_network_links = {
        "default-01" = {
          virtual_network_key = "01"
        }
      }
      tags = {
        description = "dns private zones"
        ops_team    = "g-x-admin-azure",
      }
    }

    dns_public_zone = {
      resource_group_name = "frc-rg-dns-01"
      record_ttl          = 300
    }
  }
}

variable "dns_private_zone" {
  description = "DNS zones specifications"
  type        = any
  default = {
    "azure.intramundi.com" = {
      domain_name = "azure.intramundi.com"
    }
    "intramundi_com" = {
      domain_name = "intramundi.com"
    }
    "unix.sits.credit-agricole.fr" = {
      domain_name = "unix.sits.credit-agricole.fr"
    }
  }
}

variable "dns_private_zone_a_records" {
  description = "DNS host A records for the Keycload private endpoint in each client zone, see https://confluence.intramundi.com/display/ITSPCI/Keycloak+infrastucture"
  type = map(object({
    name                 = string
    dns_private_zone_key = optional(string, "azure.intramundi.com")
    zone_name            = optional(string, "azure.intramundi.com")
    resource_group_key   = optional(string, "01")
    records              = list(string)
    ttl                  = optional(number, 300)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {}
}

variable "dns_private_endpoint_private_zone" {
  description = "DNS zones specifications for private endpoints, see https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-dns?WT.mc_id=AZ-MVP-5003548"
  type        = any
  default = [
    "privatelink.dfs.core.windows.net",
    "privatelink.queue.core.windows.net",
    "privatelink.table.core.windows.net",
    "privatelink.file.core.windows.net",
    "privatelink.azurecr.io",
    "privatelink.vaultcore.azure.net",
    "private.--region--.azmk8s.io",
    "privatelink.blob.core.windows.net",
    "privatelink.postgres.database.azure.com",
    "privatelink.mysql.database.azure.com",
    "privatelink.database.windows.net",
    "privatelink.openai.azure.com",
    "privatelink.cognitiveservices.azure.com",
    "privatelink.services.ai.azure.com",
    "privatelink.api.azureml.ms",
    "privatelink.notebooks.azure.net",
    "privatelink.--region--.prometheus.monitor.azure.com",
    "privatelink.--region--.azurecontainerapps.io",
    "privatelink.servicebus.windows.net",
    "privatelink.azurewebsites.net"
  ]
}

variable "dns_private_resolver" {
  description = "Dns private resolver specifications"
  type        = any
  default     = {}
}

variable "dns_private_resolver_azure_creation" {
  description = "Create the shared services area with an Azure Key Vaults"
  type        = bool
  default     = false
}

variable "dns_vmss_forwarder_creation" {
  description = "Create the shared services area with an Azure Key Vaults"
  type        = bool
  default     = false
}

variable "dns_records" {
  description = "DNS records to create"
  type = object({
    traefik_private_endpoint_cname_record = map(object({
      container_aks_key = optional(string, "01")
      dns_suffixes      = list(string)
    }))
  })
  default = {
    traefik_private_endpoint_cname_record = {
      "01" = {
        container_aks_key = "replace-with-an-existing-key"
        dns_suffixes = [ //Will be prefixed by the env name for non prod env, sample: alto-amt-china-dmo.azure.intramundi.com
        ]
      }
    }
  }
}

variable "dns_records_http_probe_customization" {
  description = "Custom specification for the http probe based on the dns_records keys"
  type = object({
    traefik_private_endpoint_cname_record = optional(map(object({
      container_aks_key = optional(string, "01")
      tags = optional(object({
        probeUriPrefixPath         = optional(string, "https://")
        probeUriSuffixPath         = optional(string, "/")
        probeSuccessHttpStatusCode = optional(string, "200")
        hostHeader                 = optional(string, "")
        project_name               = optional(string)
        ops_team                   = optional(string, "g-x-admin-azure")
        it_owner                   = optional(string, "g-x-admin-azure")
      }), {})
    })), {})
  })
  default = {
    traefik_private_endpoint_cname_record = {}
  }
}

variable "dns_public_zone" {
  description = "AVM Terraform Module for DNS Zone, https://registry.terraform.io/modules/Azure/avm-res-network-dnszone/azurerm/latest"
  type        = any
  default     = {}
}


##############################################
###### shared services area specifications
##############################################
variable "shared_services_creation" {
  description = "Create the shared services area with an Azure Key Vaults"
  type        = bool
  default     = true
}

variable "shared_services_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    workload_name = optional(string, "shared-services")
    location      = optional(string, null)
    tags          = optional(map(string), {})
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "shared_services_resource_group_managed_by_azure" {
  description = "Resource Group managed by azure specifications"
  type = map(object({
    name          = optional(string, "managed_by_azure")
    location      = optional(string)
    instance_name = optional(string, "01")
    workload_name = optional(string, "shared-services")
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure",
    })
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {
    "01" = {
      name     = "frc-rg-alerting-01"
      location = "francecentral"
      tags = {
        ops_team                 = "g-x-admin-azure",
        it_owner                 = "g-x-admin-azure",
        Project                  = "amba-monitoring",
        _deployed_by_alz_monitor = "true"
      }
    }
    "02" = {
      name     = "frc-rg-microsoft-defender-01"
      location = "francecentral"
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure",
      }
    }
    "03" = {
      name = "NetworkWatcherRG"
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure",
      }
    }
  }
}

variable "custom_shared_services_resource_group_managed_by_azure" {
  description = "Custom Resource Group managed by azure specifications"
  type = map(object({
    name          = optional(string, "managed_by_azure")
    instance_name = optional(string, "01")
    workload_name = optional(string, "shared-services")
    location      = optional(string)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure",
    })
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {}
}

variable "shared_services_default_specification" {
  description = "Shared services default specifications"
  type = object({
    soa_record = optional(object({
      email         = string
      minimum_ttl   = number
      refresh_time  = number
      retry_time    = number
      serial_number = number
      ttl           = number
      }), {
      email         = "ff5d5b28.amundi.com.fr.teams.ms"
      minimum_ttl   = 10
      refresh_time  = 3600
      retry_time    = 300
      serial_number = 1
      ttl           = 3600
    })
    key_vault = optional(object({
      sku_name                  = optional(string, "standard")
      default_key               = optional(string, "01")
      key_vault_key             = optional(string, "shared-services-01")
      enable_rbac_authorization = optional(bool, true)
    }), {})
    existing_certificate = optional(map(object({
      alias        = string
      name         = string
      key_vault_id = string
      })), {
      "01" = {
        alias        = "shared_services_prd"
        name         = "azure-intramundi-com"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
    })
    existing_secret = optional(map(object({
      alias        = string
      name         = string
      key_vault_id = string
      })), {
      "certificate-authority-azure-mysql" = {
        alias        = "shared_services_prd"
        name         = "certificate-authority-azure-mysql"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "app-sysdig-amt-prd-access-key" = {
        alias        = "shared_services_prd"
        name         = "app-sysdig-amt-prd-access-key"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "app-sysdig-amt-prd-api-token" = {
        alias        = "shared_services_prd"
        name         = "app-sysdig-amt-prd-api-token"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-dev-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-dev-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-rct-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-rct-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-uat-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-rct-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-tst-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-ppr-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-dmo-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-ppr-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-ppr-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-ppr-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-np-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-ppr-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "keycloak-argocd-azure-prd-client-secret" = {
        alias        = "shared_services_prd"
        name         = "keycloak-argocd-azure-prd-client-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "sp-azure-devops-self-hosted-agent-01-secret" = {
        alias        = "shared_services_prd"
        name         = "sp-azure-devops-self-hosted-agent-01-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "dbsqware-api-terraform-secret" = {
        alias        = "shared_services_prd"
        name         = "dbsqware-api-terraform-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "prometheus-basic-auth-np-secret" = {
        alias        = "shared_services_prd"
        name         = "prometheus-basic-auth-np-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "prometheus-basic-auth-np-raw-secret" = {
        alias        = "shared_services_prd"
        name         = "prometheus-basic-auth-np-raw-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "prometheus-basic-auth-prd-secret" = {
        alias        = "shared_services_prd"
        name         = "prometheus-basic-auth-prd-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "prometheus-basic-auth-prd-raw-secret" = {
        alias        = "shared_services_prd"
        name         = "prometheus-basic-auth-prd-raw-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "grafana-prd-sa-1-terraform-manage-datasource-secret" = {
        alias        = "shared_services_prd"
        name         = "grafana-prd-sa-1-terraform-manage-datasource-secret"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
      "svc-dat-azuredev-security-scan" = {
        alias        = "shared_services_prd"
        name         = "svc-dat-azuredev-security-scan"
        key_vault_id = "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-shared-services-prd-01/providers/Microsoft.KeyVault/vaults/frc-kv-shared-prd-02"
      }
    })
    container_registry = optional(object({
      prd = optional(object({
        role_assignment = map(object({
          role_definition_name = string
          principal_id         = string
        }))
        }), {
        role_assignment = {
          "sp-jenkins-amt-prd" = {
            role_definition_name = "AcrPush"
            principal_id         = "777b7c3e-064f-419d-bccf-37c61a746d06"
          },
          "frc-id-func-shared-services-prd-01" = {
            role_definition_name = "Deployer-Import (mg-caf-amt)"
            principal_id         = "ec9fe244-11c2-47b0-a48f-0eaab1a41616"
          }
        }
      })
      np = optional(object({
        role_assignment = map(object({
          role_definition_name = string
          principal_id         = string
        }))
        }), {
        role_assignment = {
          "sp-jenkins-amt-np" = {
            role_definition_name = "AcrPush"
            principal_id         = "6d4d5c4c-97a7-4f54-9c5b-91e23168c5d7"
          },
          "frc-id-func-shared-services-prd-01" = {
            role_definition_name = "Deployer-Import (mg-caf-amt)"
            principal_id         = "ec9fe244-11c2-47b0-a48f-0eaab1a41616"
          }
        }
      })
      }), {
      prd = {
        role_assignment = {
          "sp-jenkins-amt-prd" = {
            role_definition_name = "AcrPush"
            principal_id         = "777b7c3e-064f-419d-bccf-37c61a746d06"
          },
          "frc-id-func-shared-services-prd-01" = {
            role_definition_name = "Deployer-Import (mg-caf-amt)"
            principal_id         = "ec9fe244-11c2-47b0-a48f-0eaab1a41616"
          }
        }
      }
      np = {
        role_assignment = {
          "sp-jenkins-amt-np" = {
            role_definition_name = "AcrPush"
            principal_id         = "6d4d5c4c-97a7-4f54-9c5b-91e23168c5d7"
          },
          "frc-id-func-shared-services-prd-01" = {
            role_definition_name = "Deployer-Import (mg-caf-amt)"
            principal_id         = "ec9fe244-11c2-47b0-a48f-0eaab1a41616"
          }
        }
      }
    })
  })
  default = {}
}

variable "shared_services_key_vault" {
  description = "Key Vault specifications"
  type        = any
  default = {
    "01" = {
      instance_name             = "01"
      resource_group_key        = "01"
      enable_rbac_authorization = true
      tags = {
        description = "azure key vault"
        ops_team    = "g-x-admin-azure",
        it_owner    = "g-x-admin-azure"
      }

      role_assignment = {
        "sp-terraform-caf" = {
          role_definition_name = "Key Vault Administrator"
          principal_id         = "1be7ac54-bf01-4444-a014-5710361757d0"
        }
        "GSCO_CREW_DAT" = {
          role_definition_name = "Key Vault Administrator"
          principal_id         = "5ffcc1c1-1bd9-4d28-8215-0feebff9f515"
        }
      }

      import_certificate = {
        "01" = {
          existing_certificate_key = "01"
        }
      }

      import_secret = {
        "certificate-authority-azure-mysql" = {
          existing_secret_key = "certificate-authority-azure-mysql"
        }
        "app-sysdig-amt-prd-access-key" = {
          existing_secret_key = "app-sysdig-amt-prd-access-key"
        }
        "app-sysdig-amt-prd-api-token" = {
          existing_secret_key = "app-sysdig-amt-prd-api-token"
        }
      }

      private_endpoint = {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 4 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias = "shared-services"
        }
      }
    }
    // Specific use cas needed for Machine Learning when we need an Access Policy Key Vault instead of an RBAC one, see https://learn.microsoft.com/en-us/azure/ai-services/openai/encrypt-data-at-rest?WT.mc_id=AZ-MVP-5003548#use-customer-managed-keys-with-azure-key-vault
    "03" = {
      instance_name             = "03"
      resource_group_key        = "01"
      enable_rbac_authorization = false
      tags = {
        description = "azure key vault"
        ops_team    = "g-x-admin-azure",
        it_owner    = "g-x-admin-azure"
      }

      access_policy = {
        "sp-terraform-caf" = {
          principal_id = "1be7ac54-bf01-4444-a014-5710361757d0"
          key_permissions = [
            "Create",
            "Get",
            "Delete",
            "Purge",
            "GetRotationPolicy",
          ]
          secret_permissions = [
            "Get",
            "Set",
            "List",
            "Delete",
            "Purge",
          ]
        }
        "GSCO_CREW_DAT" = {
          principal_id = "5ffcc1c1-1bd9-4d28-8215-0feebff9f515"
          key_permissions = [
            "Create",
            "Get",
            "List",
            "Delete",
            "Purge",
            "GetRotationPolicy",
          ]
          secret_permissions = [
            "Get",
            "Set",
            "List",
            "Delete",
            "Purge",
          ]
        }
      }

      private_endpoint = {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 24 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias = "shared-services"
        }
      }
    }
  }
}

variable "shared_services_key_vault_secret" {
  description = "Secret list to create"
  type = map(object({
    name = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default  = {}
  nullable = true
}

variable "shared_services_aad_application" {
  description = "Entra ID application/service principal to create"
  type = map(object({
    display_name = string
    owners = optional(list(string), [
      "1be7ac54-bf01-4444-a014-5710361757d0", //sp-terraform-caf
      "523df6f1-6072-4ece-8124-a52040fefca3", // Lance Adrien (AO account) 
      "6ca1eec1-c066-46f2-9186-0066149a95da", // Dumont James (AO account)
      "0c89993c-8018-4d10-8507-812e6abd51ba", // Charrier Bastien (AO account)
      "b7ce3147-fad1-4fba-9e87-a7bb0a388319"  // Ganvet Dieuveil (AO account)
    ])
    description                       = string
    sign_in_audience                  = optional(string)
    identifier_uris                   = optional(list(string), [])
    identifier_uris_use_own_client_id = optional(bool, false)
    required_resource_access = optional(list(object({
      resource_app_id                    = optional(string, null)
      resource_app_id_microsoft_graph_id = optional(bool, false)
      resource_access = optional(list(object({
        id                                             = optional(string, null)
        id_microsoft_graph_oauth2_permission_scope_key = optional(string, null)
        type                                           = optional(string, null)
      })), [])
    })), [])
    web = optional(list(object({
      redirect_uris = optional(list(string), [])
      implicit_grant = optional(object({
        access_token_issuance_enabled = optional(bool)
        id_token_issuance_enabled     = optional(bool)
      }), {})
    })), [])
    key_vault_key = optional(string, "01")
    secret = object({
      name                  = string
      days_to_expire        = optional(number, 90)
      version               = optional(string, null)
      role_assignment_scope = optional(list(string), [])
    })
  }))
  default  = {}
  nullable = true
}

variable "shared_services_container_registry" {
  description = "Container registry specifications"
  type = map(object({
    instance_name         = optional(string, "01")
    resource_group_key    = optional(string, "01")
    workload_name         = optional(string)
    location              = optional(string)
    sku                   = optional(string, "Premium")
    export_policy_enabled = optional(bool, false)
    key_vault_key         = optional(string)
    key_vault_key_key     = optional(string)
    tags = optional(map(string), {
      description = "azure container registry"
      ops_team    = "g-x-admin-azure",
      it_owner    = "g-x-admin-azure"
    })
    private_endpoint = optional(map(object({
      alias               = string
      instance_name       = optional(string, "01")
      region_code         = optional(string)
      location            = optional(string)
      resource_group_name = optional(string)
      subnet_key          = optional(string)
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = optional(string, null)
      })), [])
      })),
      {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 5 // Take the IP address number "cidrhost_hostnum" of the current subnet
              member_name      = "registry"
            },
            {
              cidrhost_hostnum = 6 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias = "shared-services"
        }
      }
    )
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
    })))
  }))
  default = {
    "01" = {}
  }
}

variable "shared_services_storage_account" {
  description = "Storage account specifications"
  type        = any
  default = {
    "01" = {
      instance_name      = "01"
      resource_group_key = "01"
      account_tier       = "Premium"
      account_kind       = "FileStorage"
      tags = {
        description = "azure storage account"
        ops_team    = "g-x-admin-azure",
        it_owner    = "g-x-admin-azure"
      }

      private_endpoint = {

        current_file = {
          alias            = "current"
          subresource_name = "file"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 7 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services_file = {
          alias            = "shared-services"
          subresource_name = "file"
        }
      }
    }

    "02" = {
      instance_name      = "02"
      resource_group_key = "01"

      account_tier   = "Standard" // when is_hns_enabled is set to true the account_tier is Standard or Premium with account_kind is BlockBlobStorage
      account_kind   = "StorageV2"
      is_hns_enabled = "true" // must be true for ADLS Gen2
      tags = {
        description = "azure storage account"
        ops_team    = "g-x-admin-azure",
        it_owner    = "g-x-admin-azure"
      }

      private_endpoint = {
        current_file = {
          alias            = "current"
          subresource_name = "file"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 33 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }
        shared-services_file = {
          alias            = "shared-services"
          subresource_name = "file"
        }

        current_blob = {
          alias            = "current"
          subresource_name = "blob"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 34 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }
        shared-services_blob = {
          alias            = "shared-services"
          subresource_name = "blob"
        }

        current-dfs = {
          alias            = "current"
          subresource_name = "dfs"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 39 // Take the IP address number "cidrhost_hostnum" of the current subnet
              //Reserved for a third storage account blob part -> cidrhost_hostnum = 40 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }
        shared-services-dfs = {
          alias            = "shared-services"
          subresource_name = "dfs"
        }
      }
    }
  }
}

variable "shared_services_additional_storage_account" {
  description = "Storage account specifications"
  type        = any
  default     = {}
}

variable "shared_services_storage_account_network_rules_private_link_access" {
  description = "Configuration of the private link access for the storage, could be used for example when Azure Defender has been set at the subscription level"
  type = list(object({
    endpoint_resource_id = string
    endpoint_tenant_id   = optional(string)
  }))
  default = []
}

##############################################
###### private link area specifications
##############################################
variable "private_link_creation" {
  description = "Create the Private Link area"
  type        = bool
  default     = true
}

variable "private_link_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "private_link_default_specification" {
  description = "Container platform default specifications"
  type = object({
    key_vault_key     = optional(string, "01")
    key_vault_key_key = optional(string, "private-link-01")
  })
  default = {}
}

variable "private_link_private_endpoint" {
  type        = any
  description = "Private endpoints"
  default     = {}
}

variable "private_link_forwarding_rule" {
  type = map(object({
    instance_name                                                      = optional(string)
    workload_name                                                      = optional(string)
    environment_type                                                   = optional(string)
    resource_group_key                                                 = optional(string, "01")
    private_link_service_visibility_and_auto_approval_subscription_ids = optional(list(string), [])
    tags                                                               = optional(map(string), {})
    subnet_key_private_link                                            = string
    subnet_key_load_balancer                                           = string
    subnet_key_virtual_machine_scale_set                               = optional(string)
    vmss_linux_admin = optional(object({
      admin_username = optional(string, "amtsharedadm")
    }), {})
    forwarding_rules = map(object({
      source_port         = string
      destination_address = string
      destination_port    = string
      use_vmss_probe      = optional(bool, false)
      interface           = optional(string, "eth0")
      protocol            = optional(string)
    }))
    aviatrix = optional(object({
      use                       = optional(bool, false)
      account_key               = optional(string, "default")
      instance_name             = optional(string, "01")
      gateway_type              = optional(string, "specialty")
      ha_instance_name          = optional(string, "02")
      subnet_key                = optional(string, "01-snet-aviatrix-spoke-gateway-01")
      virtual_network_key       = optional(string, "01")
      aviatrix_account_create   = optional(bool, true)
      workload_name             = optional(string)
      enable_vpc_dns_server     = optional(bool, false)
      instance_size             = optional(string, "Standard_B1ms")
      zone                      = optional(string, "az-1")
      ha_zone                   = optional(string, "az-2")
      single_ip_snat            = optional(bool, false)
      filtered_spoke_vpc_routes = optional(string, null)
      snat_policy = optional(list(object({
        src_cidr          = optional(string)
        dst_cidr          = optional(string)
        protocol          = optional(string)
        dst_port          = optional(string)
        interface         = optional(string)
        connection        = optional(string)
        apply_route_entry = optional(bool, true)
        snat_ips          = optional(string)
      })), [])
      monitor_exclude_list                    = optional(list(string))
      public_subnet_filtering_ha_route_tables = optional(list(string))
      public_subnet_filtering_route_tables    = optional(list(string))
      tags = optional(map(string), {
        description                                          = "aviatrix specialty gateway"
        ops_team                                             = "G-X-ADMIN-AZURE-NETWORK"
        Audit_Amundi_Network_interfaces_IP_forwarding        = "exclude"
        Amundi_Network_interfaces_should_not_have_public_IPs = "exclude"
        ops_team                                             = "g-x-admin-azure",
        it_owner                                             = "g-x-admin-azure"
      })
    }), {})
  }))
  description = "Private Link Forwarding rules"
  default     = {}
}

##############################################
###### shared services area specifications
##############################################
variable "iaas_creation" {
  description = "Create the shared services area"
  type        = bool
  default     = true
}

variable "iaas_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    workload_name = optional(string, "iaas")
    location      = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
  }
}

variable "iaas_vm" {
  description = "Virtual Machine specifications"
  type = map(object({
    type                        = optional(string, "linux")
    instance_name               = optional(string, "01")
    resource_group_key          = optional(string, "01")
    name                        = optional(string, null)
    name_interface              = optional(string, null)
    ip_address                  = optional(string, null)
    ip_address_cidrhost_hostnum = optional(string, 4) // Take the IP address number "cidrhost_hostnum" of the current subnet
    workload_name               = optional(string, "iaas")
    location                    = optional(string, null)
    subnet_key                  = string
    size                        = string
    user                        = optional(string, null)
    password                    = optional(string, null)
    keyvault_key                = optional(string, "01") // Will create by default a secret in the Key Vault key "01"
    vm-shutdown                 = optional(bool, false)
    daily_recurrence_time       = optional(string, "0100")
    timezone                    = optional(string, "Romance Standard Time")
    adddisk                     = optional(bool, false)
    disk                        = optional(any, {})
    source_image_reference      = optional(map(string), null)
    tags                        = optional(map(string), {})
    extension = optional(map(object({
      name                       = string
      publisher                  = string
      type                       = string
      type_handler_version       = string
      auto_upgrade_minor_version = optional(bool)
    })), {})
  }))
  default  = {}
  nullable = true
}

##############################################
###### container area specifications
##############################################

variable "grafana_url_prd" {
  type        = string
  default     = "https://grafana.intramundi.com/"
  description = "A Grafana Connections API address"
}

variable "container_creation" {
  description = "Create the container platform"
  type        = bool
  default     = true
}

variable "container_default_specification" {
  description = "Container platform default specifications"
  type = object({
    key_vault_key = optional(string, "01")
    aks = optional(object({
      create             = optional(bool, true)
      kubernetes_version = optional(string, "1.33")
      prometheus = optional(object({
        enable                        = optional(bool, true)
        required_resource_provider    = optional(list(string), ["Microsoft.Monitor"])
        public_network_access_enabled = optional(bool, false)
        aks_workload_identity = optional(map(object({
          container_aks_key  = optional(string, "01")
          instance_name      = optional(string, "01")
          resource_group_key = optional(string, "01")
          namespace          = optional(string, "caas-system")
          application_name   = optional(string, "prometheus-prometheus-azur-prometheus")
          tags               = optional(map(string))
          role_assignment = optional(map(object({
            role_definition_name       = string
            scope_id                   = optional(string)
            scope_acr_key              = optional(string)
            scope_data_collection_rule = optional(bool, false)
            scope_sa_key               = optional(string)
            scope_suffix               = optional(string, "")
            })), {
            "Monitoring Metrics Publisher" = {
              role_definition_name       = "Monitoring Metrics Publisher"
              scope_data_collection_rule = true
            }
          })
        })), { prometheus = {} })
        role_assignment = optional(map(object({
          role_definition_name = string
          principal_id         = string
          principal_type       = optional(string, "ServicePrincipal")
          })), {
          "sp-grafana-amt-prd" = {
            role_definition_name = "Monitoring Data Reader"
            principal_id         = "815b523d-68cc-4e07-b9ae-e76af02d543a"
          }
        })
        private_endpoint = optional(map(object({
          alias               = string
          instance_name       = optional(string, "01")
          subresource_name    = optional(string, "prometheusMetrics")
          region_code         = optional(string)
          location            = optional(string)
          resource_group_name = optional(string)
          subnet_key          = optional(string, "01-snet-front-private-endpoints-01")
          ip_configuration = optional(list(object({
            name               = optional(string)
            private_ip_address = optional(string)
            cidrhost_hostnum   = optional(number)
            member_name        = optional(string, "queryApi")
            subresource_name   = optional(string, "prometheusMetrics")
          })), [])
          })),
          {
            current = {
              alias = "current"
              ip_configuration = [ // Use this block to fix the IP address
                {
                  cidrhost_hostnum = 36 // Take the IP address number "cidrhost_hostnum" of the current subnet
                }
              ]
            }
            shared-services = {
              alias = "shared-services"
            }
        })
      }), {})
      argocd = optional(object({
        aks_workload_identity = optional(map(object({
          container_aks_key  = optional(string, "01")
          instance_name      = optional(string, "01")
          resource_group_key = optional(string, "01")
          namespace          = optional(string, "caas-system")
          application_name   = optional(string, "argocd-argo-cd-repo-server")
          tags               = optional(map(string))
          role_assignment = optional(map(object({
            role_definition_name       = string
            scope_id                   = optional(string)
            scope_acr_key              = optional(string)
            scope_data_collection_rule = optional(bool, false)
            scope_sa_key               = optional(string)
            scope_suffix               = optional(string, "")
            })), {
            "Monitoring Metrics Publisher" = {
              role_definition_name = "AcrPull"
              scope_acr_key        = "01"
            }
          })
        })), { argocd = {} })
      }), {})
      traefik_azure_load_balancer_ipv4           = optional(string, "10.0.240.6")
      traefik_shared_services_private_ip_address = optional(string)
      workload_identity_enabled                  = optional(bool, true)
      namespace                                  = optional(list(string), [])
      default_node_pool = optional(object({ // General purpose node pool configuration
        instance = optional(string, "01")
        zones    = optional(list(string), ["1", "2", "3"])
        np = optional(object({
          image_cleaner = optional(object({
            enabled        = optional(bool, true)
            interval_hours = optional(number, 48)
            }), {
            enabled        = true
            interval_hours = 48
          })
          maintenance_window_auto_upgrade = optional(list(object({
            frequency    = optional(string)
            interval     = optional(number)
            duration     = optional(number)
            day_of_week  = optional(string)
            day_of_month = optional(number)
            week_index   = optional(string)
            start_time   = optional(string)
            utc_offset   = optional(string)
            start_date   = optional(string)
            not_allowed = optional(list(object({
              start = string
              end   = string
            })), [])
            })), [
            {
              frequency   = "Weekly"
              interval    = 1
              duration    = 4
              day_of_week = "Wednesday"
              start_time  = "01:00"
              start_date  = "2025-01-15T00:00:00Z"
              not_allowed = []
            }
          ])
          automatic_upgrade_channel = optional(string, "patch")
          vm_size                   = optional(string, "Standard_D4d_v5")
          os_disk_type              = optional(string, "Ephemeral")
          auto_scaling_enabled      = optional(bool, true)
          min_count                 = optional(number, 1)
          max_count                 = optional(number, 2)
          max_surge                 = optional(string, "10%")
          priority                  = optional(string, "Spot")
          spot_max_price            = optional(string, "-1")
          eviction_policy           = optional(string, "Delete")
          node_taints               = optional(list(string), ["kubernetes.azure.com/scalesetpriority=spot:NoSchedule"])
          storage_class_file_share = optional(object({
            reclaim_policy = string
            }), {
            reclaim_policy = "Delete"
          })
          storage_class_disk_01 = optional(object({
            reclaim_policy      = string
            disk_sku_name       = string
            volume_binding_mode = string
            }), {
            reclaim_policy      = "Delete"
            disk_sku_name       = "StandardSSD_LRS"
            volume_binding_mode = "WaitForFirstConsumer"
          })
          storage_class_disk_02 = optional(object({
            reclaim_policy      = string
            disk_sku_name       = string
            volume_binding_mode = string
            }), {
            reclaim_policy      = "Delete"
            disk_sku_name       = "StandardSSD_ZRS"
            volume_binding_mode = "WaitForFirstConsumer"
          })
          keycloak = optional(object({
            shared_application = optional(object({
              private_link_id = optional(string, "/subscriptions/cf199ca0-37f5-4acb-8dff-9e4d284790b7/resourceGroups/frc-rg-private-link-np-01/providers/Microsoft.Network/privateLinkServices/frc-pl-keycloak-np-01")
              subnet_key      = optional(string, "01-snet-front-private-endpoints-01")
              ip_configuration = optional(list(object({
                cidrhost_hostnum = number
                member_name      = optional(string, null)
                })), [
                {
                  cidrhost_hostnum = 31 // Take the IP address number "cidrhost_hostnum" of the current subnet
                }
              ])
            }), {})
          }), {})
        }))
        prd = optional(object({
          image_cleaner = optional(object({
            enabled        = optional(bool, true)
            interval_hours = optional(number, 2160)
            }), {
            enabled        = true
            interval_hours = 2160 // 90 days
          })
          maintenance_window_auto_upgrade = optional(list(object({
            frequency    = optional(string)
            interval     = optional(number)
            duration     = optional(number)
            day_of_week  = optional(string)
            day_of_month = optional(number)
            week_index   = optional(string)
            start_time   = optional(string)
            utc_offset   = optional(string)
            start_date   = optional(string)
            not_allowed = optional(list(object({
              start = string
              end   = string
            })), [])
            })), [
            {
              frequency   = "RelativeMonthly"
              interval    = 1
              duration    = 4
              day_of_week = "Wednesday"
              week_index  = "Last"
              start_time  = "01:00"
              start_date  = "2025-01-15T00:00:00Z"
              not_allowed = []
            }
          ])
          automatic_upgrade_channel = optional(string, "patch")
          vm_size                   = optional(string, "Standard_D4d_v5")
          os_disk_type              = optional(string, "Ephemeral")
          auto_scaling_enabled      = optional(bool, true)
          min_count                 = optional(number, 1)
          max_count                 = optional(number, 3)
          max_surge                 = optional(string, "10%")
          priority                  = optional(string, null)
          spot_max_price            = optional(string, null)
          eviction_policy           = optional(string, null)
          node_taints               = optional(list(string), [])
          storage_class_file_share = optional(object({
            reclaim_policy = string
            }), {
            reclaim_policy = "Retain"
          })
          storage_class_disk_01 = optional(object({
            reclaim_policy      = string
            disk_sku_name       = string
            volume_binding_mode = string
            }), {
            reclaim_policy      = "Retain"
            disk_sku_name       = "StandardSSD_LRS"
            volume_binding_mode = "WaitForFirstConsumer"
          })
          storage_class_disk_02 = optional(object({
            reclaim_policy      = string
            disk_sku_name       = string
            volume_binding_mode = string
            }), {
            reclaim_policy      = "Retain"
            disk_sku_name       = "StandardSSD_ZRS"
            volume_binding_mode = "WaitForFirstConsumer"
          })
          keycloak = optional(object({
            shared_application = optional(object({
              private_link_id = optional(string, "/subscriptions/06990571-f710-403d-b219-b59325a657d6/resourceGroups/frc-rg-private-link-prd-01/providers/Microsoft.Network/privateLinkServices/frc-pl-keycloak-prd-01")
              subnet_key      = optional(string, "01-snet-front-private-endpoints-01")
              ip_configuration = optional(list(object({
                cidrhost_hostnum = number
                member_name      = optional(string, null)
                })), [
                {
                  cidrhost_hostnum = 31 // Take the IP address number "cidrhost_hostnum" of the current subnet
                }
              ])
            }), {})
          }), {})
        }))
        }),
        {
          np  = {}
          prd = {}
        }
      )
      private_cluster_enabled = optional(bool, true)
      network_profile = optional(object({
        network_plugin      = string
        network_data_plane  = string
        network_plugin_mode = string
        outbound_type       = string
        service_cidr        = string
        dns_service_ip      = string
        }),
        {
          network_plugin      = "azure"
          network_data_plane  = "cilium"
          network_plugin_mode = null
          outbound_type       = "userDefinedRouting"
          service_cidr        = "192.168.0.0/16"
          dns_service_ip      = "192.168.0.4"
        }
      )
      federated_identity_credential = optional(list(object({
        service_account_name      = string
        service_account_namespace = string
        })),
        [
          {
            service_account_name      = "secrets-store-csi-driver"
            service_account_namespace = "caas-system"
          },
          {
            service_account_name      = "traefik"
            service_account_namespace = "caas-system"
          },
          {
            service_account_name      = "external-dns"
            service_account_namespace = "caas-system"
          }
        ]
      )
      disk_access = optional(map(object({
        instance_name = string
        })),
        {
          "01" = {
            instance_name = "01"
          }
        }
      )
      service_mesh_profile = optional(list(object({
        mode = optional(string, "Istio")
        revisions = optional(list(string), [
          // Add here on list LEVEL ITEM 1 the target revision for upgrade process --> "asm-1-27"
          //"asm-1-27" Uncomment this line to launch the canary upgrade with this target version
          "asm-1-26",
        ])
        status    = optional(string, "enabled")
        mtls_mode = optional(string, "STRICT")
        })),
        [
          {
            mode = "Istio"
            revisions = [
              // Add here on list LEVEL ITEM 1 the target revision for upgrade process --> "asm-1-27"
              //"asm-1-27" Uncomment this line to launch the canary upgrade with this target version
              "asm-1-26",
            ]
            status    = "enabled"
            mtls_mode = "STRICT"
          }
        ]
      )
      key_vault_secrets_provider = optional(list(object({
        secret_rotation_enabled  = bool
        secret_rotation_interval = string
        })),
        [
          {
            secret_rotation_enabled  = true
            secret_rotation_interval = "2m"
          }
        ]
      )
      azure_active_directory_role_based_access_control = optional(list(object({
        admin_group_object_ids = list(string)
        azure_rbac_enabled     = optional(bool, true)
        })),
        [
          {
            admin_group_object_ids = [
              "5ffcc1c1-1bd9-4d28-8215-0feebff9f515"
            ]
          }
        ]
      )
      helm_release = optional(object({

        np = optional(object({
          replicas = optional(map(string))
          }),
          {
            replicas = {
              "traefik.deployment.replicas"     = "1"
              "argo-cd.controller.replicas"     = "1"
              "argo-cd.server.replicas"         = "1"
              "argo-cd.repoServer.replicas"     = "1"
              "argo-cd.applicationSet.replicas" = "1"
              "shield.cluster.replica_count"    = "1"
            }
          }
        )

        prd = optional(object({
          replicas = optional(map(string))
          }),
          {
            replicas = {
              "traefik.deployment.replicas"     = "2"
              "argo-cd.controller.replicas"     = "2"
              "argo-cd.server.replicas"         = "2"
              "argo-cd.repoServer.replicas"     = "2"
              "argo-cd.applicationSet.replicas" = "2"
              "shield.cluster.replica_count"    = "2"
            }
          }
        )

        psql-trading-secret = optional(object({
          namespace = optional(string, "caas-system")
        }))
        }),
        {
          psql-trading-secret = {}
        }
      )
      workbook = optional(list(string), ["AksLogs"])
      role_assignment = optional(map(object({
        role_definition_name = string
        principal_id         = string
        principal_type       = optional(string, null)
      })), {})
      log_analytics_workspace = optional(object({
        create                           = optional(bool, false)
        data_collection_rule_association = optional(bool, false)
      }), {})
    }), {})

    container_app = optional(object({
      create                        = optional(bool, false)
      required_resource_provider    = optional(list(string), ["Microsoft.App"])
      logs_destination              = optional(string, "log-analytics")
      container_app_environment_key = optional(string, "01")
      resource_group_key            = optional(string, "10")
      key_vault_key                 = optional(string, "01")
      acr_key                       = optional(string, "01")
      workload_profile_name         = optional(string, "Consumption")
      enable_auth_configs           = optional(bool, false)
      workload_profile = optional(list(object({
        name                  = optional(string)
        workload_profile_type = optional(string, "Consumption")
        minimum_count         = optional(number, 0)
        maximum_count         = optional(number, 0)
        })), [{}]
      )
      auth_configs = optional(map(object({
        name = string
        platform = optional(object({
          enabled         = optional(bool)
          runtime_version = optional(string)
        }))
        global_validation = optional(object({
          unauthenticated_client_action = optional(string)
          redirect_to_provider          = optional(string)
          exclude_paths                 = optional(list(string))
        }))
        identity_providers = optional(object({
          azure_active_directory = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              open_id_issuer                                     = optional(string)
              client_id                                          = optional(string)
              client_secret_setting_name                         = optional(string)
              client_secret_certificate_issuer                   = optional(string)
              client_secret_certificate_subject_alternative_name = optional(string)
              client_secret_certificate_thumbprint               = optional(string)
            }))
            login = optional(object({
              login_parameters         = list(string)
              disable_www_authenticate = bool
            }))
            validation = optional(object({
              jwt_claim_checks = optional(object({
                allowed_groups              = optional(list(string))
                allowed_client_applications = optional(list(string))
              }))
              allowed_audiences = optional(list(string))
              default_authorization_policy = optional(object({
                allowed_principals = optional(object({
                  groups     = optional(list(string))
                  identities = optional(list(string))
                }))
                allowed_applications = optional(list(string))
              }))
            }))
            is_auto_provisioned = optional(bool)
          }))
          facebook = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              app_id                  = optional(string)
              app_secret_setting_name = optional(string)
            }))
            graph_api_version = optional(string)
            login = optional(object({
              scopes = list(string)
            }))
          }))
          github = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              client_id                  = optional(string)
              client_secret_setting_name = optional(string)
            }))
            login = optional(object({
              scopes = list(string)
            }))
          }))
          google = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              client_id                  = optional(string)
              client_secret_setting_name = optional(string)
            }))
            login = optional(object({
              scopes = list(string)
            }))
            validation = optional(object({
              allowed_audiences = list(string)
            }))
          }))
          twitter = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              consumer_key                 = string
              consumer_secret_setting_name = optional(string)
            }))
          }))
          apple = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              client_id                  = string
              client_secret_setting_name = optional(string)
            }))
            login = optional(object({
              scopes = list(string)
            }))
          }))
          azure_static_web_apps = optional(object({
            enabled = optional(bool)
            registration = optional(object({
              client_id = string
            }))
          }))
          custom_open_id_connect_providers = optional(map(object({
            enabled = optional(bool)
            registration = optional(object({
              client_id = optional(string)
              client_credential = optional(object({
                method                     = string
                client_secret_setting_name = string
              }))
              open_id_connect_configuration = optional(object({
                authorization_endpoint           = string
                token_endpoint                   = string
                issuer                           = string
                certification_uri                = string
                well_known_open_id_configuration = optional(string)
              }))
            }))
            login = optional(object({
              name_claim_type = string
              scopes          = list(string)
            }))
          })), {})
        }))
        login = optional(object({
          routes = optional(object({
            logout_endpoint = string
          }))
          token_store = optional(object({
            enabled                       = bool
            token_refresh_extension_hours = number
            azure_blob_storage = optional(object({
              sas_url_setting_name = string
            }))
          }))
          preserve_url_fragments_for_logins = optional(bool)
          allowed_external_redirect_urls    = optional(list(string))
          cookie_expiration = optional(object({
            convention         = optional(string)
            time_to_expiration = optional(string)
          }))
          nonce = optional(object({
            validate_nonce            = bool
            nonce_expiration_interval = string
          }))
        }))
        http_settings = optional(object({
          require_https = optional(bool)
          forward_proxy = optional(object({
            convention               = optional(string)
            custom_host_header_name  = optional(string)
            custom_proto_header_name = optional(string)
          }))
          routes = optional(object({
            api_prefix = string
          }))
        }))
        encryption_settings = optional(object({
          container_app_auth_encryption_secret_name = optional(string)
          container_app_auth_signing_secret_name    = optional(string)
        }))
      })), {})
      np = optional(object({
        zone_redundancy_enabled = optional(bool, false)
      }), {})
      prd = optional(object({
        zone_redundancy_enabled = optional(bool, true)
      }), {})

    }), {})
  })
  default = {}
}

variable "container_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
    "10" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "container_aks" {
  description = "AKS Clusters specifications"
  type        = any
  default = {
    "01" = {
      instance_name = "01"
      private_endpoint = {
        current_disks = {
          alias            = "current"
          instance_name    = "01"
          disk_key         = "01"
          subresource_name = "disks"
          member_name      = "diskAccess_1"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 8 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared_services_kube_apiserver = {
          alias            = "shared-services"
          subresource_name = "management"
        }
      }
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "container_aks_node_pool" {
  description = "AKS Node pools."
  type = map(object({
    instance_name = optional(string, "02")
    mode          = optional(string, "User")
    min_count     = number
    vm_size       = optional(string, null)
    os_disk_type  = optional(string, null)
    node_taints   = optional(list(string), [])
  }))
  default = {
    "02" = {
      instance_name = "02"
      mode          = "User"
      min_count     = 0
    }
  }
}

variable "container_aks_workload_identity" {
  description = "Microsoft Entra Workload ID with Azure Kubernetes Service (AKS)"
  type = map(object({
    container_aks_key  = optional(string, "01")
    instance_name      = optional(string, "01")
    resource_group_key = optional(string, "01")
    namespace          = string
    application_name   = string
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    role_assignment = optional(map(object({
      role_definition_name       = string
      scope_id                   = optional(string)
      scope_acr_key              = optional(string)
      scope_data_collection_rule = optional(bool, false)
      scope_sa_key               = optional(string)
      scope_suffix               = optional(string, "")
    })), {})
  }))
  default = {}
}

variable "container_app_environment" {
  description = "Manages a Container App Environment. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_app_environment"
  type = map(object({
    workload_name                   = optional(string)
    instance_name                   = optional(string, "01")
    resource_group_key              = optional(string, "10")
    private_link_resource_group_key = optional(string, "01")
    subnet_key                      = optional(string, "01-snet-container-app-01")
    internal_load_balancer_enabled  = optional(bool, true)
    zone_redundancy_enabled         = optional(bool)
    application_insights_create     = optional(bool, false)
    workload_profile = optional(list(object({
      name                  = optional(string)
      workload_profile_type = optional(string, "Consumption")
      minimum_count         = optional(number, 0)
      maximum_count         = optional(number, 10)
      })),
      []
    )
    mutual_tls_enabled = optional(bool, true)
    private_endpoint = optional(map(object({
      alias               = string
      instance_name       = optional(string, "01")
      subresource_name    = optional(string, "managedEnvironments")
      region_code         = optional(string)
      location            = optional(string)
      resource_group_name = optional(string)
      subnet_key          = optional(string, "01-snet-front-private-endpoints-01")
      ip_configuration = optional(list(object({
        name               = optional(string)
        private_ip_address = optional(string)
        cidrhost_hostnum   = optional(number)
        member_name        = optional(string, "managedEnvironments")
        subresource_name   = optional(string, "managedEnvironments")
      })), [])
      })),
      {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 35 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias = "shared-services"
        }
      }
    )
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
    "01" = {}
  }
}

variable "container_app" {
  description = "Manages a Container App through the AVM module: https://registry.terraform.io/modules/Azure/avm-res-app-containerapp/azurerm/latest"
  type        = any
  default     = {}
}

##############################################
###### database area specifications
##############################################
variable "database_creation" {
  description = "Create the database platform"
  type        = bool
  default     = true
}

variable "database_default_specification" {
  description = "Database platform default specifications"
  type = object({
    private_endpoint = optional(object({
      resource_group_key = optional(string, "01")
    }), {})

    postgresql_flexible_server = optional(object({
      create            = optional(bool, true)
      auto_grow_enabled = optional(bool, true)
      version_db        = optional(number, 15)
      np = optional(object({
        sku        = optional(string, "B_Standard_B1ms")
        zone       = optional(string, null)
        storage_mb = optional(number, 65536)

        server_configuration = optional(map(object({
          name  = string
          value = string
        })), {})
        high_availability = optional(list(object({
          mode                      = optional(string, null)
          standby_availability_zone = optional(string, null)
        })), [])
      }), {})
      prd = optional(object({
        sku        = optional(string, "GP_Standard_D2s_v3")
        zone       = optional(string, "1")
        storage_mb = optional(number, 65536)

        server_configuration = optional(map(object({
          name  = string
          value = string
        })), {})
        high_availability = optional(list(object({
          mode                      = optional(string, "ZoneRedundant")
          standby_availability_zone = optional(string, null)
        })), [{}])
      }), {})
      aad_application = optional(object({
        key_vault_key = optional(string, "01")
        owners = optional(list(string), [
          "1be7ac54-bf01-4444-a014-5710361757d0", //sp-terraform-caf
          "523df6f1-6072-4ece-8124-a52040fefca3", // Lance Adrien (AO account) 
          "6ca1eec1-c066-46f2-9186-0066149a95da", // Dumont James (AO account)
          "0c89993c-8018-4d10-8507-812e6abd51ba", // Charrier Bastien (AO account)
          "b7ce3147-fad1-4fba-9e87-a7bb0a388319"  // Ganvet Dieuveil (AO account)
        ])
      }), {})
    }), {})

    mssql_server = optional(object({
      create        = optional(bool, false)
      key_vault_key = optional(string, "01")
      azuread_administrator = optional(object({
        login_username              = optional(string)
        object_id                   = optional(string)
        azuread_authentication_only = optional(bool, true)
      }), {})
      aad_application = optional(object({
        key_vault_key = optional(string, "01")
        owners = optional(list(string), [
          "1be7ac54-bf01-4444-a014-5710361757d0", //sp-terraform-caf
          "523df6f1-6072-4ece-8124-a52040fefca3", // Lance Adrien (AO account) 
          "6ca1eec1-c066-46f2-9186-0066149a95da", // Dumont James (AO account)
          "0c89993c-8018-4d10-8507-812e6abd51ba", // Charrier Bastien (AO account)
          "b7ce3147-fad1-4fba-9e87-a7bb0a388319"  // Ganvet Dieuveil (AO account)
        ])
      }), {})
    }), {})

    mysql_flexible_server = optional(object({
      create        = optional(bool, false)
      key_vault_key = optional(string, "01")
      np = optional(object({
        sku         = optional(string, "B_Standard_B1ms")
        zone        = optional(string, null)
        version     = optional(string, "8.4")
        create_mode = optional(string, "Default")
        high_availability = optional(list(object({
          mode                      = optional(string, "SameZone")
          standby_availability_zone = optional(string, null)
        })), [])
        server_configuration = optional(list(object({
          name  = optional(string)
          value = optional(string)
          })), [
          {
            name  = "require_secure_transport"
            value = "ON"
          }
        ])
        storage = optional(list(object({
          auto_grow_enabled  = optional(bool, null)
          io_scaling_enabled = optional(bool, null)
          iops               = optional(number, null)
          size_gb            = optional(number, null)
        })), [])
        customer_managed_key = optional(list(object({
          key_vault_key_id = optional(string)
        })), [])
      }), {})
      prd = optional(object({
        sku         = optional(string, "GP_Standard_D2ds_v4")
        zone        = optional(string, "1")
        version     = optional(string, "8.4")
        create_mode = optional(string, "Default")
        high_availability = optional(list(object({
          mode                      = optional(string, "ZoneRedundant")
          standby_availability_zone = optional(string, null)
        })), [])
        server_configuration = optional(list(object({
          name  = optional(string)
          value = optional(string)
          })), [
          {
            name  = "require_secure_transport"
            value = "ON"
          }
        ])
        storage = optional(list(object({
          auto_grow_enabled  = optional(bool, null)
          io_scaling_enabled = optional(bool, null)
          iops               = optional(number, null)
          size_gb            = optional(number, null)
        })), [])
        customer_managed_key = optional(list(object({
          key_vault_key_id = optional(string)
        })), [])
      }), {})
      aad_application = optional(object({
        key_vault_key = optional(string, "01")
        version       = optional(string, "v1")
        owners = optional(list(string), [
          "1be7ac54-bf01-4444-a014-5710361757d0", //sp-terraform-caf
          "523df6f1-6072-4ece-8124-a52040fefca3", // Lance Adrien (AO account) 
          "6ca1eec1-c066-46f2-9186-0066149a95da", // Dumont James (AO account)
          "0c89993c-8018-4d10-8507-812e6abd51ba", // Charrier Bastien (AO account)
          "b7ce3147-fad1-4fba-9e87-a7bb0a388319"  // Ganvet Dieuveil (AO account)
        ])
      }), {})
    }), {})

  })
  default = {}
}

variable "database_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    workload_name = optional(string, "database")
    location      = optional(string, null)
    tags          = optional(map(string), {})
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {
    "01" = {}
  }
}

variable "database_postgresql_flexible_server" {
  description = "PostgreSQL Flexible Servers specifications"
  type = map(object({
    instance_name             = optional(string, "01")
    resource_group_key        = optional(string, "01")
    region_code               = optional(string)
    keyvault_key              = optional(string, "01")
    backup_vault_key          = optional(string, "01")
    backup_policy_keys        = optional(list(string), ["amundi-01-postgresql-flexible"])
    workload_name             = optional(string)
    administrator_login       = optional(string, "adminpostgresql01")
    administrator_secret_name = optional(string, "psql-01-administrator")
    active_directory_administrator = optional(map(object({
      object_id      = string
      principal_name = string
      principal_type = string
      tenant_id      = optional(string, "a5c34232-eadc-4609-bff3-dd6fcdae3fe2")
      })), {
      "GSCO_CREW_DAT" = {
        object_id      = "5ffcc1c1-1bd9-4d28-8215-0feebff9f515"
        principal_name = "GSCO_CREW_DAT"
        principal_type = "Group"
      }
      "GSCO_CREW_DBA" = {
        object_id      = "587e52bb-0071-47ad-9269-78398487eaa1"
        principal_name = "GSCO_CREW_DBA"
        principal_type = "Group"
      }
      "sp-dbsqware-amt" = {
        object_id      = "dbba476f-c33d-47d7-9349-456e10b7ed2a"
        principal_name = "sp-dbsqware-amt"
        principal_type = "ServicePrincipal"
      }
    })
    aad_application = optional(object({
      owners = optional(list(string))
      secret = optional(object({
        name    = optional(string, "sp-flexible-server-admin")
        version = optional(string, "v1")
      }), {})
    }), {})
    auto_grow_enabled = optional(string)
    storage_mb        = optional(string)
    sku               = optional(string)
    version_db        = optional(string)
    zone              = optional(string)
    high_availability = optional(list(object({
      mode                      = optional(string, null)
      standby_availability_zone = optional(string, null)
    })), [])
    database = optional(map(object({
      name = string
      })),
      {
        "01" = {
          name = "alto_trading"
        }
      }
    )
    server_configuration = optional(map(object({
      name  = string
      value = string
      })), {
      "max_connections" = {
        name  = "max_connections"
        value = "100"
      }
    })
    private_endpoint = optional(map(object({
      alias               = string
      instance_name       = optional(string, "01")
      region_code         = optional(string)
      location            = optional(string)
      resource_group_name = optional(string)
      subnet_key          = optional(string, "01-snet-back-private-endpoints-01")
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = optional(string, null)
      })), [])
      })),
      {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 9 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias = "shared-services"
        }
      }
    )
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
    "01" = {
    }
  }
}

variable "database_mssql_server" {
  description = "Microsoft SQL Azure Database Server"
  type = map(object({
    instance_name                = optional(string, "01")
    workload_name                = optional(string)
    region_code                  = optional(string)
    resource_group_key           = optional(string, "01")
    key_vault_key                = optional(string)
    sql_migration_service_create = optional(bool, false)
    sku_name                     = optional(string, "S0") //The sku name of the Azure Analysis Services server to create. Choose from: B1, B2, D1, S0, S1, S2, S3, S4, S8, S9. Some skus are region specific. See https://docs.microsoft.com/en-us/azure/analysis-services/analysis-services-overview#availability-by-region"
    private_endpoint             = any
    azuread_administrator = optional(object({
      login_username              = optional(string)
      object_id                   = optional(string)
      azuread_authentication_only = optional(bool)
    }), {})
    aad_application = optional(any, {})
    secret = optional(object({
      name    = optional(string, "sp-mssql-server-admin")
      version = optional(string, "v1")
    }), {})
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
    "01" = {
      instance_name = "01"
      private_endpoint = {

        current_sqlServer = {
          alias            = "current"
          subresource_name = "sqlServer"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 21 // Take the IP address number "cidrhost_hostnum" of the current subnet
              member_name      = "sqlServer"
            }
          ]
        }

        shared-services_sqlServer = {
          alias            = "shared-services"
          subresource_name = "sqlServer"
        }
      }

      tags = {
        description = "Azure SQL Database"
        ops_team    = "g-x-admin-azure",
        it_owner    = "g-x-admin-azure"
      }
    }
  }
}

variable "database_mssql_database" {
  description = "Map of SQL servers to create"
  type = map(object({
    name                 = string
    mssql_server_key     = optional(string, "01")
    key_vault_key        = optional(string)
    collation            = optional(string)
    license_type         = optional(string)
    max_size_gb          = optional(number)
    read_scale           = optional(bool)
    sku_name             = optional(string)
    zone_redundant       = optional(bool)
    storage_account_type = optional(string)
    enclave_type         = optional(string)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    identity = optional(object({
      type        = optional(string, "UserAssigned")
      identity_id = optional(string)
    }), {})
  }))
  default = {
    "01" = {
      name = "invest"
    }
  }
}

variable "database_mysql_flexible_servers" {
  description = "MySQL Flexible Servers specifications"
  type = map(object({
    instance_name             = optional(string, "01")
    resource_group_key        = optional(string, "01")
    workload_name             = optional(string)
    keyvault_key              = optional(string)
    administrator_login       = optional(string, "adminmysqlflex01")
    administrator_secret_name = optional(string, "mysql-01-administrator")
    public_network_access     = optional(string, "Disabled")
    aad_application = optional(object({
      key_vault_key = optional(string, "01")
      version       = optional(string, "v1")
      owners = optional(list(string), [
        "1be7ac54-bf01-4444-a014-5710361757d0" //sp-terraform-caf
      ])
    }), {})
    active_directory_administrator = optional(map(object({
      login     = optional(string)
      object_id = string
      tenant_id = optional(string, "a5c34232-eadc-4609-bff3-dd6fcdae3fe2")
      })), {
      "GSCO_CREW_AZURE_MYSQL_ADMIN" = {
        object_id = "2a8467a4-44f3-49e3-85cb-d68377354d14"
      }
    })
    server_configuration = optional(list(object({
      name  = optional(string)
      value = optional(string)
    })), [])
    create_mode = optional(string)
    version     = optional(string)
    sku_name    = optional(string)
    database = optional(map(object({
      name      = string
      charset   = optional(string, "utf8")
      collation = optional(string, "utf8_unicode_ci")
      })),
      {}
    )
    delegated_subnet_id = optional(string)
    private_dns_zone_id = optional(string)
    zone                = optional(string)
    high_availability = optional(list(object({
      mode                      = optional(string, "SameZone")
      standby_availability_zone = optional(string, null)
    })), [])
    storage = optional(list(object({
      auto_grow_enabled  = optional(bool, null)
      io_scaling_enabled = optional(bool, null)
      iops               = optional(number, null)
      size_gb            = optional(number, null)
    })), [])
    private_endpoint = optional(map(object({
      alias               = string
      instance_name       = optional(string, "01")
      region_code         = optional(string)
      subresource_name    = optional(string)
      location            = optional(string)
      resource_group_name = optional(string)
      subnet_key          = optional(string, "01-snet-back-private-endpoints-01")
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = optional(string, null)
      })), [])
      })),
      {
        current = {
          alias            = "current"
          subresource_name = "mysqlServer"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 13 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services = {
          alias            = "shared-services"
          subresource_name = "mysqlServer"

        }
      }
    )
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
    "01" = {}
  }
}

variable "database_user_assigned_identity" {
  description = "Database User Assigned Identity specifications"
  type = map(object({
    workload_name      = optional(string)
    instance_name      = optional(string, "01")
    resource_group_key = optional(string, "01")
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {}
}

##############################################
###### virtual desktop area specifications
##############################################
variable "virtual_desktop_creation" {
  description = "Create a Virtual Desktop area"
  type        = bool
  default     = false
}

variable "virtual_desktop_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "virtual_desktop_default_specification" {
  description = "Virtual Desktop default specifications"
  type        = any
  default = {
    tags = {
      description = "virtual desktop"
      ops_team    = "g-x-admin-azure",
      it_owner    = "g-x-admin-azure"
    }
  }
}

variable "virtual_desktop" {
  description = "Virtual Desktop specifications"
  type        = any
  default = {
    "01" = {
      host_pool = {
        "01" = {
          type                             = "Personal"
          load_balancer_type               = "BreadthFirst"
          personal_desktop_assignment_type = "Automatic"
        }
      }
    }
  }
}

##############################################
###### azure devops area specifications
##############################################
variable "ADO_ARM_CLIENT_ID" {
  type        = string
  description = "Client id of the service principal that will connect to Azure DevOps"
}

variable "ADO_ARM_CLIENT_SECRET" {
  description = "Client secret of the service principal that will connect to Azure DevOps"
  type        = string
}

variable "ADO_SYNC_REPO_USERNAME" {
  type        = string
  description = "Azure DevOps username used to sync repos"
}

variable "ADO_SYNC_REPO_PAT" {
  description = "Azure DevOps PAT used to sync repos"
  type        = string
}

variable "azure_devops_creation" {
  description = "Create a Azure DevOps area"
  type        = bool
  default     = true
}

variable "azure_devops_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "azure_devops_default_specification" {
  description = "Azure DevOps default specifications"
  type = object({
    resource_group_key = optional(string, "01")
    org_service_url    = optional(string, "https://dev.azure.com/amundi-technology")
    work_item_template = optional(string, "Agile")
    features = optional(map(string), {
      "boards"       = "disabled"
      "repositories" = "enabled"
      "pipelines"    = "disabled"
      "testplans"    = "disabled"
      "artifacts"    = "disabled"
    })
    aad_application = optional(object({
      key_vault_key = optional(string, "01")
      owners        = optional(list(string), ["1be7ac54-bf01-4444-a014-5710361757d0"]) // sp-terraform-caf
      }),
      {
        key_vault_key = "01"
      }
    )
    devops_agent_create = optional(bool, false)
    devops_agent = optional(object({
      image_name = optional(string, "amundi/azp-agent-linux:2025.10.07")
      self_hosted_agent_enrolment = optional(object({
        client_id                 = optional(string, "db76ccbf-0074-4c52-8020-b7845a6d4603")
        client_secret_key         = optional(string, "sp-azure-devops-self-hosted-agent-01-secret")
        container_app_secret_name = optional(string, "sp-azure-devops-self-hosted-agent-01-secret")
      }), {})
      compute_types = optional(list(string), [
        "azure_container_instance",
        "azure_container_app",
      ])
      container_instance_count = optional(number, 0) //Set to zero, prefer using Azure Container App has it can scale from 0
    }), {})
    amundi_products = optional(object({
      template_files_modification_ignored = optional(list(string), ["application.yaml", "config.yaml", "secret.yaml"])

      alto-invest = optional(object({
        namespaces = list(string)
        source_url = string
        dependencies = map(object({
          helm_repo_suffix = optional(string, "apps")
        }))
        git_repository_file_amundi_products = map(object({
          all_files_modification_ignored = optional(bool, false)
          repository_key                 = optional(string)
          prefix_file_path               = optional(string, null)
          file                           = optional(string, null)
          content                        = optional(string)
          template_file_path             = optional(string, null)
          template_values = optional(object({
            container_repo_suffix = optional(string, "container/amundi/platform/")
            additional_dependencies = optional(map(object({
              helm_repo_suffix = optional(string, "apps")
            })), {})
            enablers = optional(list(string), [])
          }), {})
        }))
        }),
        {
          namespaces = ["shared", "platform"]
          source_url = "https://amundi-technology@dev.azure.com/amundi-technology/frc-shared-services-prd-01/_git/alto-invest"
          dependencies = {
            "cache-api"            = {}
            "cache-console"        = {}
            "component-manager"    = {}
            "maestro-server"       = {}
            "maestro-admin-server" = {}
            "maestro-admin-front"  = {}
            "family-services"      = {}
            "family-generator"     = {}
            "ext-api"              = {}
            "bff-api"              = {}
            "license-diffuser"     = {}
            "keycloak" = {
              helm_repo_suffix = "vendors"
            }
            "keycloak-operator" = {
              helm_repo_suffix = "vendors"
            }
            "redis" = {
              helm_repo_suffix = "vendors"
            }
          }
          git_repository_file_amundi_products = {
            #Keys must respect the following convention --> <Template FileName>/<Product Name> or <Template FileName>/<Depedency>/<Product Name>

            "Chart/alto-invest" = {
              prefix_file_path   = "argocd-manifest"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-argocd-manifest.yaml.tftpl"
            }

            "values/alto-invest" = {
              prefix_file_path   = "argocd-manifest"
              file               = "values.yaml"
              template_file_path = "/template-files/values-argocd-manifest.yaml.tftpl"
            }

            "Chart/cache-api/alto-invest" = {
              prefix_file_path   = "applications/cache-api"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/cache-api/alto-invest" = {
              prefix_file_path   = "applications/cache-api"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/cache-console/alto-invest" = {
              prefix_file_path   = "applications/cache-console"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/cache-console/alto-invest" = {
              prefix_file_path   = "applications/cache-console"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/component-manager/alto-invest" = {
              prefix_file_path   = "applications/component-manager"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/component-manager/alto-invest" = {
              prefix_file_path   = "applications/component-manager"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/maestro-server/alto-invest" = {
              prefix_file_path   = "applications/maestro-server"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/maestro-server/alto-invest" = {
              prefix_file_path   = "applications/maestro-server"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/maestro-admin-server/alto-invest" = {
              prefix_file_path   = "applications/maestro-admin-server"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/maestro-admin-server/alto-invest" = {
              prefix_file_path   = "applications/maestro-admin-server"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/maestro-admin-front/alto-invest" = {
              prefix_file_path   = "applications/maestro-admin-front"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/maestro-admin-front/alto-invest" = {
              prefix_file_path   = "applications/maestro-admin-front"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/family-services/alto-invest" = {
              prefix_file_path   = "applications/family-services"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/family-services/alto-invest" = {
              prefix_file_path   = "applications/family-services"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/family-generator/alto-invest" = {
              prefix_file_path   = "applications/family-generator"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/family-generator/alto-invest" = {
              prefix_file_path   = "applications/family-generator"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/ext-api/alto-invest" = {
              prefix_file_path   = "applications/ext-api"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/ext-api/alto-invest" = {
              prefix_file_path   = "applications/ext-api"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/bff-api/alto-invest" = {
              prefix_file_path   = "applications/bff-api"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/bff-api/alto-invest" = {
              prefix_file_path   = "applications/bff-api"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/license-diffuser/alto-invest" = {
              prefix_file_path   = "applications/license-diffuser"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/license-diffuser/alto-invest" = {
              prefix_file_path   = "applications/license-diffuser"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/"
              }
            }

            "Chart/keycloak/alto-invest" = {
              prefix_file_path   = "applications/keycloak"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/keycloak/alto-invest" = {
              prefix_file_path   = "applications/keycloak"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/sso/keycloak/keycloak"
              }
            }

            "Chart/keycloak-operator/alto-invest" = {
              prefix_file_path   = "applications/keycloak-operator"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/keycloak-operator/alto-invest" = {
              prefix_file_path   = "applications/keycloak-operator"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/keycloak"
              }
            }
            "Chart/redis/alto-invest" = {
              prefix_file_path   = "applications/redis"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/redis/alto-invest" = {
              prefix_file_path   = "applications/redis"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/bitnami/"
              }
            }
          }
        }
      )
      alto-asset-servicing = optional(object({
        namespaces = list(string)
        source_url = string
        dependencies = map(object({
          helm_repo_suffix = optional(string, "apps")
        }))
        git_repository_file_amundi_products = map(object({
          all_files_modification_ignored = optional(bool, true)
          repository_key                 = optional(string)
          prefix_file_path               = optional(string, null)
          file                           = optional(string, null)
          content                        = optional(string)
          template_file_path             = optional(string, null)
          template_values = optional(object({
            container_repo_suffix = optional(string, "container/amundi/risk/")
            additional_dependencies = optional(map(object({
              helm_repo_suffix = optional(string, "apps")
            })), {})
            enablers = optional(list(string), [])
          }), {})
        }))
        }),
        {
          namespaces = ["shared", "platform", "risk", "monitoring", "mongodb"]
          source_url = "https://dev.azure.com/amundi-technology/frc-shared-services-prd-01/_git/alto-asset-servicing"
          dependencies = {
            "nginx-gateway-iis"        = {}
            "cache-console"            = {}
            "alto-cache"               = {}
            "cache-api"                = {}
            "rule-engine"              = {}
            "component-manager"        = {}
            "contextual-proof-engine"  = {}
            "investment-compliance-cs" = {}
            "investment-compliance"    = {}
            "middleware-mock"          = {}
            "kube-prometheus-stack" = {
              helm_repo_suffix = "vendors"
            }
            "keda" = {
              helm_repo_suffix = "vendors"
            }
            "mongodb" = {
              helm_repo_suffix = "vendors"
            }
            "spring-boot-admin" = {
              helm_repo_suffix = "vendors"
            }
            "xvfb-server" = {
              helm_repo_suffix = "vendors"
            }
            "redis" = {
              helm_repo_suffix = "vendors"
            }
          }
          git_repository_file_amundi_products = {
            #Keys must respect the following convention --> <Template FileName>/<Product Name> or <Template FileName>/<Depedency>/<Product Name>

            "Chart/alto-asset-servicing" = {
              prefix_file_path   = "argocd-manifest"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-argocd-manifest.yaml.tftpl"
            }

            "values/alto-asset-servicing" = {
              prefix_file_path   = "argocd-manifest"
              file               = "values.yaml"
              template_file_path = "/template-files/values-argocd-manifest.yaml.tftpl"
            }

            "Chart/nginx-gateway-iis/alto-asset-servicing" = {
              prefix_file_path   = "applications/nginx-gateway-iis"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/nginx-gateway-iis/alto-asset-servicing" = {
              prefix_file_path   = "applications/nginx-gateway-iis"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/cache-console/alto-asset-servicing" = {
              prefix_file_path   = "applications/cache-console"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/cache-console/alto-asset-servicing" = {
              prefix_file_path   = "applications/cache-console"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/cache-api/alto-asset-servicing" = {
              prefix_file_path   = "applications/cache-api"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/cache-api/alto-asset-servicing" = {
              prefix_file_path   = "applications/cache-api"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/alto-reporting/alto-asset-servicing" = {
              prefix_file_path   = "applications/alto-reporting"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/alto-reporting/alto-asset-servicing" = {
              prefix_file_path   = "applications/alto-reporting"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/rule-engine/alto-asset-servicing" = {
              prefix_file_path   = "applications/rule-engine"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/rule-engine/alto-asset-servicing" = {
              prefix_file_path   = "applications/rule-engine"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/component-manager/alto-asset-servicing" = {
              prefix_file_path   = "applications/component-manager"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/component-manager/alto-asset-servicing" = {
              prefix_file_path   = "applications/component-manager"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/contextual-proof-engine/alto-asset-servicing" = {
              prefix_file_path   = "applications/contextual-proof-engine"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/contextual-proof-engine/alto-asset-servicing" = {
              prefix_file_path   = "applications/contextual-proof-engine"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/investment-compliance-cs/alto-asset-servicing" = {
              prefix_file_path   = "applications/investment-compliance-cs"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/investment-compliance-cs/alto-asset-servicing" = {
              prefix_file_path   = "applications/investment-compliance-cs"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/investment-compliance/alto-asset-servicing" = {
              prefix_file_path   = "applications/investment-compliance"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/investment-compliance/alto-asset-servicing" = {
              prefix_file_path   = "applications/investment-compliance"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/middleware-mock/alto-asset-servicing" = {
              prefix_file_path   = "applications/middleware-mock"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/middleware-mock/alto-asset-servicing" = {
              prefix_file_path   = "applications/middleware-mock"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/kube-prometheus-stack/alto-asset-servicing" = {
              prefix_file_path   = "applications/kube-prometheus-stack"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/kube-prometheus-stack/alto-asset-servicing" = {
              prefix_file_path   = "applications/kube-prometheus-stack"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/keda/alto-asset-servicing" = {
              prefix_file_path   = "applications/keda"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/keda/alto-asset-servicing" = {
              prefix_file_path   = "applications/keda"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/"
              }
            }

            "Chart/mongodb/alto-asset-servicing" = {
              prefix_file_path   = "applications/mongodb"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/mongodb/alto-asset-servicing" = {
              prefix_file_path   = "applications/mongodb"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/"
              }
            }

            "Chart/spring-boot-admin/alto-asset-servicing" = {
              prefix_file_path   = "applications/spring-boot-admin"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/spring-boot-admin/alto-asset-servicing" = {
              prefix_file_path   = "applications/spring-boot-admin"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/"
              }
            }
            "Chart/redis/alto-asset-servicing" = {
              prefix_file_path   = "applications/redis"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/redis/alto-asset-servicing" = {
              prefix_file_path   = "applications/redis"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/bitnami/"
              }
            }
            "Chart/xvfb-server/alto-asset-servicing" = {
              prefix_file_path   = "applications/xvfb-server"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/xvfb-server/alto-asset-servicing" = {
              prefix_file_path   = "applications/xvfb-server"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
              template_values = {
                container_repo_suffix = "container/vendors/"
              }
            }
          }
        }
      )
      authentication = optional(object({
        namespaces = list(string)
        source_url = string
        dependencies = map(object({
          helm_repo_suffix = optional(string, "apps")
        }))
        git_repository_file_amundi_products = map(object({
          all_files_modification_ignored = optional(bool, true)
          repository_key                 = optional(string)
          prefix_file_path               = optional(string, null)
          file                           = optional(string, null)
          content                        = optional(string)
          template_file_path             = optional(string, null)
          template_values = optional(object({
            container_repo_suffix = optional(string, "container/amundi/keycloak/")
            additional_dependencies = optional(map(object({
              helm_repo_suffix = optional(string, "apps")
            })), {})
            enablers = optional(list(string), [])
          }), {})
        }))
        }),
        {
          namespaces = ["keycloak-operator", "sso-apps", "sso-infra"]
          source_url = "https://dev.azure.com/amundi-technology/frc-shared-services-prd-01/_git/authentication"
          dependencies = {
            "keycloak" = {
              helm_repo_suffix = "vendors"
            }
            "keycloak-operator" = {
              helm_repo_suffix = "vendors"
            }
          }
          git_repository_file_amundi_products = {
            #Keys must respect the following convention --> <Template FileName>/<Product Name> or <Template FileName>/<Depedency>/<Product Name>

            "Chart/authentication" = {
              prefix_file_path   = "argocd-manifest"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-argocd-manifest.yaml.tftpl"
            }

            "values/authentication" = {
              prefix_file_path   = "argocd-manifest"
              file               = "values.yaml"
              template_file_path = "/template-files/values-argocd-manifest.yaml.tftpl"
            }

            "Chart/keycloak-apps/authentication" = {
              prefix_file_path   = "applications/keycloak-apps"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/keycloak-apps/authentication" = {
              prefix_file_path   = "applications/keycloak-apps"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/keycloak-infra/authentication" = {
              prefix_file_path   = "applications/keycloak-infra"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/keycloak-infra/authentication" = {
              prefix_file_path   = "applications/keycloak-infra"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }

            "Chart/keycloak-operator/authentication" = {
              prefix_file_path   = "applications/keycloak-operator"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/keycloak-operator/authentication" = {
              prefix_file_path   = "applications/keycloak-operator"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            }
          }
        }
      )
      argo-lza = optional(object({
        namespaces = list(string)
        source_url = string
        dependencies = map(object({
          helm_repo_suffix = optional(string, "apps")
        }))
        git_repository_file_amundi_products = map(object({
          all_files_modification_ignored = optional(bool, true)
          repository_key                 = optional(string)
          prefix_file_path               = optional(string, null)
          file                           = optional(string, null)
          content                        = optional(string)
          template_file_path             = optional(string, null)
          template_values = optional(object({
            container_repo_suffix = optional(string, "container/amundi/platform/")
            additional_dependencies = optional(map(object({
              helm_repo_suffix = optional(string, "apps")
            })), {})
            enablers = optional(list(string), [])
          }), {})
        }))
        }),
        {
          namespaces = []
          source_url = "https://dev.azure.com/amundi-technology/frc-shared-services-prd-01/_git/argo-lza"
          dependencies = {
            //"sample" = {}
          }
          git_repository_file_amundi_products = {
            #Keys must respect the following convention --> <Template FileName>/<Product Name> or <Template FileName>/<Depedency>/<Product Name>

            "Chart/argo-lza" = {
              prefix_file_path   = "argocd-manifest"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-argocd-manifest.yaml.tftpl"
            }

            "values/argo-lza" = {
              prefix_file_path   = "argocd-manifest"
              file               = "values.yaml"
              template_file_path = "/template-files/values-argocd-manifest.yaml.tftpl"
            }
            /* Sample -->
            "Chart/sample/argo-lza" = {
              prefix_file_path   = "applications/sample"
              file               = "Chart.yaml"
              template_file_path = "/template-files/Chart-applications.yaml.tftpl"
            }

            "application/sample/argo-lza" = {
              prefix_file_path   = "applications/sample"
              file               = "application.yaml"
              template_file_path = "/template-files/application.yaml.tftpl"
            } */
          }
        }
      )
      sgss = optional(any)
    }), {})
    required_resource_provider = optional(map(object({
      resource_provider = string
      })),
      {
        dev_center = {
          resource_provider = "Microsoft.App"
        }
      }
    )
  })
  default = {}
}

variable "azure_devops" {
  description = "Azure DevOps specifications"
  type = map(object({
    region_code       = optional(string)
    keyvault_key      = optional(string, "01")
    acr_key           = optional(string, "01")
    container_aks_key = optional(string, "01") //Container aks key containing the argo cd account that will have privilege on this Azure DevOps project(s)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
      }
    )

    devops_project = optional(map(object({
      instance_name      = optional(string)
      workload_name      = optional(string)
      aad_application    = map(any)
      work_item_template = optional(string, "Agile")
      features = optional(map(string), {
        "boards"       = "disabled"
        "repositories" = "enabled"
        "pipelines"    = "disabled"
        "testplans"    = "disabled"
        "artifacts"    = "disabled"
      })
      variable_group = optional(map(object({
        name         = string
        description  = string
        allow_access = optional(bool, true)
        variable = optional(map(object({
          name         = string
          secret_value = optional(string)
          secret_key   = optional(string)
        })), {})
        })), {
        "01" = {
          name        = "common_variables"
          description = "Don't update this variable its managed by DAT through Terraform"
          variable = {
            "01" = {
              name       = "MAPPED_ADO_PAT"
              secret_key = "svc-dat-azuredev-security-scan"
            }
          }
        }
      })
      })), {
      "01" = {
        aad_application = {}
        features = {
          "boards"       = "disabled"
          "repositories" = "enabled"
          "pipelines"    = "disabled"
          "testplans"    = "disabled"
          "artifacts"    = "disabled"
        }
      }
    })

    git_repository = optional(map(object({
      init = optional(map(any))
      })),
      {
        //init = {}
      }
    )

    amundi_products = optional(list(string), [])

    git_repository_file = optional(map(object({
      repository_key     = string
      file               = string
      content            = string
      template_file_path = optional(string, null)
      template_values    = optional(any)
      })),
      {
        /*        "dev" = {
          repository_key = "init"
          file           = "dev.yaml"
          content        = <<-EOT
name: dev
EOT
        }
        "prd" = {
          repository_key = "init"
          file           = "prd.yaml"
          content        = <<-EOT
name: prd
EOT
        } */
      }
    )

    group_membership = map(object({
      devops_project_key           = optional(string, "01")
      workload_name                = optional(string)
      group_name                   = optional(string, "default Team")
      entra_id_user_member         = optional(list(string), [])
      entra_id_user_member_default = optional(list(string), [])
      entra_id_group_member        = optional(list(string), [])
      entra_id_group_member_default = optional(list(string), [
        "ed1ff691-798d-400c-9a4d-484e42f1793c", //GSCO_CREW_Security
        "2f4d72a5-1124-4cc3-82e1-f4efeee16447"  //GSCO_CREW_CICD_AZURE_DEVOPS_ADMIN

      ])
      entra_id_service_principal_member = optional(list(string), [])
      members                           = optional(list(string), []) // !!! Assign manualy a Basic licence if using this option
    }))
  }))
  default = {
    "01" = {
      group_membership = {
        "01" = {}
      }
    }
  }
}

variable "azure_devops_agent_pool" {
  description = "Map of Azure DevOps agent pool to create"
  type = map(object({
    project_key    = optional(string, "01")
    region_code    = optional(string)
    workload_name  = optional(string)
    instance_name  = optional(string, "01")
    auto_provision = optional(bool, false)
    auto_update    = optional(bool, true)
    securityrole_assignment = optional(map(object({
      role_name    = string
      display_name = string
      })), {
      /*
It not supported yet to grant admin privilege at the agent pool organisation level, see https://github.com/microsoft/terraform-provider-azuredevops/issues/910#issuecomment-3252886225
      "sp-azure-devops-self-hosted-agent-01" = {
        role_name    = "Administrator"
        display_name = "sp-azure-devops-self-hosted-agent-01"
      }
      */
    })
    virtual_network_key           = optional(string, "01")
    container_app_subnet_key      = optional(string, "01-snet-container-app-devops-01")
    container_instance_subnet_key = optional(string, "01-snet-container-instance-devops-01")
    container_app_replica_timeout = optional(number, 1800)
    tags                          = optional(map(string))
  }))
  default = {
    "01" = {}
  }
}

variable "azure_devops_group" {
  description = "Map of Azure DevOps group"
  type = map(object({
    scope_organization        = optional(bool, false)
    project_key               = optional(string, "01")
    environment               = optional(list(string), ["prd"])
    display_name              = optional(string)
    display_name_group_prefix = optional(bool, true)
    description               = optional(string, "Complete group description: https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy")
    account_license_type      = optional(string)
  }))
  default = {
    "AZURE_DEVOPS_DEVELOPERS" = {
      display_name         = "AZURE_DEVOPS_DEVELOPERS"
      description          = "Azure DevOps Developers - Cf https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy"
      account_license_type = "express"
    }
    "AZURE_DEVOPS_CODE_REVIEWERS" = {
      display_name         = "AZURE_DEVOPS_CODE_REVIEWERS"
      description          = "Azure DevOps Code reviewers - Cf https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy"
      account_license_type = "express"
    }
    "AZURE_DEVOPS_SCRUM_MASTERS" = {
      display_name         = "AZURE_DEVOPS_SCRUM_MASTERS"
      description          = "Azure Devops Scrum managment - Cf https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy"
      account_license_type = "stakeholder"
    }
    "AZURE_DEVOPS_TEAM_LEADS" = {
      display_name         = "AZURE_DEVOPS_TEAM_LEADS"
      description          = "Azure DevOps Team leads - Cf https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy"
      account_license_type = "express"
    }
    "AZURE_DEVOPS_READERS" = {
      display_name         = "AZURE_DEVOPS_READERS"
      description          = "Read board tickets - Cf https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy"
      account_license_type = "stakeholder"
    }
    "AZURE_DEVOPS_TEST_USERS" = {
      display_name         = "AZURE_DEVOPS_TEST_USERS"
      description          = "Read board tickets/ update status on Test cases - Cf https://confluence.intramundi.com/display/ITSPCI/RBAC+Strategy"
      account_license_type = "stakeholder"
    }
  }
}

##############################################
###### Microsoft 365 area specifications
##############################################
variable "microsoft_365_creation" {
  description = "Create the Microsoft 365 area"
  type        = bool
  default     = false
}

variable "microsoft_365_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "power-bi-online-01" = {
      workload_name = "power-bi-online"
      tags = {
        owner    = "louisdavid.feral@amundi.com"
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
    "sharepoint-online-01" = {
      workload_name = "sharepoint-online"
      tags = {
        owner    = "louisdavid.feral@amundi.com"
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
    "teams-01" = {
      workload_name = "teams"
      tags = {
        owner    = "christophe.bailly@amundi.com"
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "microsoft_365_default_specification" {
  description = "Microsoft 365 default specifications"
  type        = any
  default = {
    powerbi_embedded = {
      mode     = "Gen2"
      sku_name = "A1"
    }
    microsoft_365 = {
      sku = [{
        name = "F2"
        tier = "Fabric"
      }]
    }
    bot_service_azure_bot = {
      sku = "F0"
    }
  }
}

variable "microsoft_365_powerbi_embedded" {
  description = "Manages a PowerBI Embedded. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/powerbi_embedded"
  type        = any
  default     = {}
}

variable "microsoft_365_fabric_capacity" {
  description = "Manages a Fabric Capacity. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/fabric_capacity"
  type        = any
  default     = {}
}

variable "microsoft_365_bot_service_azure_bot" {
  description = "Azure Bot Service. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/bot_service_azure_bot"
  type = map(object({
    workload_name                         = string
    resource_group_key                    = string
    instance_name                         = string
    microsoft_app_id                      = string
    location                              = optional(string, null)
    sku                                   = optional(string, null)
    developer_app_insights_api_key        = optional(string, null)
    developer_app_insights_application_id = optional(string, null)
    developer_app_insights_key            = optional(string, null)
    display_name                          = optional(string, null)
    endpoint                              = optional(string, null)
    icon_url                              = optional(string, null)
    microsoft_app_msi_id                  = optional(string, null)
    cmk_key_vault_key_url                 = optional(string, null)
    microsoft_app_tenant_id               = optional(string, null)
    microsoft_app_type                    = optional(string, null)
    local_authentication_enabled          = optional(string, false)
    luis_app_ids                          = optional(list(string), [])
    luis_key                              = optional(string, null)
    public_network_access_enabled         = optional(string, false)
    streaming_endpoint_enabled            = optional(string, null)
    tags                                  = optional(map(string), {})
    ms_teams = optional(map(object({
      bot_name               = optional(string, null)
      location               = optional(string, null)
      resource_group_name    = optional(string, null)
      calling_web_hook       = optional(string, null)
      deployment_environment = optional(string, null)
      enable_calling         = optional(string, null)
    })), {})
  }))
  default = {}
}

##############################################
###### Machine Learning area specifications
##############################################
variable "machine_learning_creation" {
  description = "Create the Machine Learning area"
  type        = bool
  default     = false
}

variable "machine_learning_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    location      = optional(string, null)
    tags = optional(map(string), {
      description = "AI + machine learning"
      ops_team    = "g-x-admin-azure",
      it_owner    = "g-x-admin-azure"
      }
    )
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {
    "01" = {}
  }
}

variable "machine_learning_default_specification" {
  description = "Machine Learning default specifications"
  type = object({
    resource_group_key         = optional(string, "01")
    key_vault_key              = optional(string, "01")
    key_vault_key_key          = optional(string, "machine_learning_01")
    container_registry_key     = optional(string, "01")
    storage_account_key        = optional(string, "machine_learning_01")
    required_resource_provider = optional(list(string), ["Microsoft.MachineLearningServices", "Microsoft.CognitiveServices"])
    region_shared_services     = optional(string, null) //Only use this variable if the shared services is different than the Azure region for Machine Learning services
    hub_storage_account = optional(map(object({
      instance_name      = optional(string, "01")
      workload_name      = optional(string, null)
      resource_group_key = optional(string, "01")
      storage_account = optional(object(
        {
          instance_name      = optional(string, "01")
          workload_name      = optional(string, null)
          resource_group_key = optional(string, "01")
          location           = optional(string)
          key_vault_key      = optional(string)
          key_vault_key_key  = optional(string)
          tags = optional(map(string), {
            description = "azure machine learning"
            ops_team    = "g-x-admin-azure",
            it_owner    = "g-x-admin-azure"
          })
          account_tier             = optional(string, "Standard")
          account_kind             = optional(string, "StorageV2")
          is_hns_enabled           = optional(bool, false)
          account_replication_type = optional(string, "ZRS")
          role_assignment          = optional(any, {})
          share                    = optional(any, {})
          allowed_copy_scope       = optional(string, "AAD")
          private_endpoint         = optional(any, {})
          private_endpoint_cognitive = optional(any,
            {
              current_blob = {
                alias            = "current"
                subresource_name = "blob"
                ip_configuration = [ // Use this block to fix the IP address
                  {
                    cidrhost_hostnum = 27 // Take the IP address number "cidrhost_hostnum" of the current subnet
                  }
                ]
              }
              current_file = {
                alias            = "current"
                subresource_name = "file"
                ip_configuration = [ // Use this block to fix the IP address
                  {
                    cidrhost_hostnum = 28 // Take the IP address number "cidrhost_hostnum" of the current subnet
                  }
                ]
              }
              current_queue = {
                alias            = "current"
                subresource_name = "queue"
                ip_configuration = [ // Use this block to fix the IP address
                  {
                    cidrhost_hostnum = 29 // Take the IP address number "cidrhost_hostnum" of the current subnet
                  }
                ]
              }
              current_table = {
                alias            = "current"
                subresource_name = "table"
                ip_configuration = [ // Use this block to fix the IP address
                  {
                    cidrhost_hostnum = 30 // Take the IP address number "cidrhost_hostnum" of the current subnet
                  }
                ]
              }

              shared-services_blob = {
                alias            = "shared-services"
                subresource_name = "blob"
              }
              shared-services_file = {
                alias            = "shared-services"
                subresource_name = "file"
              }
              shared-services_queue = {
                alias            = "shared-services"
                subresource_name = "queue"
              }
              shared-services_table = {
                alias            = "shared-services"
                subresource_name = "table"
              }
            }
          )
        }), {}
      )
      })),
      {
        "01" = {}
      }
    )
    cognitive_account = optional(object({
      storage_account_key                     = optional(string, "machine_learning_01")
      kind_without_storage                    = list(string)
      kind_with_storage_account_network_rules = list(string)
      OpenAI = object({
        suffix_name = string
      })
      TextTranslation = object({
        suffix_name = string
      })
      SpeechServices = object({
        suffix_name = string
      })
      Bing_Search_v7 = object({
        suffix_name = string
      })
      ComputerVision = object({
        suffix_name = string
      })
      TextAnalytics = object({ //Language service
        suffix_name = string
      })
      }),
      {
        "kind_without_storage"                    = ["OpenAI", "TextTranslation", "Bing.Search.v7", "ComputerVision"]
        "kind_with_storage_account_network_rules" = ["TextTranslation"]
        "OpenAI" = {
          suffix_name = "oai"
        }
        "TextTranslation" = {
          suffix_name = "trsl"
        }
        "SpeechServices" = {
          suffix_name = "spch"
        }
        "Bing_Search_v7" = {
          suffix_name = "bingv7"
        }
        "ComputerVision" = {
          suffix_name = "cv"
        }
        "TextAnalytics" = {
          suffix_name = "lang" //language service
        }
    })
  })
  default = {}
}

variable "machine_learning_ai_services" {
  description = "Azure AI services"
  type = map(object({
    instance_name                = optional(string, "01")
    workload_name                = optional(string, null)
    resource_group_key           = optional(string)
    key_vault_key                = optional(string)
    sku_name                     = optional(string, "S0") //The sku name of the Azure Analysis Services server to create. Choose from: B1, B2, D1, S0, S1, S2, S3, S4, S8, S9. Some skus are region specific. See https://docs.microsoft.com/en-us/azure/analysis-services/analysis-services-overview#availability-by-region"
    local_authentication_enabled = optional(bool, false)
    tags = optional(map(string), {
      description = "Azure AI services"
      ops_team    = "g-x-admin-azure",
      it_owner    = "g-x-admin-azure"
    })
    private_endpoint = optional(map(object({
      instance_name       = optional(string, "01")
      location            = optional(string)
      region_code         = optional(string)
      alias               = string
      subresource_name    = optional(string, "account")
      resource_group_name = optional(string)
      subnet_key          = optional(string)
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = string
        name             = string
      })), [])
      })), {
      current_account = {
        alias            = "current"
        subresource_name = "account"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 14 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "default"
            name             = "ai-services-default"
          },
          {
            cidrhost_hostnum = 15 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "secondary"
            name             = "ai-services-secondary"
          },
          {
            cidrhost_hostnum = 16 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "third"
            name             = "ai-services-third"
          }
        ]
      }

      shared-services_account = {
        alias            = "shared-services"
        subresource_name = "account"
      }
    })
  }))
  default = {
    "01" = {}
  }
}

variable "machine_learning_workspace_hub" {
  description = "Azure AI Studio hub - Fundry"
  type = map(object({
    instance_name      = optional(string, "01")
    workload_name      = optional(string, null)
    resource_group_key = optional(string)
    ai_services_key    = optional(string, "01")
    tags = optional(map(string), {
      description = "Azure AI Studio hub"
      ops_team    = "g-x-admin-azure"
      it_owner    = "g-x-admin-azure"
    })
    application_insights_id       = optional(string)
    application_insights_create   = optional(bool, true)
    key_vault_key                 = optional(string)
    container_registry_key        = optional(string)
    user_assigned_identity_create = optional(bool, true)
    role_assignment               = optional(any, {})
    encryption = optional(object({
      key_vault_id      = optional(string)
      key_vault_key     = optional(string)
      key_id            = optional(string)
      key_vault_key_key = optional(string)
      status            = optional(bool)
    }), {})
    private_endpoint = optional(any, {
      current_amlworkspace = {
        alias            = "current"
        subresource_name = "amlworkspace"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 17 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "notebook"
            name             = "workspace-hub-notebook"
          },
          {
            cidrhost_hostnum = 18 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "inference"
            name             = "workspace-hub-inference"
          },
          {
            cidrhost_hostnum = 19 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "models"
            name             = "workspace-hub-models"
          },
          {
            cidrhost_hostnum = 20 // Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "default"
            name             = "workspace-hub-default"
          },
        ]
      }

      shared-services_amlworkspace = {
        alias            = "shared-services"
        subresource_name = "amlworkspace"
      }
    })
  }))
  default = {
    "01" = {}
  }
}

variable "machine_learning_cognitive_account" {
  description = "Map of cognitive accounts to create."
  type = map(object({
    instance_name                 = optional(string, "01")
    workload_name                 = optional(string, null)
    resource_group_key            = optional(string)
    key_vault_key                 = optional(string)
    key_vault_key_key             = optional(string)
    key_vault_rbac                = optional(bool, true)
    user_assigned_identity_create = optional(bool, true)
    user_assigned_identity_id     = optional(string)
    sku_name                      = string
    kind                          = string
    location                      = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    public_network_access_enabled         = optional(bool, false)
    storage_account_container_suffix_name = optional(list(string), [])
    outbound_network_access_restricted    = optional(bool, true)
    local_auth_enabled                    = optional(bool, false)
    fqdns                                 = optional(list(string))
    customer_managed_key = optional(object({
      key_vault_key_id = string
    }))
    customer_managed_key_enable = optional(bool, true)
    custom_subdomain_name       = optional(string)
    model                       = optional(any)
    model_not_available         = optional(list(string), [])
    rai_policy                  = optional(any, {})
    rai_policy_name             = optional(string)
    private_endpoint = optional(map(object({
      instance_name       = optional(string, "01")
      location            = optional(string)
      region_code         = optional(string)
      alias               = string
      subresource_name    = optional(string, "account")
      resource_group_name = optional(string)
      subnet_key          = optional(string, "01-snet-back-private-endpoints-01")
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = string
        name             = optional(string)
      })), [])
      })), {
      current_account = {
        alias            = "current"
        subresource_name = "account"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 23 //25, 26 Take the IP address number "cidrhost_hostnum" of the current subnet
            member_name      = "default"
            name             = "coginitive-default"
          },
        ]
      }

      shared-services_account = {
        alias            = "shared-services"
        subresource_name = "account"
      }
    })
  }))
  default = {}
}

variable "machine_learning_project" {
  description = "Azure AI Project"
  type = map(object({
    workload_name      = optional(string, null)
    instance_name      = optional(string, "01")
    workspace_hub_key  = optional(string, "01")
    resource_group_key = optional(string, null)
    description        = optional(string, null)
    friendly_name      = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {}
}

variable "machine_learning_model" {
  description = "Azure AI Model"
  type = map(object({
    name                  = optional(string)
    content_safety_status = optional(string, "Enabled")
    model_id              = string
    project_key           = string
    resource_group_key    = optional(string, null)
    sku_name              = optional(string, "Consumption")
    subscribe             = optional(bool, false)
  }))
  default = {}
}

##############################################
###### Event area specifications
##############################################

variable "event_creation" {
  description = "Create the event platform"
  type        = bool
  default     = false
}

variable "event_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    workload_name = optional(string, "event")
    location      = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "event_default_specification" {
  description = "Event platform default specifications"
  type = object({
    event_servicebus_namespace = object({
      create                   = optional(bool, true)
      key_vault_key            = optional(string, "01")
      allow_aviatrix_public_ip = optional(bool, true)
      np = optional(object({
        sku                           = optional(string)
        capacity                      = optional(number)
        premium_messaging_partitions  = optional(number)
        key_vault_key                 = optional(string, "01")
        key_vault_key_key             = optional(string, "event_01")
        public_network_access_enabled = optional(bool, false)
        local_auth_enabled            = optional(bool, false)
        minimum_tls_version           = optional(string, "1.2")
        network_rule_set = optional(list(object({
          default_action           = optional(string)
          ip_rules                 = optional(list(string))
          trusted_services_allowed = optional(bool)
          network_rules = optional(list(object({
            subnet_id                            = optional(string, null)
            ignore_missing_vnet_service_endpoint = optional(bool, false)
          })), [])
        })), [])
        timeouts = optional(list(object({
          create = optional(string, null)
          update = optional(string, null)
          read   = optional(string, null)
          delete = optional(string, null)
        })), [])
        queue = optional(object({
          name                                    = optional(string)
          lock_duration                           = optional(string)
          duplicate_detection_history_time_window = optional(string)
          requires_duplicate_detection            = optional(bool)
          requires_session                        = optional(bool)
          forward_to                              = optional(string)
          forward_dead_lettered_messages_to       = optional(string)
          dead_lettering_on_message_expiration    = optional(bool)
          max_delivery_count                      = optional(number)
          status                                  = optional(string)
          auto_delete_on_idle                     = optional(string)
          default_message_ttl                     = optional(string)
          max_size_in_megabytes                   = optional(number, 1024)
          authorization_rule                      = optional(list(string), [])
          timeouts = optional(list(object({
            create = optional(string)
            update = optional(string)
            read   = optional(string)
            delete = optional(string)
          })), [])
          role_assignments = optional(map(object({
            role_definition_name = string
            principal_ids        = list(string)
            scope_suffix         = optional(string, "")
        })), {}) }), {})
        topic = optional(object({
          name                          = optional(string)
          status                        = optional(string)
          auto_delete_on_idle           = optional(string)
          default_message_ttl           = optional(string)
          duplicate_detection_window    = optional(string)
          express_enabled               = optional(bool)
          max_message_size_in_kilobytes = optional(number)
          max_size_in_megabytes         = optional(number, 1024)
          requires_duplicate_detection  = optional(bool)
          support_ordering              = optional(bool)
          timeouts = optional(list(object({
            create = optional(string)
            update = optional(string)
            read   = optional(string)
            delete = optional(string)
          })), [])
        }), {})
        role_assignments = optional(map(object({
          role_definition_name = string
          principal_ids        = list(string)
          scope_suffix         = optional(string, "")
        })), {})
      }), {})
      prd = optional(object({
        sku                           = optional(string)
        capacity                      = optional(number)
        premium_messaging_partitions  = optional(number)
        key_vault_key                 = optional(string, "01")
        key_vault_key_key             = optional(string, "event_01")
        local_auth_enabled            = optional(bool, true)
        public_network_access_enabled = optional(bool, true)
        minimum_tls_version           = optional(string, "1.2")
        timeouts = optional(list(object({
          create = optional(string, null)
          update = optional(string, null)
          read   = optional(string, null)
          delete = optional(string, null)
        })), [])
        network_rule_set = optional(list(object({
          default_action           = optional(string)
          ip_rules                 = optional(list(string))
          trusted_services_allowed = optional(bool)
          network_rules = optional(list(object({
            subnet_id                            = optional(string, null)
            ignore_missing_vnet_service_endpoint = optional(bool, false)
          })), [])
        })), [])
        queue = optional(object({
          name                                    = optional(string)
          lock_duration                           = optional(string)
          duplicate_detection_history_time_window = optional(string)
          requires_duplicate_detection            = optional(bool)
          requires_session                        = optional(bool)
          forward_to                              = optional(string)
          forward_dead_lettered_messages_to       = optional(string)
          dead_lettering_on_message_expiration    = optional(bool)
          max_delivery_count                      = optional(number)
          status                                  = optional(string)
          auto_delete_on_idle                     = optional(string)
          default_message_ttl                     = optional(string)
          max_size_in_megabytes                   = optional(number)
          authorization_rule                      = optional(list(string), [])
          timeouts = optional(list(object({
            create = optional(string)
            update = optional(string)
            read   = optional(string)
            delete = optional(string)
          })), [])
          role_assignments = optional(map(object({
            role_definition_name = string
            principal_ids        = list(string)
            scope_suffix         = optional(string, "")
        })), {}) }), {})
        topic = optional(object({
          name                          = optional(string)
          status                        = optional(string)
          auto_delete_on_idle           = optional(string)
          default_message_ttl           = optional(string)
          duplicate_detection_window    = optional(string)
          express_enabled               = optional(bool)
          max_message_size_in_kilobytes = optional(number)
          max_size_in_megabytes         = optional(number)
          requires_duplicate_detection  = optional(bool)
          support_ordering              = optional(bool)
          timeouts = optional(list(object({
            create = optional(string)
            update = optional(string)
            read   = optional(string)
            delete = optional(string)
          })), [])
        }), {})
        role_assignments = optional(map(object({
          role_definition_name = string
          principal_ids        = list(string)
          scope_suffix         = optional(string, "")
        })), {})
      }), {})
    })
  })
  default = {
    event_servicebus_namespace = {
      np  = {}
      prd = {}
    }
  }
}

variable "event_servicebus_namespace" {
  description = "Map of event bus to create"
  type = map(object({
    instance_name                   = optional(string, "01")
    resource_group_key              = optional(string, "01")
    private_link_resource_group_key = optional(string, "01")
    key_vault_key                   = optional(string)
    sku                             = optional(string, "Basic")
    capacity                        = optional(number, 0)
    public_network_access_enabled   = optional(bool, false)
    premium_messaging_partitions    = optional(number, 0)
    local_auth_enabled              = optional(bool, false)
    minimum_tls_version             = optional(string, "1.2")
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    identity = optional(object({
      type        = optional(string, "UserAssigned")
      identity_id = optional(string)
    }), {})
    timeouts = optional(list(object({
      create = optional(string, null)
      update = optional(string, null)
      read   = optional(string, null)
      delete = optional(string, null)
    })), [])
    network_rule_set = optional(list(object({
      default_action           = optional(string)
      ip_rules                 = optional(list(string))
      trusted_services_allowed = optional(bool)
      network_rules = optional(list(object({
        subnet_id                            = optional(string, null)
        ignore_missing_vnet_service_endpoint = optional(bool, false)
      })), [])
      })), [
      {
        default_action = "Deny"
        ip_rules = [
          "34.140.168.60",
          "34.140.168.61",
          "34.140.168.62",
          "34.140.168.63",
          "84.14.108.122",
          "109.7.48.66",
          "192.44.63.160/28"
        ]
        trusted_services_allowed = false
      }
    ])
    queue = optional(map(object({
      name                                    = optional(string)
      lock_duration                           = optional(string)
      duplicate_detection_history_time_window = optional(string)
      requires_duplicate_detection            = optional(bool)
      requires_session                        = optional(bool)
      forward_to                              = optional(string)
      forward_dead_lettered_messages_to       = optional(string)
      dead_lettering_on_message_expiration    = optional(bool)
      max_delivery_count                      = optional(number)
      status                                  = optional(string)
      auto_delete_on_idle                     = optional(string)
      default_message_ttl                     = optional(string)
      max_size_in_megabytes                   = optional(number, 1024)
      authorization_rule                      = optional(list(string), [])
      timeouts = optional(list(object({
        create = optional(string, null)
        update = optional(string, null)
        read   = optional(string, null)
        delete = optional(string, null)
      })), [])
      role_assignments = optional(map(object({
        role_definition_name = optional(string)
        principal_ids        = list(string)
        scope_suffix         = optional(string, "")
    })), {}) })), {})
    topic = optional(map(object({
      name                          = optional(string)
      status                        = optional(string)
      auto_delete_on_idle           = optional(string)
      default_message_ttl           = optional(string)
      duplicate_detection_window    = optional(string)
      express_enabled               = optional(bool)
      max_message_size_in_kilobytes = optional(number)
      max_size_in_megabytes         = optional(number)
      requires_duplicate_detection  = optional(bool)
      support_ordering              = optional(bool)
      timeouts = optional(list(object({
        create = optional(string)
        update = optional(string)
        read   = optional(string)
        delete = optional(string)
      })), [])
    })), {})
    role_assignments = optional(map(object({
      role_definition_name = string
      principal_ids        = list(string)
      scope_suffix         = optional(string, "")
    })), {})
    private_endpoint = optional(map(object({
      alias               = string
      instance_name       = optional(string, "01")
      region_code         = optional(string)
      location            = optional(string)
      resource_group_name = optional(string)
      subnet_key          = optional(string, "01-snet-back-private-endpoints-01")
      ip_configuration = optional(list(object({
        cidrhost_hostnum = number
        member_name      = optional(string, null)
      })), [])
      })),
      {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 38 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }
        shared-services = {
          alias = "shared-services"
        }
      }
    )
  }))
  default = {
    "01" = {}
  }
}

##############################################
###### App services area specifications
##############################################

variable "app_service_creation" {
  description = "Create app services"
  type        = bool
  default     = false
}

variable "app_service_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default = {
    "01" = {
      tags = {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      }
    }
  }
}

variable "app_service_default_specification" {
  description = "App services default specifications"
  type = object({
    app_service = object({
      kind                                           = optional(string, "functionapp")
      public_network_access_enabled                  = optional(bool, false)
      subnet_key                                     = optional(string, "01-snet-app-service-01")
      webdeploy_publish_basic_authentication_enabled = optional(bool, false)
      ftp_publish_basic_authentication_enabled       = optional(bool, false)
      https_only                                     = optional(bool, true)
      storage_uses_managed_identity                  = optional(bool, true)
      skip_service_principal_aad_check               = optional(bool, false)
      key_vault_key                                  = optional(string, "01")
      key_vault_key_key                              = optional(string, "app_service_01")
      principal_type                                 = optional(string, "ServicePrincipal")
      AzureWebJobsStorage__credential                = optional(string)
      AZURE_FUNCTIONS_ENVIRONMENT                    = optional(string)
      app_service_plans = object({
        instance = optional(string, "01")
        os_type  = optional(string, "Linux")
        sku_name = optional(string, "P0v3") // FC1 not available for the moment
      })
      application_insights = optional(object({
        application_type    = optional(string, "web")
        inherit_tags        = optional(bool, false)
        location            = optional(string)
        name                = optional(string)
        resource_group_name = optional(string)
        tags = optional(map(any), {
          ops_team = "g-x-admin-azure",
          it_owner = "g-x-admin-azure"
        })
        workspace_resource_id                 = optional(string)
        daily_data_cap_in_gb                  = optional(number)
        daily_data_cap_notifications_disabled = optional(bool)
        retention_in_days                     = optional(number, 90)
        sampling_percentage                   = optional(number, 100)
        disable_ip_masking                    = optional(bool, false)
        local_authentication_disabled         = optional(bool, false)
        internet_ingestion_enabled            = optional(bool, true)
        internet_query_enabled                = optional(bool, true)
        force_customer_storage_for_profiler   = optional(bool, false)
      }), {})
      app_settings = optional(map(string), {
        WEBSITE_TIME_ZONE                      = "Romance Standard Time"
        WEB_CONCURRENCY                        = "1"
        WEBSITE_RUN_FROM_PACKAGE               = "1"
        WEBSITE_ENABLE_SYNC_UPDATE_SITE        = "true"
        WEBSITE_ENABLE_SYNC_UPDATE_SITE_LOCKED = "false"
        SCM_DO_BUILD_DURING_DEPLOYMENT         = "false"
        FUNCTIONS_WORKER_RUNTIME               = "powershell"
        AzureWebJobsSecretStorageType          = "Blob"
        AzureWebJobsDisableHomepage            = "false"
      })
      site_config = optional(object({
        always_on                                     = optional(bool, true)
        api_definition_url                            = optional(string)
        api_management_api_id                         = optional(string)
        app_command_line                              = optional(string)
        auto_heal_enabled                             = optional(bool)
        app_scale_limit                               = optional(number)
        application_insights_connection_string        = optional(string)
        application_insights_key                      = optional(string)
        container_registry_managed_identity_client_id = optional(string)
        container_registry_use_managed_identity       = optional(bool)
        default_documents                             = optional(list(string))
        elastic_instance_minimum                      = optional(number)
        ftps_state                                    = optional(string, "FtpsOnly")
        health_check_eviction_time_in_min             = optional(number)
        health_check_path                             = optional(string)
        http2_enabled                                 = optional(bool, false)
        ip_restriction_default_action                 = optional(string, "Allow")
        load_balancing_mode                           = optional(string, "LeastRequests")
        local_mysql_enabled                           = optional(bool, false)
        managed_pipeline_mode                         = optional(string, "Integrated")
        minimum_tls_version                           = optional(string, "1.3")
        pre_warmed_instance_count                     = optional(number)
        remote_debugging_enabled                      = optional(bool, false)
        remote_debugging_version                      = optional(string)
        runtime_scale_monitoring_enabled              = optional(bool)
        scm_ip_restriction_default_action             = optional(string, "Allow")
        scm_minimum_tls_version                       = optional(string, "1.2")
        scm_use_main_ip_restriction                   = optional(bool, false)
        use_32_bit_worker                             = optional(bool, false)
        vnet_route_all_enabled                        = optional(bool, true)
        websockets_enabled                            = optional(bool, false)
        worker_count                                  = optional(number)
        app_service_logs = optional(map(object({
          disk_quota_mb         = optional(number, 35)
          retention_period_days = optional(number)
        })), {})
        application_stack = optional(map(object({
          dotnet_core_version         = optional(string)
          dotnet_version              = optional(string)
          java_version                = optional(string)
          node_version                = optional(string)
          powershell_core_version     = optional(string)
          python_version              = optional(string)
          go_version                  = optional(string)
          ruby_version                = optional(string)
          java_server                 = optional(string)
          java_server_version         = optional(string)
          php_version                 = optional(string)
          use_custom_runtime          = optional(bool)
          use_dotnet_isolated_runtime = optional(bool)
          docker = optional(list(object({
            image_name        = string
            image_tag         = string
            registry_password = optional(string)
            registry_url      = string
            registry_username = optional(string)
          })))
          current_stack                = optional(string)
          docker_image_name            = optional(string)
          docker_registry_url          = optional(string)
          docker_registry_username     = optional(string)
          docker_registry_password     = optional(string)
          docker_container_name        = optional(string)
          docker_container_tag         = optional(string)
          java_embedded_server_enabled = optional(bool)
          tomcat_version               = optional(bool)
        })), {})
        cors = optional(map(object({
          allowed_origins     = optional(list(string))
          support_credentials = optional(bool, false)
        })), {})
        ip_restriction = optional(map(object({
          action                    = optional(string, "Allow")
          ip_address                = optional(string)
          name                      = optional(string)
          priority                  = optional(number, 65000)
          service_tag               = optional(string)
          virtual_network_subnet_id = optional(string)
          headers = optional(map(object({
            x_azure_fdid      = optional(list(string))
            x_fd_health_probe = optional(list(string), ["1"])
            x_forwarded_for   = optional(list(string))
            x_forwarded_host  = optional(list(string))
          })), {})
        })), {})
        scm_ip_restriction = optional(map(object({
          action                    = optional(string, "Allow")
          ip_address                = optional(string)
          name                      = optional(string)
          priority                  = optional(number, 65000)
          service_tag               = optional(string)
          virtual_network_subnet_id = optional(string)
          headers = optional(map(object({
            x_azure_fdid      = optional(list(string))
            x_fd_health_probe = optional(list(string), ["1"])
            x_forwarded_for   = optional(list(string))
            x_forwarded_host  = optional(list(string))
          })), {})
        })), {})
        virtual_application = optional(map(object({
          physical_path   = optional(string, "site\\wwwroot")
          preload_enabled = optional(bool, false)
          virtual_directory = optional(map(object({
            physical_path = optional(string)
            virtual_path  = optional(string)
          })), {})
          virtual_path = optional(string, "/")
          })),
          {
            default = {
              physical_path   = "site\\wwwroot"
              preload_enabled = false
              virtual_path    = "/"
            }
        })
      }), {})
      managed_identities = optional(object({
        system_assigned            = optional(bool, false)
        user_assigned_resource_ids = optional(set(string), [])
      }), {})
    })
  })
  default = {
    app_service = {
      app_service_plans = {}
    }
  }
}

variable "app_service_plans" {
  description = "app_service_plans"
  type = map(object({
    workload_name      = optional(string)
    instance_name      = optional(string, "01")
    resource_group_key = optional(string, "01")
    os_type            = string
    sku_name           = string
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
    "01" = {
      instance_name = "01"
      os_type       = "Linux"
      sku_name      = "P0v3"

    }
  }
}

variable "app_service" {
  description = "App service spec"
  type = map(object({
    instance_name                                  = optional(string, "01")
    resource_group_key                             = optional(string, "01")
    private_link_resource_group_key                = optional(string, "01")
    subnet_key                                     = optional(string)
    key_vault_key                                  = optional(string)
    enable_key_vault_roles                         = optional(bool, true)
    workload_name                                  = optional(string)
    kind                                           = optional(string, "functionapp")
    storage_uses_managed_identity                  = optional(bool, true)
    public_network_access_enabled                  = optional(bool, false)
    ftp_publish_basic_authentication_enabled       = optional(bool, false)
    webdeploy_publish_basic_authentication_enabled = optional(bool, false)
    https_only                                     = optional(bool, true)
    AzureWebJobsStorage__credential                = optional(string, "managedidentity")
    application_insights = optional(object({
      application_type    = optional(string, "web")
      inherit_tags        = optional(bool, false)
      location            = optional(string)
      name                = optional(string)
      resource_group_name = optional(string)
      tags = optional(map(any), {
        ops_team = "g-x-admin-azure",
        it_owner = "g-x-admin-azure"
      })
      workspace_resource_id                 = optional(string)
      daily_data_cap_in_gb                  = optional(number)
      daily_data_cap_notifications_disabled = optional(bool)
      retention_in_days                     = optional(number, 90)
      sampling_percentage                   = optional(number, 100)
      disable_ip_masking                    = optional(bool, false)
      local_authentication_disabled         = optional(bool, false)
      internet_ingestion_enabled            = optional(bool, true)
      internet_query_enabled                = optional(bool, true)
      force_customer_storage_for_profiler   = optional(bool, false)
    }), {})
    private_endpoint = optional(map(object({
      alias                           = optional(string)
      instance_name                   = optional(string, "01")
      region_code                     = optional(string)
      location                        = optional(string)
      resource_group_name             = optional(string)
      dns_custom                      = optional(bool, false)
      resource_group_custom           = optional(bool, false)
      custom_subnet_id                = optional(bool, false)
      subnet_id                       = optional(string)
      private_dns_zone_ids            = optional(string)
      address_prefix                  = optional(string)
      subresource_name                = optional(string, "sites")
      private_link_resource_group_key = optional(string, "01")
      subnet_key                      = optional(string, "01-snet-back-private-endpoints-01")
      ip_configuration = optional(list(object({
        name               = optional(string)
        private_ip_address = optional(string)
        cidrhost_hostnum   = optional(number)
        member_name        = optional(string)
        subresource_name   = optional(string, "sites")
      })), [])
      })),
      {
        current = {
          alias = "current"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 37 // Take the IP address number "cidrhost_hostnum" of the current subnet
              subresource_name = "sites"

            }
          ]
        }
        shared-services = {
          alias            = "shared-services"
          subresource_name = "sites"
        }
      }
    )
    app_settings = optional(map(string), {
      WEBSITE_TIME_ZONE                      = "Romance Standard Time"
      WEB_CONCURRENCY                        = "1"
      WEBSITE_RUN_FROM_PACKAGE               = "1"
      WEBSITE_ENABLE_SYNC_UPDATE_SITE        = "true"
      WEBSITE_ENABLE_SYNC_UPDATE_SITE_LOCKED = "false"
      SCM_DO_BUILD_DURING_DEPLOYMENT         = "false"
      FUNCTIONS_WORKER_RUNTIME               = "powershell"
      AzureWebJobsSecretStorageType          = "Blob"
      AzureWebJobsDisableHomepage            = "false"
    })
    site_config = optional(object({
      always_on                                     = optional(bool, true)
      api_definition_url                            = optional(string)
      api_management_api_id                         = optional(string)
      app_command_line                              = optional(string)
      auto_heal_enabled                             = optional(bool)
      app_scale_limit                               = optional(number)
      application_insights_connection_string        = optional(string)
      application_insights_key                      = optional(string)
      container_registry_managed_identity_client_id = optional(string)
      container_registry_use_managed_identity       = optional(bool)
      default_documents                             = optional(list(string))
      elastic_instance_minimum                      = optional(number)
      ftps_state                                    = optional(string, "Disabled")
      health_check_eviction_time_in_min             = optional(number)
      health_check_path                             = optional(string)
      http2_enabled                                 = optional(bool, false)
      ip_restriction_default_action                 = optional(string, "Allow")
      load_balancing_mode                           = optional(string, "LeastRequests")
      local_mysql_enabled                           = optional(bool, false)
      managed_pipeline_mode                         = optional(string, "Integrated")
      minimum_tls_version                           = optional(string, "1.3")
      pre_warmed_instance_count                     = optional(number)
      remote_debugging_enabled                      = optional(bool, false)
      remote_debugging_version                      = optional(string)
      runtime_scale_monitoring_enabled              = optional(bool)
      scm_ip_restriction_default_action             = optional(string, "Allow")
      scm_minimum_tls_version                       = optional(string, "1.3")
      scm_use_main_ip_restriction                   = optional(bool, false)
      use_32_bit_worker                             = optional(bool, false)
      vnet_route_all_enabled                        = optional(bool, true)
      websockets_enabled                            = optional(bool, false)
      worker_count                                  = optional(number)
      app_service_logs = optional(map(object({
        disk_quota_mb         = optional(number, 35)
        retention_period_days = optional(number)
      })), {})
      application_stack = optional(map(object({
        dotnet_core_version         = optional(string)
        dotnet_version              = optional(string)
        java_version                = optional(string)
        node_version                = optional(string)
        powershell_core_version     = optional(string)
        python_version              = optional(string)
        go_version                  = optional(string)
        ruby_version                = optional(string)
        java_server                 = optional(string)
        java_server_version         = optional(string)
        php_version                 = optional(string)
        use_custom_runtime          = optional(bool)
        use_dotnet_isolated_runtime = optional(bool)
        docker = optional(list(object({
          image_name        = string
          image_tag         = string
          registry_password = optional(string)
          registry_url      = string
          registry_username = optional(string)
        })))
        current_stack                = optional(string)
        docker_image_name            = optional(string)
        docker_registry_url          = optional(string)
        docker_registry_username     = optional(string)
        docker_registry_password     = optional(string)
        docker_container_name        = optional(string)
        docker_container_tag         = optional(string)
        java_embedded_server_enabled = optional(bool)
        tomcat_version               = optional(bool)
      })), {})
      cors = optional(map(object({
        allowed_origins     = optional(list(string))
        support_credentials = optional(bool, false)
        })), {
        default = {
          allowed_origins = ["https://portal.azure.com"]
        }
      })
      ip_restriction = optional(map(object({
        action                    = optional(string, "Allow")
        ip_address                = optional(string)
        name                      = optional(string)
        priority                  = optional(number, 65000)
        service_tag               = optional(string)
        virtual_network_subnet_id = optional(string)
        headers = optional(map(object({
          x_azure_fdid      = optional(list(string))
          x_fd_health_probe = optional(list(string), ["1"])
          x_forwarded_for   = optional(list(string))
          x_forwarded_host  = optional(list(string))
        })), {})
      })), {})
      scm_ip_restriction = optional(map(object({
        action                    = optional(string, "Allow")
        ip_address                = optional(string)
        name                      = optional(string)
        priority                  = optional(number, 65000)
        service_tag               = optional(string)
        virtual_network_subnet_id = optional(string)
        headers = optional(map(object({
          x_azure_fdid      = optional(list(string))
          x_fd_health_probe = optional(list(string), ["1"])
          x_forwarded_for   = optional(list(string))
          x_forwarded_host  = optional(list(string))
        })), {})
      })), {})
      virtual_application = optional(map(object({
        physical_path   = optional(string, "site\\wwwroot")
        preload_enabled = optional(bool, false)
        virtual_directory = optional(map(object({
          physical_path = optional(string)
          virtual_path  = optional(string)
        })), {})
        virtual_path = optional(string, "/")
        })),
        {
          default = {
            physical_path   = "site\\wwwroot"
            preload_enabled = false
            virtual_path    = "/"
          }
      })
      }), {

      cors = {
        default = {
          allowed_origins = ["https://portal.azure.com"]
        }
      }
    })
    managed_identities = optional(object({
      system_assigned            = optional(bool, false)
      user_assigned_resource_ids = optional(set(string), [])
    }), {})
    app_service_storage_account = optional(object({
      instance_name      = optional(string, "01")
      workload_name      = optional(string, null)
      resource_group_key = optional(string, "01")
      key_vault_key      = optional(string)
      tags = optional(map(string), {
        description = "azure app service"
        ops_team    = "g-x-admin-azure",
        it_owner    = "g-x-admin-azure"
      })
      network_rules = optional(map(object({
        default_action             = optional(string, "Deny")
        bypass                     = optional(list(string), ["None"])
        ip_rules                   = optional(list(string), [])
        virtual_network_subnet_ids = optional(list(string), [])
        private_link_access = optional(list(object({
          endpoint_resource_id = string
          endpoint_tenant_id   = optional(string)
        })), [])
        })), {
        "01" = {
          default_action = "Deny"
        }
      })
      account_tier                  = optional(string, "Standard")
      account_kind                  = optional(string, "StorageV2")
      public_network_access_enabled = optional(bool, false)
      is_hns_enabled                = optional(bool, false)
      account_replication_type      = optional(string, "ZRS")
      role_assignment               = optional(any, {})
      share                         = optional(any, {})
      private_endpoint = optional(map(object({
        instance_name                   = optional(string, "01")
        private_link_resource_group_key = optional(string, "01")
        resource_group_key              = optional(string, "01")
        dns_custom                      = optional(bool, false)
        resource_group_custom           = optional(bool, false)
        resource_group_name             = optional(string)
        location                        = optional(string)
        region_code                     = optional(string)
        private_dns_zone_ids            = optional(string)
        subnet_id                       = optional(string)
        address_prefix                  = optional(string)
        subnet_key                      = optional(string, "01-snet-back-private-endpoints-01")

        alias            = string
        subresource_name = string
        ip_configuration = optional(list(object({
          cidrhost_hostnum = number
        })), [])
        })), {
        current = {
          alias            = "current"
          subresource_name = "blob"
          ip_configuration = [
            {
              cidrhost_hostnum = 40
            }
          ]
        }
        shared-services = {
          alias            = "shared-services"
          subresource_name = "blob"
        }
      })
    }), {})
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
  }))
  default = {
    "01" = {
    }
  }
}

##############################################
###### Monitor area specifications
##############################################
variable "monitor_creation" {
  description = "Create the Machine Learning area"
  type        = bool
  default     = false
}

variable "monitor_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    workload_name = optional(string, "monitor")
    location      = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
    })), {})
  }))
  default = {
    "01" = {}
  }
}

variable "monitor_app_insight" {
  description = "Azure Monitor Application insight"
  type = map(object({
    instance_name      = optional(string, "01")
    workload_name      = optional(string, null)
    location           = optional(string, null)
    resource_group_key = optional(string, "01")
    application_type   = optional(string, "web")
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    application_insights_id     = optional(string)
    application_insights_create = optional(bool, false)
  }))
  default = {
    "01" = {
    }
  }
}

##############################################
###### Backup area specifications
##############################################
variable "backup_creation" {
  description = "Create the Backup area"
  type        = bool
  default     = false
}

variable "backup_resource_group" {
  description = "Resource Group specifications"
  type = map(object({
    instance_name = optional(string, "01")
    workload_name = optional(string, "backup")
    location      = optional(string, null)
    tags = optional(map(string), {
      ops_team = "g-x-admin-azure",
      it_owner = "g-x-admin-azure"
    })
    role_assignment = optional(map(object({
      role_definition_name = string
      principal_id         = string
      principal_type       = optional(string, null)
      })), {
      "Backup Contributor - GSCO_CREW_DBA" = {
        role_definition_name = "Backup Contributor"
        principal_id         = "587e52bb-0071-47ad-9269-78398487eaa1"
        principal_type       = "Group"
      }
    })
  }))
  default = {
    "01" = {}
  }
}

variable "backup_vault_default_specification" {
  description = "Backup vault default specifications"
  type = object({
    key_vault_key = optional(string, "01")
    storage_account = optional(map(object({
      instance_name      = optional(string, "01")
      workload_name      = optional(string, null)
      resource_group_key = optional(string, "01")
      key_vault_key      = optional(string)
      storage_account = optional(object(
        {
          instance_name                    = optional(string, "01")
          workload_name                    = optional(string, null)
          resource_group_key               = optional(string, "01")
          key_vault_key                    = optional(string)
          public_network_access_enabled    = optional(bool, true)   // Required by Azure Backup Vault, see https://learn.microsoft.com/en-us/azure/backup/restore-azure-database-postgresql-flex#prerequisites?WT.mc_id=AZ-MVP-5003548
          cross_tenant_replication_enabled = optional(bool, true)   // Required by Azure Backup Vault, see https://learn.microsoft.com/en-us/azure/backup/restore-azure-database-postgresql-flex#prerequisites?WT.mc_id=AZ-MVP-5003548
          allowed_copy_scope               = optional(string, null) // !!! Warning not supported yet, we need to set this manually from the portal for the moment and re apply, see https://github.com/hashicorp/terraform-provider-azurerm/issues/30340. Required by Azure Backup Vault, see https://learn.microsoft.com/en-us/azure/storage/common/security-restrict-copy-operations?WT.mc_id=AZ-MVP-5003548&tabs=portal
          network_rules = optional(map(object({
            default_action             = optional(string, "Deny")
            bypass                     = optional(list(string), ["AzureServices"]) // Required by Azure Backup Vault, see https://learn.microsoft.com/en-us/azure/backup/restore-azure-database-postgresql-flex#prerequisites?WT.mc_id=AZ-MVP-5003548
            ip_rules                   = optional(list(string), [])
            virtual_network_subnet_ids = optional(list(string), [])
            private_link_access = optional(list(object({
              endpoint_resource_id = string
              endpoint_tenant_id   = optional(string)
            })), [])
          })), { "01" = {} })

          role_assignment = optional(map(object({
            role_definition_name = string
            principal_id         = string
            principal_type       = optional(string, null)
            })), {
            "Storage Blob Data Contributor - GSCO_CREW_DBA" = {
              role_definition_name = "Storage Blob Data Contributor"
              principal_id         = "587e52bb-0071-47ad-9269-78398487eaa1"
              principal_type       = "Group"
            }

            "Reader and Data Access - GSCO_CREW_DBA" = {
              role_definition_name = "Reader and Data Access"
              principal_id         = "587e52bb-0071-47ad-9269-78398487eaa1"
              principal_type       = "Group"
            }
            }
          )

          tags = optional(map(string), {
            description = "azure backup vault"
            ops_team    = "g-x-admin-azure",
            it_owner    = "g-x-admin-azure"
          })
          account_tier             = optional(string, "Standard")
          account_kind             = optional(string, "StorageV2")
          is_hns_enabled           = optional(bool, false)
          account_replication_type = optional(string, "ZRS")
          share                    = optional(any, {})
          container = optional(any, {
            "postgresql_flexible" = {
              name                  = "postgresql-flexible" //only lowercase alphanumeric characters and hyphens allowed
              container_access_type = "private"
            }
          })
          private_endpoint = optional(any,
            {
              shared-services_blob = {
                alias            = "shared-services"
                subresource_name = "blob"
              }
              shared-services_file = {
                alias            = "shared-services"
                subresource_name = "file"
              }
            }
          )

          management_policy = optional(any, {
            "purge_all_7_days" = {
              rule = [{
                name    = "purge_all_7_days"
                enabled = true
                filters = [
                  {
                    blob_types = ["blockBlob", "appendBlob"]
                  }
                ]
                actions = [
                  {
                    base_blob = [
                      {
                        delete_after_days_since_modification_greater_than = 7
                      }
                    ]
                    snapshot = [
                      {
                        delete_after_days_since_creation_greater_than = 1
                      }
                    ]
                    version = [
                      {
                        delete_after_days_since_creation = 1
                      }
                    ]
                  }
                ]
              }]
            }
          })
        }), {}
      )
      })),
      {
        "01" = {}
      }
    )
    np = optional(object({
      redundancy                   = optional(string, "LocallyRedundant")
      cross_region_restore_enabled = optional(bool, false) // "cross_region_restore_enabled can only be enabled when redundancy is set to GeoRedundant."
    }), {})
    prd = optional(object({
      redundancy                   = optional(string, "GeoRedundant")
      cross_region_restore_enabled = optional(bool, true) // "cross_region_restore_enabled can only be enabled when redundancy is set to GeoRedundant."
    }), {})
  })
  default = {}
}

variable "backup_vault" {
  description = "Azure Data Protection Backup Vault resource"
  type = map(object({
    instance_name      = optional(string, "01")
    workload_name      = optional(string)
    resource_group_key = optional(string, "01")
    key_vault_key      = optional(string)
    tags               = optional(map(string), {})
    datastore_type     = optional(string, "VaultStore") # Must be one of: ArchiveStore, OperationalStore, SnapshotStore, VaultStore.
    redundancy         = optional(string)

    # Backup Policies Configuration
    backup_policies = optional(map(object({
      type = string # "disk", "blob", "kubernetes", "postgresql", "postgresql_flexible"
      name = string

      # Common policy settings
      backup_repeating_time_intervals = optional(list(string), [])
      default_retention_duration      = optional(string, "P30D")
      time_zone                       = optional(string, "UTC")

      # Disk-specific settings
      # (all settings are shared with other types for consistency)

      # Blob-specific settings
      operational_default_retention_duration = optional(string)
      vault_default_retention_duration       = optional(string)

      # AKS-specific settings
      default_retention_life_cycle = optional(object({
        data_store_type = optional(string, "OperationalStore")
        duration        = optional(string, "P14D")
      }))

      # Retention rules (common to all types)
      retention_rules = optional(list(object({
        name     = string
        priority = number
        duration = optional(string, "P30D")
        criteria = list(object({
          absolute_criteria      = optional(string)
          days_of_month          = optional(list(number))
          days_of_week           = optional(list(string))
          months_of_year         = optional(list(string))
          scheduled_backup_times = optional(list(string))
          weeks_of_month         = optional(list(string))
        }))
        # Life cycle (for blob policies)
        life_cycle = optional(list(object({
          data_store_type = string
          duration        = string
        })), [])
      })), [])
      })),
      {
        "amundi-01-postgresql-flexible" = {
          type = "postgresql_flexible"
          name = "amundi-01-postgresql-flexible"
          backup_repeating_time_intervals = [
            "R/2025-12-21T23:00:00Z/P1W" // Every week on Sunday at 23:00 | UTC
          ]
          default_retention_duration = "P1Y" // 1 year
          time_zone                  = "UTC"
        }
      }
    )

    cross_region_restore_enabled = optional(bool)
  }))
  default = {
    "01" = {}
  }
}
