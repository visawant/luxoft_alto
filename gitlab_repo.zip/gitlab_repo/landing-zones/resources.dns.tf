resource "azurerm_resource_group" "dns" {
  for_each = local.dns_resource_group

  name     = "${local.region_code}-rg-dns-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
