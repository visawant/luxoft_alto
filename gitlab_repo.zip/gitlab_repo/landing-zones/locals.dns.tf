locals {
  dns_resource_group = { for key, value in var.dns_resource_group : key => value if var.dns_creation || var.dns_private_resolver_azure_creation || var.dns_vmss_forwarder_creation == true }
  dns_private_zone = { for key, value in merge(local.dns_private_endpoint_private_zone, var.dns_private_zone) : key => merge(
    {
      domain_name = replace(value.domain_name, "--application--", var.project_name)
      tags        = merge(var.dns_default_specification.dns_private_zone.tags, local.tags)
    }
  ) if var.dns_creation && var.virtual_network_creation }

  traefik_dns_a_record_name = var.environment == "prd" ? "${local.region_code}-traefik-${var.project_name}" : "${var.environment}-${local.region_code}-traefik-${var.project_name}"
  traefik_dns_cname_record_name = concat(
    #argoc-cd
    [var.environment == "prd" ? "${local.region_code}-argocd-${var.project_name}" : "${var.environment}-${local.region_code}-argocd-${var.project_name}"],

    #alertmanager
    [var.environment == "prd" ? "${local.region_code}-alertmanager-${var.project_name}" : "${var.environment}-${local.region_code}-alertmanager-${var.project_name}"],

    #prometheus
    [var.environment == "prd" ? "${local.region_code}-prometheus-${var.project_name}" : "${var.environment}-${local.region_code}-prometheus-${var.project_name}"],

    #custom
    [for traefik_private_endpoint_cname_record in flatten([for value in var.dns_records.traefik_private_endpoint_cname_record : value.dns_suffixes]) : var.environment == "prd" ? traefik_private_endpoint_cname_record : "${var.environment}-${traefik_private_endpoint_cname_record}"]
  )
  traefik_private_endpoint_cname_record = { for key, value in var.dns_records_http_probe_customization.traefik_private_endpoint_cname_record : var.environment == "prd" ? key : "${var.environment}-${key}" => value }
  traefik_dns_private_zone_a_records = { for name in toset(concat([local.traefik_dns_a_record_name], local.traefik_dns_cname_record_name)) : name =>
    {
      name                 = name
      dns_private_zone_key = "azure.intramundi.com"
      zone_name            = "azure.intramundi.com"
      resource_group_key   = "01"
      records              = [var.container_default_specification.aks.traefik_azure_load_balancer_ipv4]
      ttl                  = 300
      tags                 = merge({}, local.tags)
    } if var.container_creation && var.container_default_specification.aks.create
  }

  keycloak_dns_private_zone_a_records = { for suffix_name in ["-accounts", "-admin-accounts", "-sso-infra", "-admin-sso-infra"] : suffix_name =>
    {
      name                 = "${var.environment == "prd" ? local.region_code : "${local.environment_type}-${local.region_code}"}${suffix_name}"
      dns_private_zone_key = "azure.intramundi.com"
      zone_name            = "azure.intramundi.com"
      resource_group_key   = "01"
      records = [for value in var.regional_shared_resources[var.region].keycloak_infrastructure.ip_configuration :
        cidrhost(azurerm_subnet.connectivity[var.regional_shared_resources[var.region].keycloak_infrastructure.subnet_key].address_prefixes[0], value.cidrhost_hostnum)
      ]
      ttl  = 300
      tags = merge({}, local.tags)
    } if var.container_creation && var.container_default_specification.aks.create && !contains(flatten([for value in var.dns_records.traefik_private_endpoint_cname_record : value.dns_suffixes]), "${local.region_code}${suffix_name}")
  }

  dns_private_zone_a_records = { for key, value in merge(var.dns_private_zone_a_records, local.traefik_dns_private_zone_a_records, local.keycloak_dns_private_zone_a_records) : key => merge(
    value,
    {
      resource_group_name = azurerm_resource_group.dns[value.resource_group_key].name
    }
  ) if var.dns_creation && var.virtual_network_creation }

  dns_private_endpoint_private_zone_region = toset([for item in var.dns_private_endpoint_private_zone : replace(item, "--region--", local.location_cli)])
  dns_private_endpoint_private_zone        = { for key, value in local.dns_private_endpoint_private_zone_region : key => { domain_name = value } if var.dns_creation }

  dns_virtual_network_links = tomap({
    for virtual_network_link in
    flatten([
      for private_zone_key, private_zone in local.dns_private_zone : [
        for virtual_network_link_key, virtual_network_link in lookup(private_zone, "virtual_network_links", var.dns_default_specification.dns_private_zone.virtual_network_links) : merge(
          virtual_network_link,
          {
            private_zone_key         = private_zone_key
            virtual_network_link_key = virtual_network_link_key
            vnetlinkname             = trimsuffix(substr("${private_zone.domain_name}-${basename(azurerm_virtual_network.connectivity[virtual_network_link.virtual_network_key].id)}", 0, 79), "-")
            vnetid                   = azurerm_virtual_network.connectivity[virtual_network_link.virtual_network_key].id
            autoregistration         = lookup(virtual_network_link, "autoregistration", false)
            tags                     = merge(var.dns_default_specification.dns_private_zone.tags, local.tags)
          }
        )
      ]
    ]) : "${virtual_network_link.private_zone_key}-${virtual_network_link.virtual_network_link_key}" => virtual_network_link
  })

  dns_private_resolver = { for dns_private_resolver_key, dns_private_resolver in var.dns_private_resolver : dns_private_resolver_key => merge(
    dns_private_resolver,
    {
      azure_dns_private_resolver = var.dns_private_resolver_azure_creation ? { "my_azure_dns_private_resolver" = {
        name                = "${local.region_code}-dnspr-${lookup(dns_private_resolver, "workload_name", var.project_name)}-${var.environment}-${dns_private_resolver.instance_name}"
        resource_group_name = azurerm_resource_group.dns[lookup(dns_private_resolver, "resource_group_key", "01")].name
        location            = azurerm_resource_group.dns[lookup(dns_private_resolver, "resource_group_key", "01")].location
        virtual_network_id  = azurerm_virtual_network.connectivity["01"].id

        inbound_endpoint = { for inbound_endpoint_key, inbound_endpoint in lookup(dns_private_resolver.azure_dns_private_resolver, "inbound_endpoint", {}) : inbound_endpoint_key => merge(
          inbound_endpoint,
          {
            name = "${local.region_code}-in-${lookup(inbound_endpoint, "workload_name", var.project_name)}-${var.environment}-${inbound_endpoint.instance_name}"
            ip_configurations = [
              {
                subnet_id                    = azurerm_subnet.connectivity[inbound_endpoint.ip_configuration.subnet_key].id
                private_ip_address           = lookup(inbound_endpoint.ip_configuration, "private_ip_address", cidrhost(azurerm_subnet.connectivity[inbound_endpoint.ip_configuration.subnet_key].address_prefixes[0], inbound_endpoint.ip_configuration.cidrhost_hostnum))
                private_ip_allocation_method = inbound_endpoint.ip_configuration.private_ip_allocation_method
              }
            ]
          }
        ) }

        outbound_endpoint = { for outbound_endpoint_key, outbound_endpoint in lookup(dns_private_resolver.azure_dns_private_resolver, "outbound_endpoint", {}) : outbound_endpoint_key => merge(
          outbound_endpoint,
          {
            name      = "${local.region_code}-out-${lookup(outbound_endpoint, "workload_name", var.project_name)}-${var.environment}-${outbound_endpoint.instance_name}"
            subnet_id = azurerm_subnet.connectivity[outbound_endpoint.ip_configuration.subnet_key].id
          }
        ) }

        forwarding_ruleset = { for forwarding_ruleset_key, forwarding_ruleset in lookup(dns_private_resolver.azure_dns_private_resolver, "forwarding_ruleset", {}) : forwarding_ruleset_key => merge(
          forwarding_ruleset,
          {
            name = "${local.region_code}-dnsfrs-${lookup(forwarding_ruleset, "workload_name", var.project_name)}-${var.environment}-${forwarding_ruleset.instance_name}"
          }
        ) }

        forwarding_rule = { for forwarding_rule_key, forwarding_rule in lookup(dns_private_resolver.azure_dns_private_resolver, "forwarding_rule", {}) : forwarding_rule_key => merge(
          forwarding_rule,
          {}
        ) }

        virtual_network_link = { for virtual_network_link_key, virtual_network_link in lookup(dns_private_resolver.azure_dns_private_resolver, "virtual_network_link", {}) : virtual_network_link_key => merge(
          virtual_network_link,
          {
            virtual_network_id = lookup(virtual_network_link, "vnet_key", null) == null ? virtual_network_link.virtual_network_id : azurerm_virtual_network.connectivity[virtual_network_link.vnet_key].id
          }
        ) }

        tags = merge(dns_private_resolver.azure_dns_private_resolver.tags, local.tags)
      } } : {}
      vmss_private_resolver = var.dns_vmss_forwarder_creation ? { "my_vmss_private_resolver" = {
        lb_name             = "${local.region_code}-lbi-${lookup(dns_private_resolver, "workload_name", var.project_name)}-${var.environment}-${dns_private_resolver.instance_name}"
        location            = azurerm_resource_group.dns[lookup(dns_private_resolver, "resource_group_key", "01")].location
        resource_group_name = azurerm_resource_group.dns[lookup(dns_private_resolver, "resource_group_key", "01")].name
        subnet_id           = azurerm_subnet.connectivity["01-snet-shared-01"].id
        private_ip_address  = lookup(dns_private_resolver.vmss_private_resolver.ip_configuration, "private_ip_address", null) != null ? dns_private_resolver.vmss_private_resolver.ip_configuration.private_ip_address : cidrhost(azurerm_subnet.connectivity["01-snet-shared-01"].address_prefixes[0], dns_private_resolver.vmss_private_resolver.ip_configuration.cidrhost_hostnum)
        vmss_name           = "${local.region_code}-vmss-${lookup(dns_private_resolver, "workload_name", var.project_name)}-${var.environment}-${dns_private_resolver.instance_name}"
        admin_username      = dns_private_resolver.vmss_private_resolver.admin_username
        instances           = 2
        upgrade_mode        = "Rolling"
        tags                = merge(dns_private_resolver.tags, local.tags)
      } } : {}
    }
    ) if var.virtual_network_creation
  }

  dns_public_zone = { for key, value in var.dns_public_zone : key => merge(value, {
    resource_group_name = lookup(value, "resource_group_name", var.dns_default_specification.dns_public_zone.resource_group_name)
    tags                = merge(lookup(value, "tags", {}), local.tags)
    caa_records         = lookup(value, "caa_records", {})
    aaaa_records        = lookup(value, "aaaa_records", {})
    ns_records          = lookup(value, "ns_records", {})
    a_records = { for record_key, record_value in lookup(value, "a_records", {}) : record_key => merge(record_value,
      {
        name                = lookup(record_value, "name", record_key)
        zone_name           = value.name
        resource_group_name = value.resource_group_name
        ttl                 = var.dns_default_specification.dns_public_zone.record_ttl
        tags                = merge(lookup(record_value, "tags", {}), lookup(value, "tags", {}), local.tags)
      }
    ) }
    cname_records = { for record_key, record_value in lookup(value, "cname_records", {}) : record_key => merge(record_value,
      {
        name                = lookup(record_value, "name", record_key)
        zone_name           = value.name
        resource_group_name = value.resource_group_name
        ttl                 = var.dns_default_specification.dns_public_zone.record_ttl
        tags                = merge(lookup(record_value, "tags", {}), lookup(value, "tags", {}), local.tags)
      }
    ) }
    mx_records = { for record_key, record_value in lookup(value, "mx_records", {}) : record_key => merge(record_value,
      {
        name                = lookup(record_value, "name", record_key)
        zone_name           = value.name
        resource_group_name = value.resource_group_name
        ttl                 = var.dns_default_specification.dns_public_zone.record_ttl
        tags                = merge(lookup(record_value, "tags", {}), lookup(value, "tags", {}), local.tags)
      }
    ) }
    ptr_records = lookup(value, "ptr_records", {})
    srv_records = lookup(value, "srv_records", {})
    txt_records = { for record_key, record_value in lookup(value, "txt_records", {}) : record_key => merge(record_value,
      {
        name                = lookup(record_value, "name", record_key)
        zone_name           = value.name
        resource_group_name = value.resource_group_name
        ttl                 = var.dns_default_specification.dns_public_zone.record_ttl
        tags                = merge(lookup(record_value, "tags", {}), lookup(value, "tags", {}), local.tags)
      }
    ) }
    enable_telemetry = lookup(value, "enable_telemetry", true)
    })
  }
}
