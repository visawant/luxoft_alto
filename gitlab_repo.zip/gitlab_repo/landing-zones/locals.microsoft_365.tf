locals {
  microsoft_365_resource_group = { for key, value in var.microsoft_365_resource_group : key => value if var.microsoft_365_creation }

  microsoft_365_powerbi_embedded = { for key, value in var.microsoft_365_powerbi_embedded : key => merge(
    {
      name                = replace("${local.region_code}pbi${lookup(value, "workload_name", var.project_name)}${var.environment}${value.instance_name}", "-", "")
      resource_group_name = azurerm_resource_group.microsoft_365[lookup(value, "resource_group_key", "power-bi-online-01")].name
      location            = azurerm_resource_group.microsoft_365[lookup(value, "resource_group_key", "power-bi-online-01")].location
      mode                = lookup(value, "mode", var.microsoft_365_default_specification.powerbi_embedded.mode)
      sku_name            = lookup(value, "sku_name", var.microsoft_365_default_specification.powerbi_embedded.sku_name)
      administrators      = lookup(value, "administrators", null)
    },
    value,
    {
      tags = merge(local.tags, lookup(value, "tags", {}))
    }
  ) if var.microsoft_365_creation }

  microsoft_365_fabric_capacity = { for key, value in var.microsoft_365_fabric_capacity : key => merge(
    value,
    {
      name                = "${local.region_code}-fabc-${lookup(value, "workload_name", var.project_name)}-${var.environment}-${value.instance_name}"
      resource_group_name = azurerm_resource_group.microsoft_365[lookup(value, "resource_group_key", "power-bi-online-01")].name
      location            = azurerm_resource_group.microsoft_365[lookup(value, "resource_group_key", "power-bi-online-01")].location
      tags                = merge(local.tags, lookup(value, "tags", {}))
    }
  ) if var.microsoft_365_creation }

  microsoft_365_bot_service_azure_bot = { for key, value in var.microsoft_365_bot_service_azure_bot : key => merge(
    value,
    {
      name                = "${local.region_code}-bot-${value.workload_name}-${var.environment}-${value.instance_name}"
      resource_group_name = azurerm_resource_group.microsoft_365[value.resource_group_key].name
      location            = coalesce(value.location, azurerm_resource_group.microsoft_365[value.resource_group_key].location)
      sku                 = coalesce(value.sku, var.microsoft_365_default_specification.bot_service_azure_bot.sku)
      tags                = merge(local.tags, value.tags)
    }
  ) if var.microsoft_365_creation }

  microsoft_365_bot_channel_ms_teams = tomap({
    for son in
    flatten([
      for father_key, father in local.microsoft_365_bot_service_azure_bot : [
        for son_key, son in father.ms_teams : {
          key = "${father_key}-${son_key}"
          ms_teams = merge(
            son,
            {
              microsoft_365_bot_service_azure_bot_key = father_key
              resource_group_name                     = coalesce(son.resource_group_name, father.resource_group_name)
              location                                = coalesce(son.location, father.location)
              bot_name                                = coalesce(son.bot_name, father.name)
            }
          )
        }
      ]
    ]) : son.key => son.ms_teams
  })
}
