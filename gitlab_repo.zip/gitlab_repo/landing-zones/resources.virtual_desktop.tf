resource "azurerm_resource_group" "virtual_desktop" {
  for_each = local.virtual_desktop_resource_group

  name     = "${lookup(each.value, "region_code", local.region_code)}-rg-virtual-desktop-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
