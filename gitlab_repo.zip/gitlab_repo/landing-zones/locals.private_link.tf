locals {
  private_link_resource_group = { for key, value in var.private_link_resource_group : key => value if var.private_link_creation }
  private_link                = var.private_link_creation || var.private_link_private_endpoint != {} ? { "01" = {} } : {}

  private_link_key_vault_key = var.private_link_creation && length(var.private_link_forwarding_rule) > 0 ? {
    "${var.private_link_default_specification.key_vault_key_key}" = {
      key_vault_key = var.private_link_default_specification.key_vault_key
      name          = "${var.project_name}-private-link-01"
    }
  } : {}

  private_link_private_endpoint = { for private_endpoint_key, private_endpoint in merge(var.private_link_private_endpoint, local.container_endpoints) : private_endpoint_key => merge(
    {
      name                = "${local.region_code}-pep-${lookup(private_endpoint, "workload_name", private_endpoint_key)}-${lookup(private_endpoint, "environment_type", var.environment)}-${private_endpoint.instance_name}"
      resource_group_name = azurerm_resource_group.private_link[lookup(private_endpoint, "resource_group_key", "01")].name
      location            = azurerm_resource_group.private_link[lookup(private_endpoint, "resource_group_key", "01")].location
      subnet_id           = lookup(private_endpoint, "subnet_key", null) == null ? null : azurerm_subnet.connectivity[private_endpoint.subnet_key].id
      private_dns_zone_id = lookup(private_endpoint, "private_dns_zone_key", null) == null ? null : module.dns[private_endpoint.private_dns_zone_key].resource.id
    },
    private_endpoint,
    {
      tags = merge(lookup(private_endpoint, "tags", {}), local.tags)
      private_service_connection = lookup(private_endpoint, "private_service_connection", null) == null ? [] : [
        {
          name                           = private_endpoint.private_service_connection.name
          is_manual_connection           = lookup(private_endpoint.private_service_connection, "is_manual_connection", false)
          private_connection_resource_id = lookup(private_endpoint.private_service_connection, "private_link_forwarding_rule_key", null) == null ? private_endpoint.private_service_connection.private_connection_resource_id : module.private_link_forwarding_rule[private_endpoint.private_service_connection.private_link_forwarding_rule_key].private_link_service_id
          subresource_names              = lookup(private_endpoint.private_service_connection, "subresource_names", null) == null ? null : private_endpoint.private_service_connection.subresource_names
          request_message                = lookup(private_endpoint.private_service_connection, "request_message", null)
        }
      ]
    }
  ) if var.private_link_creation }

  private_link_forwarding_rule = { for forwarding_rule_key, forwarding_rule in var.private_link_forwarding_rule : forwarding_rule_key => merge(
    {
      virtual_machine_scale_set_name      = "${local.region_code}-vmss-${coalesce(forwarding_rule.workload_name, var.project_name)}-${coalesce(forwarding_rule.environment_type, var.environment)}-${coalesce(forwarding_rule.instance_name, forwarding_rule_key)}"
      private_link_service_name           = "${local.region_code}-pl-${coalesce(forwarding_rule.workload_name, var.project_name)}-${coalesce(forwarding_rule.environment_type, var.environment)}-${coalesce(forwarding_rule.instance_name, forwarding_rule_key)}"
      lb_name                             = "${local.region_code}-lbi-${coalesce(forwarding_rule.workload_name, var.project_name)}-${coalesce(forwarding_rule.environment_type, var.environment)}-${coalesce(forwarding_rule.instance_name, forwarding_rule_key)}"
      prefix                              = "${local.region_code}-"
      suffix                              = "-${coalesce(forwarding_rule.workload_name, var.project_name)}-${coalesce(forwarding_rule.environment_type, var.environment)}-${coalesce(forwarding_rule.instance_name, forwarding_rule_key)}"
      resource_group_name                 = azurerm_resource_group.private_link[forwarding_rule.resource_group_key].name
      location                            = azurerm_resource_group.private_link[forwarding_rule.resource_group_key].location
      subnet_id_private_link              = azurerm_subnet.connectivity[forwarding_rule.subnet_key_private_link].id
      subnet_id_load_balancer             = azurerm_subnet.connectivity[forwarding_rule.subnet_key_load_balancer].id
      subnet_id_virtual_machine_scale_set = coalesce(forwarding_rule.subnet_key_virtual_machine_scale_set, "null") == "null" ? null : azurerm_subnet.connectivity[forwarding_rule.subnet_key_virtual_machine_scale_set].id
      custom_network_interface_backend_address_pool_association = forwarding_rule.aviatrix.use ? {
        "specialty-${forwarding_rule_key}" = {
          network_interface_id = "/subscriptions/${var.subscription_id_client}/resourceGroups/${azurerm_virtual_network.connectivity[forwarding_rule.aviatrix.virtual_network_key].resource_group_name}/providers/Microsoft.Network/networkInterfaces/${replace(aviatrix_gateway.connectivity["specialty-${forwarding_rule_key}"].cloud_instance_id, "-gw-", "-nic-")}"
        }
      } : {}
      customer_managed_key = {
        key_vault_key_id      = module.keyvault[var.private_link_default_specification.key_vault_key].key[var.private_link_default_specification.key_vault_key_key].versionless_id
        key_vault_resource_id = module.keyvault[var.private_link_default_specification.key_vault_key].key_vault.id
      }
    },
    forwarding_rule,
    {
      additional_tags = merge(forwarding_rule.tags, local.tags)
      private_link_service_visibility_and_auto_approval_subscription_ids = coalescelist(forwarding_rule.private_link_service_visibility_and_auto_approval_subscription_ids,
        var.environment == "prd" ? [
          "06990571-f710-403d-b219-b59325a657d6", //sub-shared-services-prd
          ] : [
          "cf199ca0-37f5-4acb-8dff-9e4d284790b7", //sub-shared-services-np
      ])
    }
  ) if var.private_link_creation }
}
