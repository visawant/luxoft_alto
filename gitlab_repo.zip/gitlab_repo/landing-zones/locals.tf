locals {
  environment_type = var.environment == "prd" ? "prd" : "np"
  region_code      = var.region_code[var.region]
  location_cli     = module.azure_region.location_cli

  tags = merge({
    project_name = var.project_name
    environment  = var.environment
    it_owner     = var.it_owner
    ops_team     = var.ops_team
    module       = "landing-zones"
    provisioner  = "terraform"
  }, var.tags)
}
