locals {
  monitor_resource_group = { for key, value in var.monitor_resource_group : key => value if var.monitor_creation }
}
