resource "azurerm_resource_group" "app_service" {
  for_each = local.app_service_resource_group

  name     = "${local.region_code}-rg-app-services-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
