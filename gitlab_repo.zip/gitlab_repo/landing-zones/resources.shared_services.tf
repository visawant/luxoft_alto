resource "azurerm_resource_group" "shared_services" {
  for_each = local.shared_services_resource_group

  name     = "${var.region_code[coalesce(each.value.location, var.region)]}-rg-${each.value.workload_name}-${var.environment}-${each.value.instance_name}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}

resource "azurerm_resource_group" "shared_services_managed_by_azure" {
  for_each = local.shared_services_resource_group_managed_by_azure

  name     = each.value.name
  location = each.value.location
  tags     = each.value.tags
}

resource "azurerm_role_assignment" "shared_services_resource_group" {
  for_each = local.shared_services_resource_group_role_assignment

  scope                = azurerm_resource_group.shared_services[each.value.resource_group_key].id
  role_definition_name = each.value.role_definition_name
  principal_id         = each.value.principal_id
  principal_type       = each.value.principal_type
}

data "azurerm_key_vault_secret" "certificate_shared_services_prd" {
  provider     = azurerm.shared_services_prd
  for_each     = { for k, v in merge(var.shared_services_default_specification.existing_certificate, var.shared_services_default_specification.existing_secret) : k => v if v.alias == "shared_services_prd" }
  name         = each.value.name
  key_vault_id = each.value.key_vault_id
}
