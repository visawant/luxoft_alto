resource "azurerm_resource_group" "backup" {
  for_each = local.backup_resource_group

  name     = "${local.region_code}-rg-${each.value.workload_name}-${var.environment}-${each.value.instance_name}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}

resource "azurerm_role_assignment" "backup_resource_group" {
  for_each = local.backup_resource_group_role_assignment

  scope                = azurerm_resource_group.backup[each.value.resource_group_key].id
  role_definition_name = each.value.role_definition_name
  principal_id         = each.value.principal_id
  principal_type       = each.value.principal_type
}
