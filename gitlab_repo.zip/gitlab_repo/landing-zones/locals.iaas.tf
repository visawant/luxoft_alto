locals {
  iaas_resource_group = { for key, value in var.iaas_resource_group : key => value if var.virtual_network_creation && var.iaas_creation }
  iaas_vm = { for vm_key, vm in var.iaas_vm : vm_key => merge(
    vm,
    {
      name                = coalesce(vm.name, replace("${local.region_code}${lookup(vm, "workload_name", var.project_name)}${var.environment}${vm.instance_name}", "-", ""))
      name_interface      = coalesce(vm.name_interface, replace("${local.region_code}nic${lookup(vm, "workload_name", var.project_name)}${var.environment}${vm.instance_name}", "-", ""))
      subnet_id           = azurerm_subnet.connectivity[vm.subnet_key].id
      vm_ip               = coalesce(vm.ip_address, cidrhost(azurerm_subnet.connectivity[vm.subnet_key].address_prefixes[0], vm.ip_address_cidrhost_hostnum))
      resource_group_name = azurerm_resource_group.iaas[lookup(vm, "resource_group_key", "01")].name
      location            = azurerm_resource_group.iaas[lookup(vm, "resource_group_key", "01")].location
      user                = substr(coalesce(vm.user, "${coalesce(vm.name, replace("${local.region_code}${lookup(vm, "workload_name", var.project_name)}${var.environment}${vm.instance_name}", "-", ""))}-admin"), 0, 20)
      password            = coalesce(vm.password, module.keyvault[vm.keyvault_key].password["iaas_vm-${vm_key}"].value)
      source_image_reference = coalesce(vm.source_image_reference, vm.type == "windows" ?
        {
          publisher = "MicrosoftWindowsServer"
          offer     = "WindowsServer"
          sku       = "2022-Datacenter"
          version   = "latest"
        } :
        {
          publisher = "Canonical"
          offer     = "0001-com-ubuntu-server-jammy" #Find specific images : az vm image list --offer 0001-com-ubuntu-server-jammy --all --output table (https://documentation.ubuntu.com/azure/azure-how-to/instances/find-ubuntu-images/)
          version   = "latest"
          sku       = "22_04-lts-gen2" /*
        Use a supported OS for the Linux Dependency agent: https://learn.microsoft.com/en-us/azure/virtual-machines/extensions/agent-dependency-linux?WT.mc_id=AZ-MVP-5003548#operating-system
        and OS that support Automatic OS Upgrade https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/virtual-machine-scale-sets-automatic-upgrade?WT.mc_id=AZ-MVP-5003548
        */
        }
      )
      tags = merge(local.tags, lookup(vm, "tags", {}))
    }
  ) if var.virtual_network_creation && var.iaas_creation }
}
