terraform {
  required_version = "~> 1.11"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.8, >= 4.55"
      configuration_aliases = [
        azurerm.shared_services,
        azurerm.dns,
      ]
    }
    aviatrix = {
      source  = "AviatrixSystems/aviatrix"
      version = "~> 3.0"
    }
    azuredevops = {
      source  = "microsoft/azuredevops"
      version = ">=0.1.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 3.0.2"
    }
    azapi = {
      source  = "Azure/azapi"
      version = "2.4.0" // Could not source 2.5.0 --> Error while installing azure/azapi v2.5.0: error checking signature: openpgp: signature expired
    }
    grafana = {
      source  = "grafana/grafana"
      version = "~> 4.24"
    }
  }
}

provider "azurerm" {
  storage_use_azuread             = true
  resource_provider_registrations = "extended"
  subscription_id                 = var.subscription_id_client
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
}

provider "azurerm" {
  resource_provider_registrations = "extended"
  alias                           = "shared_services"
  subscription_id                 = var.subscription_id_shared_services
  features {}
}

provider "azurerm" {
  resource_provider_registrations = "extended"
  alias                           = "shared_services_np"
  subscription_id                 = var.subscription_id_shared_services_np
  features {}
}

provider "azurerm" {
  resource_provider_registrations = "extended"
  alias                           = "shared_services_prd"
  subscription_id                 = var.subscription_id_shared_services_prd
  features {}
}

provider "azurerm" {
  resource_provider_registrations = "extended"
  alias                           = "networking"
  subscription_id                 = var.subscription_id_networking
  features {}
}

provider "azurerm" {
  resource_provider_registrations = "extended"
  alias                           = "dns"
  subscription_id                 = split("/", var.dns_default_specification.dns_private_zone.azure_intramundi_com.private_dns_zone_id)[2]
  features {}
}

provider "aviatrix" {
  controller_ip           = var.CONTROLLER_PUBLIC_IP
  username                = var.CONTROLLER_USERNAME
  password                = var.CONTROLLER_PASSWORD
  skip_version_validation = true
}

provider "helm" {
  registries = [
    {
      url      = var.ARTIFACT_URL
      username = var.ARTIFACT_USERNAME
      password = var.ARTIFACT_PASSWORD
    }
  ]

  kubernetes = {
    host                   = local.container_aks == {} ? null : module.aks["01"].aks.kube_admin_config.0.host
    client_certificate     = local.container_aks == {} ? null : base64decode(module.aks["01"].aks.kube_admin_config.0.client_certificate)
    client_key             = local.container_aks == {} ? null : base64decode(module.aks["01"].aks.kube_admin_config.0.client_key)
    cluster_ca_certificate = local.container_aks == {} ? null : base64decode(module.aks["01"].aks.kube_admin_config.0.cluster_ca_certificate)
  }
}

provider "kubernetes" {
  host                   = local.container_aks == {} ? null : module.aks["01"].aks.kube_admin_config.0.host
  client_certificate     = local.container_aks == {} ? null : base64decode(module.aks["01"].aks.kube_admin_config.0.client_certificate)
  client_key             = local.container_aks == {} ? null : base64decode(module.aks["01"].aks.kube_admin_config.0.client_key)
  cluster_ca_certificate = local.container_aks == {} ? null : base64decode(module.aks["01"].aks.kube_admin_config.0.cluster_ca_certificate)
}

provider "azuredevops" {
  org_service_url = var.azure_devops_default_specification.org_service_url
  tenant_id       = data.azurerm_client_config.current.tenant_id
  client_id       = var.ADO_ARM_CLIENT_ID
  client_secret   = var.ADO_ARM_CLIENT_SECRET
}

provider "grafana" {
  url  = var.grafana_url_prd
  auth = local.shared_services_existing_secret["grafana-prd-sa-1-terraform-manage-datasource-secret"].value
}
