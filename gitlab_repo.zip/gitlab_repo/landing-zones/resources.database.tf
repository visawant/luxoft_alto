resource "azurerm_resource_group" "database" {
  for_each = local.database_resource_group

  name     = "${local.region_code}-rg-${each.value.workload_name}-${var.environment}-${each.value.instance_name}"
  location = coalesce(each.value.location, var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}

resource "azurerm_role_assignment" "database_resource_group" {
  for_each = local.database_resource_group_role_assignment

  scope                = azurerm_resource_group.database[each.value.resource_group_key].id
  role_definition_name = each.value.role_definition_name
  principal_id         = each.value.principal_id
  principal_type       = each.value.principal_type
}

resource "azurerm_user_assigned_identity" "database" {
  for_each = local.database_user_assigned_identity

  name                = each.value.name
  resource_group_name = each.value.resource_group_name
  location            = each.value.location
  tags                = merge(coalesce(each.value.tags, {}), local.tags)
}
