output "connectivity_subnet" {
  value = azurerm_subnet.connectivity
}
output "connectivity_network_security_group" {
  value = azurerm_network_security_group.connectivity
}

output "connectivity_route_table" {
  value = azurerm_route_table.connectivity
}

output "private_link" {
  value = module.private_link
}

output "dns_private_zone" {
  value = module.dns
}

output "private_link_forwarding_rule" {
  value = module.private_link_forwarding_rule
}

output "shared_services_key_vault" {
  value = { for key, value in module.keyvault : key => value.key_vault }
}

output "shared_services_container_registry" {
  value = { for key, value in module.acr : key => value.container_registry }
}

output "container_aks" {
  value = { for key, value in module.aks : key =>
    {
      aks_user_assigned_identity_client_id     = value.aks_user_assigned_identity_client_id
      aks_key_vault_secrets_provider_client_id = value.aks_key_vault_secrets_provider_client_id
      aks_private_disk_access                  = value.aks_private_disk_access
      traefik_private_link_id                  = lookup(local.container_aks_post_install["01"].helm_release, "traefik", null) == null ? null : local.container_aks_post_install["01"].helm_release.traefik.private_link_id
      aks_workload_identity                    = value.aks_workload_identity
    }
  }
}

output "azure_devops" {
  value = { for key, value in module.azure-devops : key =>
    {
      agent_pool = value.agent_pool
    }
  }
}