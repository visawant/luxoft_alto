resource "azurerm_resource_provider_registration" "container" {
  for_each = { for key, value in var.container_default_specification.aks.prometheus.enable ? toset(var.container_default_specification.aks.prometheus.required_resource_provider) : toset([]) : key => value if var.container_creation }
  name     = each.value

  lifecycle {
    ignore_changes = [
      # Ignoring the following parameters because we will manage the secret lifecycle outside from terraform
      feature
    ]
  }
}

resource "azurerm_resource_group" "container" {
  depends_on = [azurerm_resource_provider_registration.container]
  for_each   = local.container_resource_group

  name     = "${local.region_code}-rg-container-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
