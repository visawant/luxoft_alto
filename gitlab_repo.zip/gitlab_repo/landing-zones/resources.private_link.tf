resource "azurerm_resource_group" "private_link" {
  for_each = local.private_link_resource_group

  name     = "${local.region_code}-rg-private-link-${var.environment}-${each.key}"
  location = lookup(each.value, "location", var.region)
  tags     = merge(local.include_subscription_tags, coalesce(each.value.tags, {}), local.tags)
}
