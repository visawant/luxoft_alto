module "landing-zone" {
  source = "git::https://git.intramundi.com/public-cloud-infrastructure/microsoft-azure/terraform/modules/landing-zones.git?ref=main"

  subscription_id_client               = var.subscription_id_client
  project_name                         = var.project_name
  environment                          = var.environment
  it_owner                             = var.it_owner
  ops_team                             = var.ops_team
  region                               = var.region
  virtual_network_creation             = var.virtual_network_creation
  dns_creation                         = var.dns_creation
  dns_records                          = var.dns_records
  dns_records_http_probe_customization = var.dns_records_http_probe_customization
  shared_services_creation             = var.shared_services_creation
  shared_services_storage_account      = var.shared_services_storage_account
  shared_services_container_registry   = var.shared_services_container_registry
  private_link_creation                = var.private_link_creation
  iaas_creation                        = var.iaas_creation
  container_creation                   = var.container_creation
  container_default_specification      = var.container_default_specification
  container_aks_node_pool              = var.container_aks_node_pool
  database_creation                    = var.database_creation
  database_postgresql_flexible_server  = var.database_postgresql_flexible_server
  virtual_desktop_creation             = var.virtual_desktop_creation
  virtual_desktop_resource_group       = var.virtual_desktop_resource_group
  virtual_desktop                      = var.virtual_desktop
  bastion_creation                     = var.bastion_creation
  bastion_sku                          = var.bastion_sku
  azure_devops_creation                = var.azure_devops_creation
  azure_devops                         = var.azure_devops
  AD_SP_AVIATRIX_DAT_APP_ID            = var.AD_SP_AVIATRIX_DAT_APP_ID
  AD_SP_AVIATRIX_DAT_SECRET            = var.AD_SP_AVIATRIX_DAT_SECRET
  CONTROLLER_PUBLIC_IP                 = var.CONTROLLER_PUBLIC_IP
  CONTROLLER_USERNAME                  = var.CONTROLLER_USERNAME
  CONTROLLER_PASSWORD                  = var.CONTROLLER_PASSWORD
  ADO_ARM_CLIENT_ID                    = var.ADO_ARM_CLIENT_ID
  ADO_ARM_CLIENT_SECRET                = var.ADO_ARM_CLIENT_SECRET
  ADO_SYNC_REPO_USERNAME               = var.ADO_SYNC_REPO_USERNAME
  ADO_SYNC_REPO_PAT                    = var.ADO_SYNC_REPO_PAT
  ARTIFACT_URL                         = var.ARTIFACT_URL
  ARTIFACT_USERNAME                    = var.ARTIFACT_USERNAME
  ARTIFACT_PASSWORD                    = var.ARTIFACT_PASSWORD

  #Specific use case
  disable_container_aks_disk_encryption = true #Legacy option for unencrypted AKS, as mentioned in the following documentation we can currently enable a customer-managed key only while creating an AKS cluster registry https://learn.microsoft.com/en-us/azure/aks/azure-disk-customer-managed-keys?WT.mc_id=AZ-MVP-5003548
}
