# Introduction

Deploy the Amundi Technology China Infrastructure.

# Prerequisite

## Source your GitLab credential

```
secret_file_path="./env/.secret.env"

echo "TF_HTTP_USERNAME=Your_Gitlab_username" > $secret_file_path
echo "TF_HTTP_PASSWORD=Your_Gitlab_PAT" >> $secret_file_path

source $secret_file_path
```

## Create the Aviatrix secret file

Write the following values into the file "./env/aviatrix.secret.env"

```
aviatrix_secret_file_path=./env/aviatrix.secret.env

echo "AD_SP_AVIATRIX_DAT_APP_ID=\"f1\"" > $aviatrix_secret_file_path
echo "AD_SP_AVIATRIX_DAT_SECRET=\"Ib\"" >> $aviatrix_secret_file_path
echo "CONTROLLER_PUBLIC_IP=\"4.\"" >> $aviatrix_secret_file_path
echo "CONTROLLER_USERNAME=\"av\"" >> $aviatrix_secret_file_path
echo "CONTROLLER_PASSWORD=\"Jd\"" >> $aviatrix_secret_file_path
echo "ADO_ARM_CLIENT_ID=\"ed\"" >> $aviatrix_secret_file_path
echo "ADO_ARM_CLIENT_SECRET=\"fG\"" >> $aviatrix_secret_file_path
echo "ADO_SYNC_REPO_USERNAME=\"fG\"" >> $aviatrix_secret_file_path
echo "ADO_SYNC_REPO_PAT=\"fG\"" >> $aviatrix_secret_file_path
echo "ARTIFACT_USERNAME=\"fG\"" >> $aviatrix_secret_file_path
echo "ARTIFACT_PASSWORD=\"fG\"" >> $aviatrix_secret_file_path
```

# Login to azure using azure cli

`az login`

# Deployment through the Terraform wrapper

## 1. Launch a terraform apply, select your environment ("dmo", "prd" or even "all")

```
./terraformw -e dmo -t apply
```

## 2. Review the changes, select "yes" and press enter to launch the deployment

![apply asked](./image/apply_asked.png)

## 3. Make sure the deployment ended with no error

![apply result](./image/apply_result.png)

## 4. Launch a terraform destroy

```
./terraformw -e dmo -t destroy
```

## 5. Make sure the deletion ended with no error

![destroy asked](./image/destroy_completed.png)

# Manual deployment

```
backend_tfvars="./env/prd-backend.tfvars"
main_tfvars="./env/prd-main.tfvars"
aviatrix_secret_file="./env/aviatrix.secret.env"

terraform init -backend-config=$backend_tfvars -reconfigure

terraform plan -var-file=$main_tfvars -var-file=$aviatrix_secret_file

terraform apply -var-file=$main_tfvars -var-file=$aviatrix_secret_file
```
