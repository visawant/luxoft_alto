subscription_id_client = "ac8717f1-4c23-46d4-a765-5026590624d0"
environment            = "dmo"
ops_team               = "g-x-admin-azure"
it_owner               = "g-x-amtchina-it"

##############################################
###### container area specifications
##############################################

container_default_specification = {
  aks = {
    namespace = ["kasm", "kasm-session"]
    role_assignment = {
      "developer-aks-reader" = {
        role_definition_name = "Azure Kubernetes Service RBAC Reader"
        principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
        principal_type       = "Group"
      }
      "developer-aks-cli-user" = {
        role_definition_name = "Azure Kubernetes Service Cluster User Role"
        principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
        principal_type       = "Group"
      }
    }
  }
}
