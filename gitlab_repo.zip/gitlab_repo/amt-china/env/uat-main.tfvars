subscription_id_client = "4669bd91-ef5a-4b88-a667-06a81092aeab"
environment            = "uat"
ops_team               = "g-x-admin-azure"
it_owner               = "g-x-amtchina-it"

##############################################
###### database area specifications
##############################################
database_postgresql_flexible_server = {
  "01" = {
    storage_mb = "1048576"
  }
}

##############################################
###### dns area specifications
##############################################
dns_records = {
  traefik_private_endpoint_cname_record = {
    "01" = {
      container_aks_key = "01"
      dns_suffixes = [   //Will be prefixed by the env name for non prod env, sample: alto-amt-china-dmo.azure.intramundi.com
        "sso-amt-china", //Need this only on uat
        "alto-amt-china",
        "minio-alto-amt-china",
        "minio-console-alto-amt-china",
      ]
    }
  }
}
