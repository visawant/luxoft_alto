subscription_id_client   = "6a0a0a6d-2136-4be5-ab6f-7f8d15d01706"
environment              = "prd"
ops_team                 = "g-x-admin-azure"
it_owner                 = "g-x-amtchina-it"
virtual_network_creation = false
container_creation       = false
database_creation        = false

##############################################
###### azure devops area specifications
##############################################
azure_devops = {
  "01" = {
    amundi_products = ["alto-invest"]
    group_membership = {
      "01" = {
        entra_id_service_principal = [] //Not supported yet, we need to assign role and licence manually for the moment to service principal sp-azure-devops-frc-<application>-<env>-01 see https://github.com/microsoft/terraform-provider-azuredevops/pull/1028
        entra_id_group_member = [
          "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
        ]
      }
    }
  }
}

##############################################
###### Storage area specifications
##############################################

shared_services_storage_account = {
  "01" = {
    instance_name      = "01"
    resource_group_key = "01"
    account_tier       = "Premium"
    account_kind       = "FileStorage"
    tags = {
      description = "azure storage account"
    }

    private_endpoint = {

      current_file = {
        alias            = "current"
        subresource_name = "file"
        ip_configuration = [ // Use this block to fix the IP address
          {
            cidrhost_hostnum = 7 // Take the IP address number "cidrhost_hostnum" of the current subnet
          }
        ]
      }

      shared-services_file = {
        alias            = "shared-services"
        subresource_name = "file"
      }
    }
  }
}
