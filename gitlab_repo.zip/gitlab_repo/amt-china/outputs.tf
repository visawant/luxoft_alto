output "container_aks" {
  value = module.landing-zone.container_aks
}
