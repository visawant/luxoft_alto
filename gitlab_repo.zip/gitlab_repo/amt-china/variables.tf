variable "subscription_id_client" {
  type        = string
  description = "value of the subscription ID for the Client subscription"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id_client))
    error_message = "The subscription ID must be a valid UUID. Example: '12345678-1234-1234-1234-123456789abc'."
  }
}

variable "project_name" {
  description = "Project name used by our Cloud naming convention: https://confluence.intramundi.com/display/ITSPCI/Cloud+naming+convention"
  type        = string
  validation {
    condition     = length(var.project_name) <= 15
    error_message = "Project name is too long. Max length is 15 characters.."
  }
  default = "amt-china"
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  validation {
    condition     = length(var.environment) <= 3 && contains(["dmo", "tst", "rct", "dev", "uat", "np", "prd"], var.environment)
    error_message = "Valid value is one of the following: dmo, tst, rct,  dev, uat, np, prd."
  }
}

variable "ops_team" {
  description = "Team accountable for day-to-day operations."
  type        = string
  validation {
    condition     = length(var.ops_team) <= 15 && can(regex("^[a-zA-Z0-9-]*$", var.ops_team))
    error_message = "The ops_team name must be less than 15 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "it_owner" {
  description = "Top-level division of your company that owns the subscription or workload that the resource belongs to. In smaller organizations, this tag might represent a single corporate or shared top-level organizational element."
  type        = string
  validation {
    condition     = length(var.it_owner) <= 100 && can(regex("^[a-zA-Z0-9-@.]*$", var.it_owner))
    error_message = "The it_owner name must be less than 15 characters, can include letters, numbers, and hyphens, and must not contain special characters or spaces."
  }
}

variable "region" {
  description = "Azure region"
  type        = string
  default     = "East Asia"
}


##############################################
###### artifact store
##############################################
variable "ARTIFACT_URL" {
  description = "Artifact store URL"
  type        = string
  default     = "oci://helm-virtual-oci.intramundi.com"
}

variable "ARTIFACT_USERNAME" {
  description = "Artifact store username"
  type        = string
  sensitive   = true
}

variable "ARTIFACT_PASSWORD" {
  description = "Artifact store password"
  type        = string
  sensitive   = true
}

##############################################
###### connectivity area specifications
##############################################
variable "virtual_network_creation" {
  description = "Create a Virtual Network"
  type        = bool
  default     = true
}

variable "bastion_creation" {
  description = "Create a Bastion"
  type        = bool
  default     = false
}

variable "bastion_sku" {
  description = "Bastion SKU"
  type        = string
  validation {
    condition     = contains(["Standard", "Developer"], var.bastion_sku)
    error_message = "Valid value is one of the following: Standard, Developer."
  }
  default = "Developer" //"Standard" // The "Developer" is not supported yet in "East Asia" cf https://learn.microsoft.com/en-us/azure/bastion/quickstart-developer-sku?WT.mc_id=AZ-MVP-5003548
}

##############################################
###### dns area specifications
##############################################
variable "dns_creation" {
  description = "Create a DNS area"
  type        = bool
  default     = true
}

variable "dns_records" {
  description = "DNS records to create"
  type = object({
    traefik_private_endpoint_cname_record = map(object({
      container_aks_key = optional(string, "01")
      dns_suffixes      = list(string)
    }))
  })
  default = {
    traefik_private_endpoint_cname_record = {
      "01" = {
        container_aks_key = "01"
        dns_suffixes = [ //Will be prefixed by the env name for non prod env, sample: alto-amt-china-dmo.azure.intramundi.com
          "alto-amt-china",
          "minio-alto-amt-china",
          "minio-console-alto-amt-china",
        ]
      }
    }
  }
}

variable "dns_records_http_probe_customization" {
  description = "Custom specification for the http probe based on the dns_records keys"
  type = object({
    traefik_private_endpoint_cname_record = optional(map(object({
      container_aks_key = optional(string, "01")
      tags = optional(object({
        probeUriPrefixPath         = optional(string, "https://")
        probeUriSuffixPath         = optional(string, "/")
        probeSuccessHttpStatusCode = optional(string, "200")
      }), {})
    })), {})
  })
  default = {
    traefik_private_endpoint_cname_record = {
      "sso-amt-china" = {
        tags = {
          probeUriSuffixPath = "/auth"
        }
      }
      "alto-amt-china" = {
        tags = {
          probeUriSuffixPath = "/confidentiality"
        }
      }
      "minio-alto-amt-china" = {
        tags = {
          probeUriSuffixPath         = "/api"
          probeSuccessHttpStatusCode = "403"
        }
      }
    }
  }
}

##
## Aviatrix related config
variable "CONTROLLER_PUBLIC_IP" {
  type        = string
  description = "Controller public IP"
}

variable "CONTROLLER_USERNAME" {
  type        = string
  description = "Controller username"
}

variable "CONTROLLER_PASSWORD" {
  description = "Controller password"
  type        = string
}

variable "AD_SP_AVIATRIX_DAT_APP_ID" {
  type        = string
  description = "AAD Aviatrix DAT account App ID"
}

variable "AD_SP_AVIATRIX_DAT_SECRET" {
  description = "AAD Aviatrix DAT account secret"
  type        = string
}

##############################################
###### shared services area specifications
##############################################
variable "shared_services_creation" {
  description = "Create the shared services area with an Azure Key Vaults"
  type        = bool
  default     = true
}

variable "shared_services_storage_account" {
  description = "Storage account specifications"
  type        = any
  default = {
    "01" = {
      instance_name      = "01"
      resource_group_key = "01"
      account_tier       = "Premium"
      account_kind       = "FileStorage"
      tags = {
        description = "azure storage account"
      }

      private_endpoint = {

        current_file = {
          alias            = "current"
          subresource_name = "file"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 7 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }

        shared-services_file = {
          alias            = "shared-services"
          subresource_name = "file"
        }
      }
    }

    "02" = {
      instance_name      = "02"
      resource_group_key = "01"

      account_tier   = "Standard" // when is_hns_enabled is set to true the account_tier is Standard or Premium with account_kind is BlockBlobStorage
      account_kind   = "StorageV2"
      is_hns_enabled = "true" // must be true for ADLS Gen2
      tags = {
        description = "azure storage account"
      }

      private_endpoint = {
        current_file = {
          alias            = "current"
          subresource_name = "file"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 33 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }
        shared-services_file = {
          alias            = "shared-services"
          subresource_name = "file"
        }

        current_blob = {
          alias            = "current"
          subresource_name = "blob"
          ip_configuration = [ // Use this block to fix the IP address
            {
              cidrhost_hostnum = 34 // Take the IP address number "cidrhost_hostnum" of the current subnet
            }
          ]
        }
        shared-services_blob = {
          alias            = "shared-services"
          subresource_name = "blob"
        }
      }

      role_assignment = {
        "amt-china-dev-reader" = {
          role_definition_name = "Reader"
          principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21"
          principal_type       = "Group"
        }
        "amt-china-dev-blob-data-reader" = {
          role_definition_name = "Storage Blob Data Reader"
          principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21"
          principal_type       = "Group"
        }
      }
    }
  }
}

variable "shared_services_container_registry" {
  description = "Container registry specifications"
  type        = any
  default = {
    "01" = {
      role_assignment = {
        "developer-acr-push" = {
          role_definition_name = "AcrPush"
          principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
          principal_type       = "Group"
        }
      }
    }
  }
}

variable "iaas_creation" {
  description = "Create the shared services area"
  type        = bool
  default     = false
}

##############################################
###### private link area specifications
##############################################
variable "private_link_creation" {
  description = "Create the Private Link area"
  type        = bool
  default     = true
}

##############################################
###### virtual desktop area specifications
##############################################
variable "virtual_desktop_creation" {
  description = "Create a Virtual Desktop area"
  type        = bool
  default     = false
}

variable "virtual_desktop_resource_group" {
  description = "Resource Group specifications"
  type        = any
  default     = {}
}

variable "virtual_desktop" {
  description = "Virtual Desktop specifications"
  type        = any
  default     = {}
}

##############################################
###### container area specifications
##############################################
variable "container_creation" {
  description = "Create the container platform"
  type        = bool
  default     = true
}

variable "container_default_specification" {
  description = "Default specifications for the container platform"
  type        = any
  default = {
    aks = {
      namespace = ["kasm", "kasm-session"]
      role_assignment = {
        "developer-aks-reader" = {
          role_definition_name = "Azure Kubernetes Service RBAC Reader"
          principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
          principal_type       = "Group"
        }
        "developer-aks-cli-user" = {
          role_definition_name = "Azure Kubernetes Service Cluster User Role"
          principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
          principal_type       = "Group"
        }
        "developer-aks-writer" = {
          role_definition_name = "Azure Kubernetes Service RBAC Writer"
          principal_id         = "9688d588-d0ca-4f59-b052-9dd936ae5a21" //GSCO_CREW_AMT_CHINA
          principal_type       = "Group"
        }
      }
    }
  }
}

variable "container_aks_node_pool" {
  description = "AKS Node pools."
  type        = any
  default = {
    "02" = {
      min_count    = 1
      vm_size      = "standard_d2s_v5"
      os_disk_type = "Managed"
    }
    "03" = {
      instance_name = "03"
      min_count     = 0
      max_count     = 3
      vm_size       = "standard_d2s_v5"
      os_disk_type  = "Managed"
      node_taints = [
        "kubernetes.azure.com/scalesetpriority=spot:NoSchedule",
        "alto-client=true:NoSchedule"
      ]
    }
  }
}

##############################################
###### database area specifications
##############################################
variable "database_creation" {
  description = "Create the database platform"
  type        = bool
  default     = true
}

variable "database_postgresql_flexible_server" {
  description = "PostgreSQL Flexible Servers specifications"
  type        = any
  default = {
    "01" = {}
  }
}


##############################################
###### azure devops area specifications
##############################################
variable "ADO_ARM_CLIENT_ID" {
  type        = string
  description = "Client id of the service principal that will connect to Azure DevOps"
}

variable "ADO_ARM_CLIENT_SECRET" {
  description = "Client secret of the service principal that will connect to Azure DevOps"
  type        = string
}

variable "ADO_SYNC_REPO_USERNAME" {
  type        = string
  description = "Azure DevOps username used to sync repos"
}

variable "ADO_SYNC_REPO_PAT" {
  description = "Azure DevOps PAT used to sync repos"
  type        = string
}

variable "azure_devops_creation" {
  description = "Create a Azure DevOps area"
  type        = bool
  default     = true
}

variable "azure_devops" {
  description = "Azure DevOps specifications"
  default = {
    "01" = {
      amundi_products = ["alto-invest"]
      group_membership = {
        "01" = {}
      }
    }
  }
}
