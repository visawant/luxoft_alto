#!/bin/bash

# Default number of parallel jobs
DEFAULT_MAX_JOBS=2

# Check if input file and the number of parallel jobs are provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <image_list_file> <number_of_parallel_jobs>"
  echo ""
  echo "Example of image.txt as image_list_file:"
  echo "registry-docker.intramundi.com/vendors/keycloak/keycloak-operator:26.1.5 eacrmanagementnp01.azurecr.io/container/vendors/keycloak/keycloak-operator"
  echo "registry-docker.intramundi.com/amundi/sso/keycloak:26.1.0.1-azure eacrmanagementnp01.azurecr.io/container/sso/keycloak/keycloak"
  exit 1
fi

image_list_file=$1
max_jobs=${2:-$DEFAULT_MAX_JOBS}

# Verify the input file exists
if [ ! -f "$image_list_file" ]; then
  echo "File not found: $image_list_file"
  exit 1
fi

# Verify the number of parallel jobs is a positive integer
if ! [[ "$max_jobs" =~ ^[0-9]+$ ]] || [ "$max_jobs" -le 0 ]; then
  echo "The number of parallel jobs must be a positive integer."
  exit 1
fi

# Function to process a single image
process_image() {
  src_image=$1
  dest_base=$2

  # Extract the tag from the source image
  tag=$(echo "$src_image" | awk -F: '{print $2}')
  dest_image_with_tag="$dest_base:$tag"
  dest_image_latest="$dest_base:latest"
  
  echo "Processing image: $src_image"
  
  # Perform Docker pull, tag, and push
  docker pull "$src_image"
  docker tag "$src_image" "$dest_image_with_tag"
  docker tag "$src_image" "$dest_image_latest"
  docker push "$dest_image_with_tag"
  docker push "$dest_image_latest"
}

# Semaphore to control the number of parallel jobs
job_semaphore() {
  while (( $(jobs -p | wc -l) >= max_jobs )); do
    sleep 1
  done
}

# Read image list file line by line and process in parallel
while IFS= read -r line; do
  src_image=$(echo "$line" | awk '{print $1}')
  dest_base=$(echo "$line" | awk '{print $2}')

  # Control the number of parallel jobs
  job_semaphore

  # Start the process_image function in the background
  process_image "$src_image" "$dest_base" &
done < "$image_list_file"

# Wait for all background jobs to finish
wait

echo "All images processed."
