az login --use-device-code  
az acr login -n frccrcaceisppr01


https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/

https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/
https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/
https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/
https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/
https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/
https://jenkins-technical.intramundi.com/job/caas/job/azure_image_promotion/