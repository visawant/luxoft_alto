#_application# Helm chart
=============

Argocd Sync State
----------

| namespace | dev | rct | ppr | prd |
| --- | --- | --- | --- | --- |
| #_namespace# | [![App Status](https://np-argocd.intramundi.com/api/badge?name=#_application#-dev-#_namespace#)](https://np-argocd.intramundi.com/applications/#_application#-dev-#_namespace#) | [![App Status](https://np-argocd.intramundi.com/api/badge?name=#_application#-rct-#_namespace#)](https://np-argocd.intramundi.com/applications/#_application#-rct-#_namespace#) | [![App Status](https://np-argocd.intramundi.com/api/badge?name=#_application#-ppr-#_namespace#)](https://np-argocd.intramundi.com/applications/#_application#-ppr-#_namespace#) | [![App Status](https://argocd.intramundi.com/api/badge?name=#_application#-prd-#_namespace#)](https://argocd.intramundi.com/applications/#_application#-prd-#_namespace#) |


**Config deployment**

 * https://np-argocd.intramundi.com for non-production environments.
 * https://argocd.intramundi.com for production.

Click on the corresponding badge to synchronize the configuration.


----------
```console
AWX spring boot variables :
awx_survey__app_component
awx_survey__app_language
awx_survey__application
awx_survey__cmdb_app_id
awx_survey__cmdb_id_dev
awx_survey__cmdb_id_rct
awx_survey__cmdb_id_ppr
awx_survey__cmdb_id_prd
awx_survey__cmdb_name
awx_survey__exposed
awx_survey__image_repository_and_name
awx_survey__image_tag
awx_survey__namespace
awx_survey__server_servlet_context_path
awx_survey__trigramme
awx_survey__ingress_host
awx_survey__ingress_path
```



