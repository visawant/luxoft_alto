# alto-alto-invest Application Bundle

## Replacements at git repo init stage

### within `Chart.yaml`

__HELM_REPOSITORY__  

### within `bootstrap.yaml`
__CLUSTER__   
__ARGOCD_NAMESPACE__

### within `values.yaml`
__ARGOCD_NAMESPACE__  
__GIT_URL__


## Replacements at aks-post-install - helm install -f bootstrap.yaml

`--set bootstrap.projects[0].apps[0].commonValues=argocd-manifest/__ENVIRONMENT__/argocd-manifest.yaml`
